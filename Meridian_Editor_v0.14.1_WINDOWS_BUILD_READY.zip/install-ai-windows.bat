@echo off
cd /d "%~dp0"
echo MERIDIAN: optional local AI transcription engine
py -3 -m pip install --upgrade faster-whisper
if errorlevel 1 (
  echo If the command failed, check your Python installation and internet connection.
  pause
  exit /b 1
)
echo Installed. The selected AI model may need an internet download once.
pause
