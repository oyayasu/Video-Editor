#ifndef AppVersion
  #define AppVersion "0.14.1"
#endif
#ifndef SourceDir
  #error SourceDir is required. Pass /DSourceDir=<absolute packaged directory>
#endif
#define AppName "Meridian Editor"
#define AppExe "MeridianEditor.exe"
#define AppPublisher "Meridian Editor open-source project"
[Setup]
AppId={{E389F6C4-9602-4725-8392-4D82BDDF3574}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\Meridian Editor
DefaultGroupName=Meridian Editor
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#AppExe}
OutputDir=..\release
OutputBaseFilename=MeridianEditor_Setup_v{#AppVersion}
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern
SetupLogging=yes
CloseApplications=yes
ChangesAssociations=no

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Meridian Editor"; Filename: "{app}\{#AppExe}"
Name: "{autodesktop}\Meridian Editor"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Tasks]
Name: desktopicon; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Run]
Filename: "{app}\{#AppExe}"; Description: "Launch Meridian Editor"; Flags: nowait postinstall skipifsilent
