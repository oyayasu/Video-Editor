# -*- mode: python ; coding: utf-8 -*-
"""Onedir Windows distribution with embedded FFmpeg and QtWebEngine."""
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules

root = Path(SPECPATH).resolve().parent
# SPECPATH is the packaging/ directory supplied by PyInstaller.
ffmpeg = root / 'packaging' / '_stage' / 'bin'
dll = root / 'native' / 'bin' / 'meridian_compositor.dll'
assets = [(str(root / 'web'), 'web'),
          (str(root / 'packaging' / 'THIRD_PARTY_NOTICES.md'), 'licenses'),
          (str(root / 'LICENSE'), 'licenses')]
licenses = root / 'packaging' / '_stage' / 'licenses'
if licenses.exists():
    assets.append((str(licenses), 'licenses/ffmpeg'))
binaries = [(str(ffmpeg / 'ffmpeg.exe'), 'bin'), (str(ffmpeg / 'ffprobe.exe'), 'bin')]
if dll.is_file():
    binaries.append((str(dll), 'native/bin'))

analysis = Analysis(
    [str(root / 'desktop_entry.py')],
    pathex=[str(root)],
    binaries=binaries,
    datas=assets,
    hiddenimports=collect_submodules('PySide6.QtWebEngineWidgets') +
                  collect_submodules('PySide6.QtWebEngineCore'),
    excludes=['tkinter', 'matplotlib', 'numpy', 'pandas', 'pytest', 'playwright'],
    noarchive=False,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz, analysis.scripts, [],
    exclude_binaries=True,
    name='MeridianEditor',
    console=False,
    debug=False,
    strip=False,
    upx=False,
)
coll = COLLECT(
    exe, analysis.binaries, analysis.datas,
    strip=False, upx=False,
    name='MeridianEditor',
)
