# Meridian Editor Windows x64 distribution builder.
# Runs on a Windows machine or GitHub Actions windows-2022 runner.
# All build dependencies are needed only here, not on end-user machines.
[CmdletBinding()]
param(
  [switch]$SkipInstaller,
  [switch]$SkipNative,
  [string]$FfmpegZip = '',
  [string]$InnoCompiler = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $root
$version = '0.14.1'

function Run([string]$Exe, [string[]]$Arguments) {
  & $Exe @Arguments
  if ($LASTEXITCODE -ne 0) { throw "$Exe failed ($LASTEXITCODE): $($Arguments -join ' ')" }
}

$stage = Join-Path $root 'packaging\_stage'
$tools = Join-Path $stage 'bin'
$releases = Join-Path $root 'release'
New-Item -ItemType Directory -Force -Path $stage,$tools,$releases | Out-Null

# FFmpeg is packaged inside the application, not required in the user's PATH.
# To make a pinned/reproducible or offline build, pass -FfmpegZip with the
# previously downloaded verified Gyan Essentials archive.
$downloadedFfmpeg = -not [bool]$FfmpegZip
if ($downloadedFfmpeg) {
  $FfmpegZip = Join-Path $stage 'ffmpeg-release-essentials.zip'
  Write-Host 'Downloading FFmpeg Essentials for Windows x64 (Gyan.dev)...'
  Invoke-WebRequest 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile $FfmpegZip
}

if (-not (Test-Path -LiteralPath $FfmpegZip)) { throw "Missing FFmpeg archive: $FfmpegZip" }
$ffZipHash = (Get-FileHash -LiteralPath $FfmpegZip -Algorithm SHA256).Hash
if ($downloadedFfmpeg) {
  $checksumFile = Join-Path $stage 'ffmpeg-release-essentials.zip.sha256'
  Invoke-WebRequest 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip.sha256' -OutFile $checksumFile
  $officialHash = [regex]::Match((Get-Content $checksumFile -Raw), '(?i)\b[a-f0-9]{64}\b').Value
  if (-not $officialHash -or $ffZipHash.ToLowerInvariant() -ne $officialHash.ToLowerInvariant()) {
    throw 'FFmpeg download failed published SHA256 validation'
  }
}
Write-Host "FFmpeg archive SHA256: $ffZipHash"
$unpacked = Join-Path $stage 'unpacked-ffmpeg'
if (Test-Path $unpacked) { Remove-Item $unpacked -Recurse -Force }
Expand-Archive -LiteralPath $FfmpegZip -DestinationPath $unpacked -Force
$ffmpegFile = Get-ChildItem $unpacked -Recurse -Filter ffmpeg.exe -File | Select-Object -First 1
$ffprobeFile = Get-ChildItem $unpacked -Recurse -Filter ffprobe.exe -File | Select-Object -First 1
if (-not $ffmpegFile -or -not $ffprobeFile) { throw 'FFmpeg Essentials archive did not contain ffmpeg.exe + ffprobe.exe' }
Copy-Item $ffmpegFile.FullName (Join-Path $tools 'ffmpeg.exe') -Force
Copy-Item $ffprobeFile.FullName (Join-Path $tools 'ffprobe.exe') -Force
Run (Join-Path $tools 'ffmpeg.exe') @('-hide_banner','-version')
Run (Join-Path $tools 'ffprobe.exe') @('-hide_banner','-version')

# Include third-party license material when available in the upstream binary bundle.
$thirdParty = Join-Path $stage 'licenses'
New-Item -ItemType Directory -Force -Path $thirdParty | Out-Null
$licenseFiles = Get-ChildItem $unpacked -Recurse -File | Where-Object {
  $_.Name -match '^(LICENSE|COPYING|README)(\.(txt|md|html))?$'
}
foreach ($license in $licenseFiles) {
  $destination = Join-Path $thirdParty ('FFmpeg-' + $license.Name)
  if (-not (Test-Path $destination)) { Copy-Item $license.FullName $destination }
}

# Optional compositor: compile the exact source shipped with the editor.
if (-not $SkipNative) {
  $cmake = Get-Command cmake -ErrorAction SilentlyContinue
  if (-not $cmake) { throw 'CMake is required to build the native C++ compositor' }
  Run $cmake.Source @('-S','native','-B','native/build','-A','x64')
  Run $cmake.Source @('--build','native/build','--config','Release')
  $dll = Join-Path $root 'native\build\Release\meridian_compositor.dll'
  if (-not (Test-Path $dll)) { throw 'C++ compositor DLL not produced' }
  New-Item -ItemType Directory -Force -Path (Join-Path $root 'native\bin') | Out-Null
  Copy-Item $dll (Join-Path $root 'native\bin\meridian_compositor.dll') -Force
}

# This is an onedir build, to avoid repeated unpacking of Chromium/QtWebEngine.
$py = (Get-Command python -ErrorAction Stop).Source
Run $py @('-m','pip','install','--disable-pip-version-check','-r','packaging/requirements-build.txt')
Run $py @('-m','unittest','tests.test_desktop_packaging_v0141','-v')
Run $py @('-m','PyInstaller','--noconfirm','--clean','packaging/meridian.spec')
$exe = Join-Path $root 'dist\MeridianEditor\MeridianEditor.exe'
if (-not (Test-Path $exe)) { throw 'Missing packaged MeridianEditor.exe' }

# Self-test verifies packaged UI files, FFmpeg and app Python runtime.
Run $exe @('--self-test')

# Portable archive: user unzips and double-clicks MeridianEditor.exe.
$portable = Join-Path $releases "MeridianEditor_Portable_v$version.zip"
if (Test-Path $portable) { Remove-Item $portable -Force }
Compress-Archive -Path (Join-Path $root 'dist\MeridianEditor') -DestinationPath $portable -CompressionLevel Optimal

if (-not $SkipInstaller) {
  if (-not $InnoCompiler) {
    $candidates = @(
      (Join-Path ([Environment]::GetFolderPath('ProgramFilesX86')) 'Inno Setup 6\ISCC.exe'),
      "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
    )
    foreach ($candidate in $candidates) { if (Test-Path $candidate) { $InnoCompiler = $candidate; break } }
  }
  if (-not $InnoCompiler -or -not (Test-Path -LiteralPath $InnoCompiler)) {
    throw 'Inno Setup 6 is required for Setup.exe. Use -SkipInstaller for portable-only.'
  }
  Run $InnoCompiler @('/Q',('/DAppVersion='+$version),('/DSourceDir='+(Join-Path $root 'dist\MeridianEditor')), 'packaging/meridian.iss')
}

$summary = @(
  "Meridian Editor Windows x64 v$version",
  "FFmpeg Essentials archive SHA256: $ffZipHash",
  "Packaging timestamp (UTC): $((Get-Date).ToUniversalTime().ToString('o'))",
  'Packaging license notes: packaging/THIRD_PARTY_NOTICES.md'
) -join "`r`n"
Set-Content -Path (Join-Path $releases 'BUILD_INFO.txt') -Value $summary -Encoding utf8
Get-ChildItem $releases -File | Where-Object { $_.Extension -in ('.zip','.exe') } | ForEach-Object {
  "$((Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower()) *$($_.Name)"
} | Set-Content -Path (Join-Path $releases 'SHA256SUMS.txt') -Encoding ascii
Write-Host 'Windows release output:'
Get-ChildItem $releases | Select-Object Name,Length
