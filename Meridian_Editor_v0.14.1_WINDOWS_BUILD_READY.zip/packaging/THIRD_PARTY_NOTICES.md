# Third-party components in the Windows test distribution

This project is GPL-3.0. Distribution of a binary requires compliance with
applicable third-party licenses, including the license obligations of these
bundled components:

- **Qt / PySide6 / QtWebEngine**: Qt libraries are generally LGPL-3.0 / GPL
  with some separately licensed components. The build uses dynamically linked
  Qt DLLs. Before public distribution, include all corresponding applicable
  licenses and satisfy the LGPL requirements (including enabling replacement
  of Qt libraries). Review the exact installed package's notices.
- **FFmpeg / FFprobe**: Gyan.dev *Essentials* Windows build may include GPL
  components and optional codecs with distinct licenses. The archive SHA-256
  is captured in `BUILD_INFO.txt`. FFmpeg license details depend on precise
  configuration; inspect `ffmpeg -buildconf`, preserve license files, and
  provide the corresponding source as required by its license.
  Upstream: https://ffmpeg.org/legal.html
  Windows builds: https://www.gyan.dev/ffmpeg/builds/
- **Pillow**: Pillow license (HPND historical/Pillow) permits redistribution
  subject to the included conditions; see https://python-pillow.org/.
- **Python runtime**: Python Software Foundation License.
- **Inno Setup**: tool used to generate the installer; not embedded as a
  Python runtime dependency.

This **preview pipeline is for testing**, not a certification of legal
compliance for distributing binaries commercially. Before publishing a
release broadly, capture the precise upstream versions, preserve complete
license notices, supply the corresponding source or an appropriate compliant
offer, and audit bundled codecs and modules.

No DaFont files, paid Adobe components, or proprietary visual packs are
bundled by this pipeline. Offline transcription model weights are not bundled.
