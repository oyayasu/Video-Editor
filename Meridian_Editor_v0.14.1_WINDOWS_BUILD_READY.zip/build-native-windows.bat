@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>&1 || (echo Please install CMake and Visual Studio Build Tools C++ & exit /b 1)
cmake -S native -B native\build -A x64 || exit /b 1
cmake --build native\build --config Release || exit /b 1
if not exist native\bin mkdir native\bin
copy /Y native\build\Release\meridian_compositor.dll native\bin\ >nul || exit /b 1
echo Native compositor compiled. Run: py -m unittest discover -s tests
