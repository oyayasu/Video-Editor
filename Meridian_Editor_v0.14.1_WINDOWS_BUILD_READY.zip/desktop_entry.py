"""Native Windows entrypoint. Python is bundled when built with PyInstaller."""
from __future__ import annotations

import shutil
import sys
from pathlib import Path


def self_test() -> int:
    from src.server import WEB
    from src.media import ffprobe
    from src.effects import catalog
    from src.model import fresh
    if not (WEB / 'index.html').is_file():
        raise RuntimeError('Bundled frontend not found')
    for binary in ('ffmpeg', 'ffprobe'):
        if shutil.which(binary) is None:
            raise RuntimeError(binary + ' missing from packaged application')
    if not catalog() or not fresh():
        raise RuntimeError('Editor model did not initialize')
    # Probe the HTTP API through the same loopback routing used by the GUI.
    import json
    import urllib.request
    from src.server import make_server
    server = make_server()
    try:
        thread = __import__('threading').Thread(target=server.serve_forever, daemon=True)
        thread.start()
        port = server.server_address[1]
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/session', timeout=10) as response:
            status = json.load(response)
        if not status.get('ffmpeg') or not status.get('effects') or not status.get('token'):
            raise RuntimeError('Bundled HTTP API failed the startup probe')
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/', timeout=10) as response:
            if b'Meridian' not in response.read(1024 * 1024):
                raise RuntimeError('Main editor UI was not served')
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)
    # Verify desktop support is importable without starting a GUI session.
    from src.desktop import DialogDispatcher
    if not isinstance(DialogDispatcher(), DialogDispatcher):
        raise RuntimeError('Desktop module did not load')
    return 0


def main() -> int:
    if '--self-test' in sys.argv:
        return self_test()
    from src.desktop import run_desktop
    return run_desktop()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception:
        from datetime import datetime, timezone
        import traceback
        path = Path.home() / '.meridian-editor' / 'desktop-error.log'
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('a', encoding='utf-8') as stream:
            stream.write('\n' + datetime.now(timezone.utc).isoformat() + '\n')
            traceback.print_exc(file=stream)
        raise
