#!/usr/bin/env sh
set -eu
python3 -m pip install --user --upgrade faster-whisper
printf '%s\n' 'Optional transcription engine installed. Model weights may download on first use.'
