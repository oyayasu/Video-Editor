# Meridian Editor v0.14.1 — Windows Test Build

**Status:** código-fonte preparado para compilar um instalador Windows; o
instalador **ainda não foi gerado nem validado neste ambiente Linux**.

O alvo é Windows 10/11 x64, sem exigir Python, FFmpeg, CMake ou Qt no computador
onde o aplicativo será instalado. Essas dependências são incorporadas na
compilação realizada em um runner Windows ou computador de desenvolvimento.

## Arquivos produzidos quando o build Windows terminar

- `MeridianEditor_Setup_v0.14.1.exe` — instalador por usuário, com atalho no menu Iniciar e desinstalação.
- `MeridianEditor_Portable_v0.14.1.zip` — extrair e abrir `MeridianEditor.exe`, sem instalação.
- `SHA256SUMS.txt` — hashes dos arquivos produzidos.

Não existe nenhum desses executáveis no **pacote de código-fonte** entregue.

## Opção recomendada: GitHub Actions, sem instalar ferramentas no PC

1. Crie um repositório no GitHub (prefira **Private** até validar o programa).
2. Envie para esse repositório o conteúdo extraído do ZIP **incluindo a pasta
   `.github/workflows`**, preservando a estrutura de subpastas.
3. Abra a guia **Actions** do repositório. Se solicitado, habilite workflows.
4. Selecione **Build Meridian Windows test installer** e **Run workflow**.
5. Quando o workflow terminar com sucesso, abra a execução e baixe o artefato
   **Meridian-Windows-v0.14.1**; ele contém o instalador e o pacote portátil.
6. Verifique o `SHA256SUMS.txt` e, no seu Windows, execute o instalador.

GitHub Actions disponibiliza minutos gratuitos sujeitos ao tipo de repositório
e ao plano; compilação leva tempo, mas **as ferramentas de build não precisam
ser instaladas no seu PC**. Não publique o artefato antes de uma validação real.

O instalador não possui assinatura de código da Microsoft. O Windows SmartScreen
pode apresentar uma advertência para um aplicativo novo e não reconhecido;
isso não comprova, por si só, que o aplicativo esteja seguro. Valide a origem,
os hashes e o código antes de executar.

## Build local alternativo em Windows (desenvolvedores)

Requer Python 3.12 x64, Visual Studio C++ Build Tools, CMake e Inno Setup 6:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\build-windows.ps1
```

## Importante: o que a build faz e o que ainda falta

A build empacota a interface atual da v0.14.0 numa janela própria usando
PySide6/QtWebEngine, inclui runtime Python, FFmpeg/FFprobe, Pillow e C++ CPU,
executa verificação de integridade e gera os dois formatos Windows.

A versão continua **experimental**: não há compositor GPU nativo profissional,
sincronização audiovisual exata, suporte completo ao After Effects ou regressão
visual confirmada em Windows. Modelos de IA para legendas **não** estão
embutidos, pois aumentariam significativamente o tamanho e exigem um processo
específico de distribuição/licença.

Dados e recuperação ficam em `%USERPROFILE%\.meridian-editor`.
Faça a primeira experiência com arquivos de teste. Projetos e mídias não são
apagados automaticamente ao desinstalar a aplicação.

## Se falhar

Consulte o log do GitHub Actions para identificar a dependência ou etapa que
falhou. Para problemas de inicialização em Windows, procure
`%USERPROFILE%\.meridian-editor\desktop-error.log` e forneça a mensagem.
Esse roteiro ainda precisa da **primeira compilação em Windows** para confirmar
compatibilidade, tamanho do pacote e inicialização do QtWebEngine.
