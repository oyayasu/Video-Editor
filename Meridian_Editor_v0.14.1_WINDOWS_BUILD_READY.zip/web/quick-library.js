'use strict';
// Local, authored preset recipes; the backend is the source of truth for edits.
class MeridianQuickLibrary {
  constructor({presets,fonts,onApply,onTransition,onFontImport,onFontUse,toast}){
    this.presets=presets;this.fonts=fonts;this.onApply=onApply;
    this.onTransition=onTransition;this.onFontImport=onFontImport;this.onFontUse=onFontUse;this.toast=toast;
    this.query='';this.category='All';this.section='presets';this.loadedFonts=new Set();
    try{this.favorites=new Set(JSON.parse(localStorage.getItem('meridian-quick-favorites')||'[]'));}
    catch(_){this.favorites=new Set()}
  }
  setup(){
    document.querySelector('#quick-search').addEventListener('input',event=>{
      this.query=event.target.value.trim().toLowerCase();this.paint();
    });
    document.querySelector('#quick-category').addEventListener('change',event=>{
      this.category=event.target.value;this.paint();
    });
    document.querySelectorAll('[data-quick-section]').forEach(button=>button.addEventListener('click',()=>{
      this.section=button.dataset.quickSection;this.category='All';
      document.querySelectorAll('[data-quick-section]').forEach(b=>b.classList.toggle('active',b===button));
      this.paint();
    }));
    this.paint();
  }
  loadPreview(font){
    if(!font.installed_files?.length||this.loadedFonts.has(font.id)||typeof FontFace==='undefined')return;
    this.loadedFonts.add(font.id);
    const variant=font.installed_files[0];
    const path='/api/installed-font/'+encodeURIComponent(font.id)+'/'+encodeURIComponent(variant);
    new FontFace('MeridianDaFont-'+font.id,`url("${path}")`).load().then(face=>document.fonts.add(face))
      .catch(()=>this.loadedFonts.delete(font.id));
  }
  persist(){try{localStorage.setItem('meridian-quick-favorites',JSON.stringify([...this.favorites]));}catch(_){}}
  paint(){
    const root=document.querySelector('#quick-catalog');if(!root)return;
    root.replaceChildren();
    const isFont=this.section==='fonts';
    const transitions=[
      ['cross_dissolve','Cross Dissolve'],['wipe_left','Wipe Left'],['wipe_right','Wipe Right'],
      ['wipe_up','Wipe Up'],['wipe_down','Wipe Down'],['soft_wipe_left','Soft Wipe Left'],
      ['soft_wipe_right','Soft Wipe Right'],['soft_wipe_up','Soft Wipe Up'],
      ['soft_wipe_down','Soft Wipe Down'],['diagonal_tl','Diagonal TL'],
      ['diagonal_br','Diagonal BR'],['circle_reveal','Circle Reveal'],
      ['audio_crossfade','Audio Crossfade'],
    ];
    const candidates=isFont?this.fonts:this.section==='transitions'?transitions.map(([id,name])=>({id,name,category:id==='audio_crossfade'?'Audio':'Video',description:'Two-source transition between overlapping clips.'})):this.presets;
    const categories=['All',...new Set(candidates.map(p=>p.category))];
    if(!isFont&&this.section==='presets')categories.push('Favorites');
    const select=document.querySelector('#quick-category');select.replaceChildren();
    categories.forEach(category=>select.add(new Option(category,category)));
    if(!categories.includes(this.category))this.category='All';select.value=this.category;
    const filtered=candidates.filter(p=>(this.category==='All'||p.category===this.category||
      (this.category==='Favorites'&&this.favorites.has(p.id)))&&
      (p.name+' '+p.category+' '+(p.description||'')).toLowerCase().includes(this.query));
    for(const item of filtered){
      const card=document.createElement('div');card.className='quick-card'+(isFont&&item.provider==='DaFont'?' dafont-card':'');
      const main=document.createElement('button');main.type='button';main.className='quick-main';
      const title=document.createElement('strong');title.textContent=item.name;
      const sub=document.createElement('small');sub.textContent=isFont?((item.provider||'Free font')+' · '+item.license+(item.installed?' · imported':'')):item.category;
      const visual=document.createElement('span');visual.className='quick-swatch '+
        (isFont?'quick-type':this.section==='transitions'?'quick-transition':(item.kind==='audio'?'quick-audio':'quick-visual'));
      if(isFont){visual.textContent='Ag';visual.style.fontFamily=item.installed?'MeridianDaFont-'+item.id+', sans-serif':'sans-serif';this.loadPreview(item);}
      else visual.textContent=this.section==='transitions'?'◧':item.kind==='audio'?'≋':'◢';
      main.append(visual,title,sub);
      main.title=isFont?'DaFont original · check the author and license terms':item.description;
      main.onclick=()=>{
        if(isFont){window.open(item.source,'_blank','noopener,noreferrer');return;}
        if(this.section==='transitions')this.onTransition(item.id);
        else this.onApply(item.id);
      };
      card.append(main);
      if(isFont&&item.provider==='DaFont'){
        const actions=document.createElement('div');actions.className='dafont-actions';
        const importButton=document.createElement('button');importButton.type='button';
        importButton.textContent=item.installed?'Update ZIP':'Import ZIP';
        importButton.title='Select original ZIP downloaded from DaFont';
        importButton.onclick=()=>this.onFontImport(item);
        const useButton=document.createElement('button');useButton.type='button';
        useButton.textContent='Use in Title';useButton.disabled=!item.installed;
        useButton.onclick=()=>this.onFontUse(item.id);
        actions.append(importButton,useButton);card.append(actions);
      }
      if(!isFont&&this.section==='presets'){
        const favorite=document.createElement('button');favorite.type='button';favorite.className='quick-favorite';
        favorite.textContent=this.favorites.has(item.id)?'★':'☆';favorite.title='Toggle favorite';
        favorite.onclick=()=>{if(this.favorites.has(item.id))this.favorites.delete(item.id);else this.favorites.add(item.id);this.persist();this.paint()};
        card.append(favorite);
      }
      root.append(card);
    }
    const count=document.querySelector('#quick-count');count.textContent=`${filtered.length} / ${candidates.length} ${isFont?'font families':this.section==='transitions'?'transitions':'ready-to-use presets'}`;
    if(isFont){const tip=document.createElement('p');tip.className='hint';
      tip.textContent='DaFont: open its official page, download ZIP and use Import ZIP. The original Google Fonts references are also retained. Only commercially permitted OFL/CC0 DaFont families are eligible for import.';root.append(tip)}
    if(!filtered.length){const empty=document.createElement('p');empty.className='hint';empty.textContent='No matches';root.append(empty)}
  }
}
