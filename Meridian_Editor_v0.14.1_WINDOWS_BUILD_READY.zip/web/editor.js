'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const defaults={x:0,y:0,scale:1,rotation:0,opacity:1,volume:1,brightness:0,contrast:1,saturation:1,blur:0};
const specs={x:['Position X',-4000,4000,1],y:['Position Y',-4000,4000,1],scale:['Scale',.01,10,.01],rotation:['Rotation',-360,360,.1],opacity:['Opacity',0,1,.01],volume:['Volume',0,4,.01],brightness:['Brightness',-1,1,.01],contrast:['Contrast',0,3,.01],saturation:['Saturation',0,3,.01],blur:['Blur',0,15,.1]};
let activeSeqId=null, nestedTrail=[], selectedIds=new Set(), effectCatalog=[], quickPresetData=[], freeFontData=[], quickLibrary=null, selectedMediaId=null, missingMedia=new Set();
let gpuPreview=null, nativeStreamSerial=0, nativeStopPromise=Promise.resolve(), nativeStarting=false, nativeImageURL=null, nativePendingImageURL=null;
const transport=new MeridianTransportClock();
const nativeFrameClient=new MeridianFrameClient(fetch, (blob,frame,cacheStatus)=>{
 if(viewerMode()!=='native')return;
 const image=$('#native-frame');
 const next=URL.createObjectURL(blob);
 if(nativePendingImageURL){URL.revokeObjectURL(nativePendingImageURL)}
 nativePendingImageURL=next;
 image.onload=()=>{
  if(nativePendingImageURL!==next)return;
  if(nativeImageURL)URL.revokeObjectURL(nativeImageURL);
  nativeImageURL=next;nativePendingImageURL=null;
 };
 image.onerror=()=>{
  if(nativePendingImageURL===next)nativePendingImageURL=null;
  URL.revokeObjectURL(next);
 };
 image.src=next;image.classList.remove('hidden');
 $('#exact-status').textContent=`C++ cache ${cacheStatus==='HIT'?'HIT':'MISS'} · ${frameToText(frame)}`;
});
nativeFrameClient.onError=error=>{$('#exact-status').textContent='Native frame error: '+error.message};
let nativeReady=false, token='', doc=null, selected=null, projectPath=null, play=false, zoom=70, tool='select', snap=true, mode='inspector', activeTab='media', graphProperty='x', undos=[],redos=[],debounce=null, mediaTags=new Map(),audioTags=new Map(),toastTimeout=0, rendering=false;
const copy=o=>structuredClone(o);
function view(){return activeSeqId?(doc.sequences||[]).find(s=>s.id===activeSeqId)||doc:doc}
function resetSelection(){selected=null;selectedIds.clear()}
function openNest(id){hideExactFrame();if(viewerMode()==='native')stopNativeStream();const found=(doc.sequences||[]).find(s=>s.id===id);if(!found)return toast('Nested sequence missing',true);if(play)togglePlay();sourceMonitor.clearProgram();nestedTrail.push(activeSeqId);activeSeqId=id;resetSelection();paint();toast('Editing: '+found.name)}
function openSelectedNest(){const c=clip(selected);if(!c?.sequence_id)return toast('Select a nested clip to open it',true);openNest(c.sequence_id)}
function closeNest(){hideExactFrame();if(viewerMode()==='native')stopNativeStream();if(!activeSeqId)return;sourceMonitor.clearProgram();activeSeqId=nestedTrail.pop()||null;resetSelection();if(play)togglePlay();paint()}
async function nestSelected(){const ids=[...selectedIds];if(!ids.length&&selected)ids.push(selected);if(!ids.length)return toast('Select one or more clips (Shift+click) first',true);const name=prompt('Nested composition name','Nested composition');if(name===null)return;const before=JSON.stringify(doc);const result=await api('nest',{project:doc,clip_ids:ids,name,container_id:activeSeqId});undos.push(before);if(undos.length>90)undos.shift();redos.length=0;doc=result.project;if(viewerMode()==='native')stopNativeStream();resetSelection();selected=result.clip_ids[0]||null;if(selected)selectedIds.add(selected);paint();syncLater();toast('Nested composition created. Double-click to edit.')}

const asset=id=>doc.media.find(m=>m.id===id), track=id=>view().tracks.find(t=>t.id===id), clip=id=>view().clips.find(c=>c.id===id), fps=()=>doc.fps;
const uid=()=>globalThis.crypto?.randomUUID?.().replaceAll('-','').slice(0,12)||Math.random().toString(36).slice(2,14);
const frameToText=n=>{n=Math.max(0,Math.round(n));const r=fps(),s=Math.floor(n/r);return `${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.floor(s/60)%60).padStart(2,'0')}:${String(s%60).padStart(2,'0')}:${String(n%r).padStart(2,'0')}`};
function toast(message,error=false){const t=$('#toast');t.textContent=message;t.style.background=error?'#56303b':'#2c3b4c';t.classList.remove('hidden');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>t.classList.add('hidden'),5000)}
async function api(path,obj){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Meridian-Token':token},body:JSON.stringify(obj)});const d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}
function snapshot(){undos.push(JSON.stringify(doc));if(undos.length>90)undos.shift();redos.length=0}
function edit(mutator){snapshot();mutator();hideExactFrame();if(viewerMode()==='native')stopNativeStream();paint();syncLater()}
function syncLater(){clearTimeout(debounce);debounce=setTimeout(()=>api('sync',{project:doc}).catch(e=>toast('Autosave failed: '+e.message,true)),500)}
function undo(){hideExactFrame();if(viewerMode()==='native')stopNativeStream();if(!undos.length)return;redos.push(JSON.stringify(doc));doc=JSON.parse(undos.pop());if(selected&&!clip(selected))resetSelection();paint();syncLater()}
function redo(){hideExactFrame();if(viewerMode()==='native')stopNativeStream();if(!redos.length)return;undos.push(JSON.stringify(doc));doc=JSON.parse(redos.pop());if(selected&&!clip(selected))resetSelection();paint();syncLater()}
function currentLength(){return Math.max(0,...view().clips.filter(c=>c.enabled).map(c=>c.start+c.duration),...(view().captions||[]).map(c=>c.start+c.duration))}
function at(c,property,local){const keys=(c.keyframes[property]||[]).slice().sort((a,b)=>a.frame-b.frame);if(!keys.length)return Number(c.properties[property]);if(local<=keys[0].frame)return keys[0].value;if(local>=keys.at(-1).frame)return keys.at(-1).value;for(let i=0;i<keys.length-1;i++){let a=keys[i],b=keys[i+1];if(local>=a.frame&&local<=b.frame){if(a.interpolation==='hold')return a.value;let t=(local-a.frame)/(b.frame-a.frame);if(a.interpolation==='ease')t=t*t*(3-2*t);return a.value+(b.value-a.value)*t}}return 0}
function activeClips(){
 const playhead=view().playhead;const all=view().clips.filter(c=>c.enabled&&!track(c.track).muted&&c.start<=playhead&&playhead<c.start+c.duration);
 const out=[];const children=new Map((doc.sequences||[]).map(s=>[s.id,s]));
 function expand(c,time,parentTrack,path,depth=0){
  if(depth>20)return;
  if(!c.sequence_id){out.push({...c,track:parentTrack,id:path+c.id,start:playhead-time+c.start,source_in:c.source_in,keyframes:c.keyframes||{},properties:c.properties});return}
  const seq=children.get(c.sequence_id);if(!seq)return;
  const parentKind=track(parentTrack)?.kind;
  const local=time-c.start+c.source_in;
  for(const child of seq.clips){
   if(!child.enabled||local<child.start||local>=child.start+child.duration)continue;
   const childTrack=seq.tracks.find(t=>t.id===child.track);
   if(!childTrack||childTrack.muted||childTrack.kind!==parentKind)continue;
   expand(child,local,parentTrack,path+c.id+'-',depth+1)
  }
 }
 for(const c of all){if(c.sequence_id)expand(c,playhead,c.track,'');else out.push(c)}
 return out;
}
function previewSlideOffset(c,local){
 let offset=0;
 for(const fx of (c.effects||[])){
  if(!fx.enabled||!['slide_in','slide_out'].includes(fx.type))continue;
  const count=Math.min(c.duration,fx.params.frames);
  const span=Math.max(1,count-1);
  if(fx.type==='slide_in')offset-=fx.params.distance*(1-Math.max(0,Math.min(1,local/span)));
  else offset+=fx.params.distance*Math.max(0,Math.min(1,(local-(c.duration-count))/span));
 }
 return offset;
}
// Browser preview is intentionally approximate. The FFmpeg renderer is authoritative.
function previewFilter(c,local){
 const result=[`brightness(${Math.max(0,1+at(c,'brightness',local))})`,`contrast(${at(c,'contrast',local)})`,`saturate(${at(c,'saturation',local)})`,`blur(${at(c,'blur',local)}px)`];
 for(const fx of (c.effects||[])){
  if(!fx.enabled)continue;
  if(fx.type==='hue')result.push(`hue-rotate(${fx.params.degrees}deg)`);
  if(fx.type==='monochrome')result.push('grayscale(1)');
  if(fx.type==='invert')result.push('invert(1)');
  if(fx.type==='gaussian_blur')result.push(`blur(${fx.params.radius}px)`);
 }
 return result.join(' ');
}
const effectsUI=new MeridianEffectsUI({
 catalog:()=>effectCatalog, selectedClip:()=>clip(selected),findClip:id=>clip(id),
 trackKind:id=>track(id)?.kind,id:uid,edit,toast,addTransition:()=>createTransition().catch(e=>toast(e.message,true)),playhead:()=>view().playhead,inspect:()=>setTab('right','inspector')
});
function showPreview(){const current=activeClips();let visible=0;const videoOrder=view().tracks.filter(t=>t.kind==='video').slice().reverse().map(t=>t.id);const videoClips=current.filter(c=>videoOrder.includes(c.track)).sort((a,b)=>videoOrder.indexOf(a.track)-videoOrder.indexOf(b.track));const keep=new Set();for(const c of videoClips){if(!asset(c.asset)?.video)continue;keep.add(c.id);visible++;let entry=mediaTags.get(c.id);if(!entry){const wrapper=document.createElement('div');wrapper.className='preview-layer';const isStill=/\.(png|jpe?g|webp)$/i.test(asset(c.asset)?.path||'');const el=document.createElement(isStill?'img':'video');el.preload='auto';el.playsInline=true;el.muted=true;el.src='/api/media/'+c.asset;wrapper.append(el);$('#preview-layers').append(wrapper);entry={wrapper,el};mediaTags.set(c.id,entry);el.addEventListener(isStill?'load':'loadeddata',()=>{if(viewerMode()==='gpu'&&!play)showPreview()},{once:true})}const {wrapper,el}=entry;wrapper.style.zIndex=videoOrder.indexOf(c.track)+1;const local=view().playhead-c.start,sourceTime=(c.source_in+local)/fps();if(typeof el.currentTime==='number'&&Math.abs(el.currentTime-sourceTime)>.11&&Number.isFinite(sourceTime)){try{el.currentTime=sourceTime}catch(_){}}const x=at(c,'x',local)+previewSlideOffset(c,local),y=at(c,'y',local),scale=at(c,'scale',local),angle=at(c,'rotation',local),alpha=at(c,'opacity',local);el.style.transform=`translate(${x/Math.max(1,doc.width)*100}%,${y/Math.max(1,doc.height)*100}%) scale(${scale}) rotate(${angle}deg)`;el.style.opacity=String(alpha);el.style.filter=previewFilter(c,local);if(typeof el.play==='function'){if(play&&el.paused)el.play().catch(()=>{});if(!play&&!el.paused)el.pause()}}
for(const [id,entry] of mediaTags){if(!keep.has(id)){entry.el.pause?.();entry.wrapper.remove();mediaTags.delete(id)}}
// Audio is sourced exclusively from audio tracks to prevent double playback.
const audible=current.filter(c=>track(c.track).kind==='audio'&&asset(c.asset)?.audio);const heard=new Set();for(const c of audible){heard.add(c.id);let el=audioTags.get(c.id);if(!el){el=document.createElement('audio');el.src='/api/media/'+c.asset;el.preload='auto';audioTags.set(c.id,el);transport.route(el)}let t=(c.source_in+view().playhead-c.start)/fps();if(Math.abs(el.currentTime-t)>.12&&Number.isFinite(t))try{el.currentTime=t}catch(_){}el.volume=Math.max(0,Math.min(1,at(c,'volume',view().playhead-c.start)));if(typeof el.play==='function'){if(play&&el.paused)el.play().catch(()=>{});if(!play&&!el.paused)el.pause()}}
for(const [id,el] of audioTags)if(!heard.has(id)){el.pause();transport.unroute(el);audioTags.delete(id)}$('#no-preview').classList.toggle('hidden',visible>0);const subtitle=(view().captions||[]).find(c=>c.start<=view().playhead&&view().playhead<c.start+c.duration);const overlay=$('#caption-overlay');overlay.textContent=subtitle?.text||'';overlay.classList.toggle('hidden',!subtitle);updateGPU(videoClips);if(viewerMode()==='native'){if(nativeFrameClient.url)nativeFrameClient.request(view().playhead);else if(!nativeStarting)startNativeStream()}}
function seek(value,paintAll=false,fromTick=false){
 hideExactFrame();view().playhead=Math.max(0,Math.min(Math.round(value),Math.max(currentLength(),fps()*10)));
 if(play&&!fromTick)transport.reanchor(view().playhead);
 $('#current-tc').textContent=frameToText(view().playhead);
 $('#timeline-tc').textContent=frameToText(view().playhead);
 $('#playhead-line').style.left=(view().playhead/fps()*zoom)+'px';
 if(paintAll){paintInspector();paintGraph()}
 showPreview();
}
async function togglePlay(){
 hideExactFrame();
 if(!play)sourceMonitor.pause();
 if(play){play=false;transport.pause();$('#play').textContent='▶';showPreview();return}
 if(view().playhead>=currentLength()&&currentLength())seek(0);
 const start=view().playhead;play=true;$('#play').textContent='❚❚';
 try{
  await transport.start(start,fps());
  if(!play)return;
  for(const el of audioTags.values())transport.route(el);
  showPreview();requestAnimationFrame(tick);
 }catch(error){play=false;$('#play').textContent='▶';toast('Playback clock unavailable: '+error.message,true)}
}
function tick(){
 if(!play)return;
 const next=transport.frame();
 if(next>=currentLength()){seek(currentLength(),false,true);togglePlay();return}
 if(next!==view().playhead)seek(next,true,true);
 requestAnimationFrame(tick);
}
function paintMedia(){const q=$('#media-search').value.toLowerCase();const list=$('#media-list');list.replaceChildren();for(const m of doc.media){if(!m.name.toLowerCase().includes(q))continue;const row=document.createElement('div');row.className='media-row';row.draggable=true;row.title=m.path;row.classList.toggle('media-selected',selectedMediaId===m.id);row.classList.toggle('media-offline',missingMedia.has(m.id));row.innerHTML=`<div class="media-icon ${!m.video?'audio':''}">${m.video?'▣':'♫'}</div><div class="media-meta"><strong></strong><span></span></div>`;row.querySelector('strong').textContent=(missingMedia.has(m.id)?'OFFLINE · ':'')+m.name;row.querySelector('span').textContent=`${(m.duration_seconds).toFixed(1)}s  ·  ${m.video?`${m.width} × ${m.height}`:'Audio'}`;row.addEventListener('click',()=>{selectedMediaId=m.id;paintMedia()});row.addEventListener('dblclick',()=>sourceMonitor.open(m.id));row.addEventListener('dragstart',e=>e.dataTransfer.setData('text/meridian-asset',m.id));list.append(row)}$('#project-summary').textContent=`${doc.width} × ${doc.height}\n${fps()} fps\n${doc.media.length} media files\n${view().clips.length} clips`}
async function applyEditorial(action,fields){
 const result=await api('editorial-edit',{project:doc,action,container_id:activeSeqId,...fields});
 snapshot();doc=result.project;selected=result.selected_id||null;selectedIds.clear();
 if(selected)selectedIds.add(selected);hideExactFrame();
 if(viewerMode()==='native')stopNativeStream();paint();syncLater();
 toast('Edit applied: '+action.replaceAll('-',' '));
}
function trackProperties(id){
 const t=track(id);if(!t)return;
 modal('Track properties',`<label>Track name</label><input id="ed-track-name" maxlength="60"><p class="hint">Track ID: ${t.id} · ${t.kind}. Removing a track is only allowed when it is unlocked and empty.</p><button id="ed-remove-track" type="button">Remove empty track</button>`,async()=>applyEditorial('rename-track',{track_id:t.id,name:$('#ed-track-name').value}));
 $('#ed-track-name').value=t.name;
 $('#ed-remove-track').onclick=async()=>{if(!confirm('Remove track '+t.id+'?'))return;try{await applyEditorial('remove-track',{track_id:t.id});$('#modal-shade').classList.add('hidden')}catch(e){toast(e.message,true)}};
}
function selectedForEdit(){const c=clip(selected);if(!c)throw Error('Select a clip in the timeline first');if(track(c.track)?.locked)throw Error('Unlock the selected track first');return c}
function trimDialog(){
 let c;try{c=selectedForEdit()}catch(e){return toast(e.message,true)}
 modal('Precision trim',`<label>Edge</label><select id="ed-edge"><option value="trim-left">In point</option><option value="trim-right">Out point</option></select><label>Absolute cut position · frame</label><input id="ed-boundary" type="number" min="0" step="1" value="${c.start}"><p class="hint">In-point trimming also moves the source in point. Out-point trimming changes the duration. Source handle bounds are checked before applying.</p>`,async()=>applyEditorial($('#ed-edge').value,{clip_id:c.id,frame:Number($('#ed-boundary').value)}));
 $('#ed-edge').onchange=()=>{$('#ed-boundary').value=$('#ed-edge').value==='trim-left'?c.start:c.start+c.duration};
}
function slideDialog(){
 let c;try{c=selectedForEdit()}catch(e){return toast(e.message,true)}
 modal('Slide edit',`<label>Timeline offset · frames</label><input id="ed-delta" type="number" step="1" value="0"><p class="hint">Moves this clip while extending or trimming its immediate neighbors. The outer edit points and selected clip source in/out are preserved.</p>`,async()=>applyEditorial('slide',{clip_id:c.id,delta:Number($('#ed-delta').value)}));
}
function slipDialog(){
 let c;try{c=selectedForEdit()}catch(e){return toast(e.message,true)}
 modal('Slip source inside clip',`<label>Source offset · frames (negative or positive)</label><input id="ed-delta" type="number" step="1" value="0"><p class="hint">Timeline position and duration stay unchanged. This shifts the source range while preserving effect and clip animation timing.</p>`,async()=>applyEditorial('slip',{clip_id:c.id,delta:Number($('#ed-delta').value)}));
}
function rollDialog(){
 const ids=[...selectedIds];if(selected&&!ids.includes(selected))ids.push(selected);
 if(ids.length!==2)return toast('Select exactly two touching clips using Shift+click',true);
 const pair=ids.map(clip).sort((a,b)=>a.start-b.start);
 const [a,b]=pair;if(!a||!b||a.track!==b.track||a.start+a.duration!==b.start)return toast('Roll requires two touching clips on the same track',true);
 modal('Rolling trim',`<label>New shared cut · absolute frame</label><input id="ed-boundary" type="number" min="0" step="1" value="${b.start}"><p class="hint">Changes both source boundaries while preserving both outer clip edges. The source must have sufficient handles.</p>`,async()=>applyEditorial('roll',{outgoing:a.id,incoming:b.id,frame:Number($('#ed-boundary').value)}));
}
function threePointDialog(action='overwrite'){
 const assetId=selectedMediaId||clip(selected)?.asset;
 const media=asset(assetId);if(!media)return toast('Select a source in Media first',true);
 const kinds=view().tracks.filter(t=>!t.locked&&(t.kind==='video'?media.video:media.audio));
 if(!kinds.length)return toast('No unlocked track accepts this media',true);
 const max=Math.max(1,Math.round(media.duration_seconds*fps()));
 modal(action==='insert'?'Three-point insert':'Three-point overwrite',`<label>Destination track</label><select id="ed-track"></select><label>Timeline in · frame</label><input id="ed-start" type="number" min="0" step="1" value="${view().playhead}"><label>Source in · frame</label><input id="ed-source" type="number" min="0" step="1" value="0"><label>Source duration · frames (max ${max})</label><input id="ed-duration" type="number" min="1" step="1" value="${max}"><p class="hint">${action==='insert'?'Ripples all unlocked tracks and subtitles, preserving later sync. Clips crossing the insertion point are split.':'Replaces only the covered range on the selected track without shifting other tracks.'} Original project is preserved if the edit is invalid.</p>`,async()=>applyEditorial(action,{asset:media.id,track:$('#ed-track').value,start:Number($('#ed-start').value),source_in:Number($('#ed-source').value),duration:Number($('#ed-duration').value)}));
 const selector=$('#ed-track');for(const t of kinds){const opt=document.createElement('option');opt.value=t.id;opt.textContent=t.name+' · '+t.kind;selector.append(opt)}
}
function overwriteDialog(){return threePointDialog('overwrite')}
function insertDialog(){return threePointDialog('insert')}
async function relinkSelected(){
 const media=asset(selectedMediaId||clip(selected)?.asset);
 if(!media)return toast('Select a media file first',true);
 let chosen=(await pick('media'))[0];
 if(!chosen)return modal('Relink source media',`<label>Replacement file path</label><input id="relink-path" placeholder="Absolute path to the replacement file"><p class="hint">The new file must contain the required streams and be long enough for every use in this project.</p>`,async()=>relinkTo(media.id,$('#relink-path').value));
 return relinkTo(media.id,chosen);
}
async function relinkTo(assetId,path){
 if(!path)throw Error('Choose a replacement file');
 const result=await api('relink-media',{project:doc,asset_id:assetId,path});snapshot();doc=result.project;
 missingMedia.delete(assetId);for(const {el,wrapper}of mediaTags.values()){el.pause?.();wrapper.remove()}mediaTags.clear();
 for(const el of audioTags.values()){el.pause();transport.unroute(el)}audioTags.clear();
 hideExactFrame();if(viewerMode()==='native')stopNativeStream();paint();syncLater();toast('Source reconnected');
}
function insertAsset(id,trackId=null,start=null){let m=asset(id);if(!m)return;const desired=trackId||(m.video?'V1':'A1');const t=track(desired);if(!t||t.locked)return;const begin=Math.max(0,start??view().playhead);const item={id:uid(),asset:id,track:desired,start:begin,source_in:0,duration:Math.max(1,Math.round(m.duration_seconds*fps())),properties:{...defaults},keyframes:{},effects:[],masks:[],enabled:true};
if(t.kind==='video'&&!m.video){toast('Choose an audio track for this asset',true);return}if(t.kind==='audio'&&!m.audio){toast('No audio stream found in that media',true);return}
edit(()=>{view().clips.push(item);selected=item.id;if(m.video&&m.audio&&desired==='V1'&&track('A1'))view().clips.push({...structuredClone(item),id:uid(),track:'A1'})});toast('Added '+m.name)}
function paintTimeline(){const duration=Math.max(currentLength(),fps()*35);const width=Math.max(1300,duration/fps()*zoom+400);$('#timeline-canvas').style.width=width+'px';let ruler=$('#ruler');ruler.replaceChildren();const step=zoom>110?1:zoom>55?2:5;for(let sec=0;sec<=width/zoom;sec+=step){const tick=document.createElement('div');tick.className='tick';tick.style.left=(sec*zoom)+'px';tick.textContent=frameToText(sec*fps());ruler.append(tick)}const headers=$('#track-headers'), content=$('#track-content');headers.replaceChildren();content.replaceChildren();if((view().captions||[]).length){const head=document.createElement('div');head.className='caption-head';head.textContent='CC  Subtitles';headers.append(head);const lane=document.createElement('div');lane.className='caption-lane';for(const c of view().captions){const block=document.createElement('div');block.className='caption-block';block.textContent=c.text;block.title=c.text;block.style.left=(c.start/fps()*zoom)+'px';block.style.width=Math.max(4,c.duration/fps()*zoom)+'px';block.onclick=()=>{seek(c.start,true);setTab('left','captions')};lane.append(block)}content.append(lane)}for(const t of view().tracks){const head=document.createElement('div');head.className='track-header '+t.kind;head.innerHTML=`<span class="track-name"></span><div class="track-buttons"><button class="mute" title="Mute track">${t.muted?'MUTE':'M'}</button><button class="lock" title="Lock track">${t.locked?'LOCK':'L'}</button></div>`;head.querySelector('.track-name').textContent=t.name;head.querySelector('.track-name').ondblclick=()=>trackProperties(t.id);head.querySelector('.mute').classList.toggle('active',t.muted);head.querySelector('.lock').classList.toggle('active',t.locked);head.querySelector('.mute').onclick=()=>edit(()=>t.muted=!t.muted);head.querySelector('.lock').onclick=()=>edit(()=>t.locked=!t.locked);headers.append(head);const lane=document.createElement('div');lane.className='track-lane '+t.kind;lane.dataset.track=t.id;lane.addEventListener('dragover',e=>{e.preventDefault();e.dataTransfer.dropEffect='copy'});lane.addEventListener('drop',e=>{e.preventDefault();const id=e.dataTransfer.getData('text/meridian-asset');if(id){const box=lane.getBoundingClientRect();insertAsset(id,t.id,Math.round((e.clientX-box.left+$('#timeline-scroll').scrollLeft)/zoom*fps()))}});lane.addEventListener('click',e=>{if(e.target===lane)seek(Math.round(e.offsetX/zoom*fps()),true)});for(const c of view().clips.filter(c=>c.track===t.id)){const m=asset(c.asset);const item=document.createElement('div');item.className='clip '+t.kind+(t.kind==='video'?` ${t.id}`:'')+(selectedIds.has(c.id)||selected===c.id?' selected':'')+(t.locked?' locked':'');item.style.left=(c.start/fps()*zoom)+'px';item.style.width=Math.max(3,c.duration/fps()*zoom)+'px';item.dataset.clip=c.id;item.innerHTML='<div class="trim left" data-resize="left"></div><span class="clip-label"></span><div class="clip-duration"></div><div class="trim right" data-resize="right"></div>';item.querySelector('.clip-label').textContent=c.sequence_id?'▣ '+((doc.sequences||[]).find(q=>q.id===c.sequence_id)?.name||'Nested'):m?.name||'Missing';if(c.sequence_id)item.classList.add('nested-clip');
 const incomingTransition=(view().transitions||[]).find(x=>x.incoming===c.id);
 if(incomingTransition){const marker=document.createElement('span');marker.className='clip-transition';
  marker.style.left=((incomingTransition.start-c.start)/fps()*zoom)+'px';
  marker.style.width=(incomingTransition.duration/fps()*zoom)+'px';
  marker.title=incomingTransition.type.replaceAll('_',' ')+' · '+incomingTransition.duration+' frames';
  marker.onclick=e=>{e.stopPropagation();editTransition(incomingTransition)};
  marker.onpointerdown=e=>e.stopPropagation();
  item.append(marker)}item.addEventListener('dblclick',e=>{e.stopPropagation();if(c.sequence_id)openNest(c.sequence_id);else if(asset(c.asset)){sourceMonitor.open(c.asset);sourceMonitor.move(c.source_in)}});item.querySelector('.clip-duration').textContent=frameToText(c.duration);item.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('text/meridian-effect')){e.preventDefault();e.dataTransfer.dropEffect='copy'}});item.addEventListener('drop',e=>{const type=e.dataTransfer.getData('text/meridian-effect');if(type){e.preventDefault();e.stopPropagation();effectsUI.apply(type,c.id)}});item.addEventListener('pointerdown',e=>dragClip(e,c,item,t));item.addEventListener('click',e=>{e.stopPropagation();if(tool==='razor'){splitSelected(c.id,view().playhead);return}if(e.shiftKey||e.ctrlKey||e.metaKey){if(selectedIds.has(c.id))selectedIds.delete(c.id);else selectedIds.add(c.id)}else{selectedIds.clear();selectedIds.add(c.id)}selected=c.id;paintTimeline();paintInspector();paintGraph()});for(const keys of Object.values(c.keyframes)){for(const k of keys){const marker=document.createElement('span');marker.className='clip-marker';marker.style.left=Math.round(k.frame/c.duration*100)+'%';item.append(marker)}}lane.append(item)}content.append(lane)}seek(view().playhead);$('#count-label').textContent=`${view().clips.length} clips · ${(view().captions||[]).length} subtitles · ${doc.media.length} media`;$('#duration-tc').textContent=frameToText(currentLength())}
function repairTransitions(timeline){
 const known=new Map(timeline.clips.map(c=>[c.id,c]));
 timeline.transitions=(timeline.transitions||[]).filter(effect=>{
  const a=known.get(effect.outgoing),b=known.get(effect.incoming);
  if(!a||!b||a.track!==b.track||a.start>=b.start)return false;
  const overlap=Math.min(a.start+a.duration,b.start+b.duration)-b.start;
  if(overlap<2)return false;
  effect.start=b.start;effect.duration=Math.min(effect.duration,overlap);return true;
 });
}
function dragClip(e,c,item,t){if(e.button!==0||t.locked)return;if(c.sequence_id&&e.detail>=2){e.preventDefault();e.stopPropagation();openNest(c.sequence_id);return;}e.stopPropagation();e.preventDefault();selected=c.id;if(!e.shiftKey&&!e.ctrlKey&&!e.metaKey){selectedIds.clear();selectedIds.add(c.id)}if(tool==='razor'){splitSelected(c.id,view().playhead);return}let origin=e.clientX,initial=c.start,inPoint=c.source_in,initialDuration=c.duration,which=e.target.dataset.resize||'move',changed=false;let prior=copy(doc);const maxDuration=Math.max(1,(c.sequence_id?((doc.sequences||[]).find(q=>q.id===c.sequence_id)?.duration||c.duration):Math.round(asset(c.asset).duration_seconds*fps())));const pixelsToFrames=dx=>Math.round(dx/zoom*fps());item.setPointerCapture(e.pointerId);item.addEventListener('pointermove',move);item.addEventListener('pointerup',finish,{once:true});item.addEventListener('pointercancel',finish,{once:true});function quant(v){return snap?Math.round(v/Math.max(1,Math.round(fps()/2)))*Math.max(1,Math.round(fps()/2)):v}function move(ev){let offset=pixelsToFrames(ev.clientX-origin);if(Math.abs(ev.clientX-origin)<3&&!changed)return;changed=true;if(which==='move')c.start=Math.max(0,quant(initial+offset));else if(which==='left'){let n=Math.max(-inPoint,Math.min(offset,initialDuration-1));let pos=Math.max(0,initial+n);n=pos-initial;c.start=pos;c.source_in=inPoint+n;c.duration=initialDuration-n}else{c.duration=Math.max(1,Math.min(maxDuration-inPoint,initialDuration+offset))}/* Keyframe rebasing is performed by src/editorial.py on commit. */item.style.left=(c.start/fps()*zoom)+'px';item.style.width=(c.duration/fps()*zoom)+'px'}function finish(){item.removeEventListener('pointermove',move);if(changed&&which!=='move'){const boundary=which==='left'?c.start:c.start+c.duration;doc=prior;applyEditorial(which==='left'?'trim-left':'trim-right',{clip_id:c.id,frame:boundary}).catch(e=>{paint();toast(e.message,true)});return}if(changed){repairTransitions(view());undos.push(JSON.stringify(prior));redos=[];if(viewerMode()==='native')stopNativeStream();syncLater()}paint()}}
async function timelineOperation(action,id=selected,frame=view().playhead){
 if(!id)return toast('Select a clip first',true);
 const original=clip(id);
 if(!original||track(original.track)?.locked)return toast('Clip unavailable or track locked',true);
 const result=await api('timeline-edit',{project:doc,action,clip_id:id,frame,container_id:activeSeqId});
 snapshot();doc=result.project;if(viewerMode()==='native')stopNativeStream();resetSelection();
 if(result.selected_id){selected=result.selected_id;selectedIds.add(selected)}
 paint();syncLater();
}
function splitSelected(id=selected,frame=view().playhead){return timelineOperation('split',id,frame).catch(e=>toast(e.message,true))}
function duplicateSelected(){return timelineOperation('duplicate').catch(e=>toast(e.message,true))}
function rippleSelected(){return timelineOperation('ripple-delete').catch(e=>toast(e.message,true))}
function delSelected(){const ids=new Set(selectedIds);if(selected)ids.add(selected);if(!ids.size)return;edit(()=>{view().clips=view().clips.filter(c=>!ids.has(c.id));view().transitions=(view().transitions||[]).filter(t=>!ids.has(t.incoming)&&!ids.has(t.outgoing));resetSelection()})}
function editTransition(item){
 const timeline=view();const outgoing=timeline.clips.find(c=>c.id===item.outgoing);
 const incoming=timeline.clips.find(c=>c.id===item.incoming);
 if(!outgoing||!incoming)return toast('Transition references missing clips',true);
 const max=Math.min(outgoing.start+outgoing.duration,incoming.start+incoming.duration)-incoming.start;
 const audio=track(outgoing.track).kind==='audio';
 const choices=audio?'<option value="audio_crossfade">Audio Crossfade</option>':[
   ['cross_dissolve','Cross Dissolve'],['wipe_left','Wipe Left'],['wipe_right','Wipe Right'],
   ['wipe_up','Wipe Up'],['wipe_down','Wipe Down'],['soft_wipe_left','Soft Wipe Left'],
   ['soft_wipe_right','Soft Wipe Right'],['soft_wipe_up','Soft Wipe Up'],
   ['soft_wipe_down','Soft Wipe Down'],['diagonal_tl','Diagonal TL'],
   ['diagonal_br','Diagonal BR'],['circle_reveal','Circle Reveal']
  ].map(([type,label])=>`<option value="${type}">${label}</option>`).join('');
 modal('Edit transition',`<label>Transition</label><select id="transition-type">${choices}</select><label>Duration (2–${max} frames)</label><input type="number" id="transition-frames" min="2" max="${max}" value="${item.duration}"><button type="button" id="transition-remove" class="wide">Remove transition</button>`,()=>{
  const frames=Number($('#transition-frames').value);
  if(!Number.isInteger(frames)||frames<2||frames>max)throw Error('Transition duration must fit inside overlap');
  edit(()=>{item.type=$('#transition-type').value;item.duration=frames});
 });
 $('#transition-type').value=item.type;
 $('#transition-remove').onclick=()=>{edit(()=>{timeline.transitions=timeline.transitions.filter(t=>t.id!==item.id)});$('#modal-shade').classList.add('hidden')};
}
function createQuickTitle(initialFontId=null){
 const installed=freeFontData.filter(f=>f.installed_files?.length);
 const available=installed.flatMap(f=>f.installed_files.map(variant=>({id:f.id,variant,name:f.name+' · '+variant})));
 // Construct the select using DOM rather than interpolating untrusted filenames.
 modal('Create title on the timeline',`<label>Title text (up to six lines)</label><textarea id="title-text" rows="3" placeholder="YOUR TITLE"></textarea><label>Font size (18–260)</label><input type="number" id="title-size" value="96" min="18" max="260"><label>Text color</label><input type="color" id="title-color" value="#ffffff"><label>DaFont fonts imported to Meridian</label><select id="title-font-select"></select><label>Other local font (.ttf / .otf path, optional)</label><input id="title-font-path" placeholder="Only when not using the font above"><label>Duration in seconds (up to 5)</label><input type="number" id="title-duration" value="4" min="0.1" max="5" step="0.1"><p class="hint">Import an eligible ZIP in Quick Edit → DaFont Fonts. Font files remain in Meridian's private library, without global installation. Title is currently rendered to a PNG layer.</p>`,async()=>{
  const text=$('#title-text').value.trim();const size=Number($('#title-size').value);
  const duration=Number($('#title-duration').value);
  if(!text||!Number.isInteger(size)||!Number.isFinite(duration)||duration<=0||duration>5)throw Error('Check title text, size and duration');
  const target=view().tracks.find(t=>t.kind==='video'&&t.id==='V2'&&!t.locked)||view().tracks.find(t=>t.kind==='video'&&!t.locked);
  if(!target)throw Error('Unlock a video track before adding a title');
  const fontEntry=available[Number($('#title-font-select').value)-1]||null;
  const res=await api('create-title',{project:doc,text,size,color:$('#title-color').value,
    font_id:fontEntry?.id||null,font_variant:fontEntry?.variant||null,
    font_path:fontEntry?'':$('#title-font-path').value.trim(),duration});
  const media=res.media;
  const item={id:uid(),asset:media.id,track:target.id,start:view().playhead,source_in:0,
    duration:Math.max(2,Math.round(duration*fps())),properties:{...defaults},keyframes:{},effects:[],masks:[],enabled:true};
  edit(()=>{doc.media.push(media);view().clips.push(item);selected=item.id;selectedIds=new Set([item.id])});
  toast('Title layer added · animate it from Quick Edit');
 });
 const choice=$('#title-font-select');choice.add(new Option('Default typeface','0'));
 available.forEach((f,index)=>choice.add(new Option(f.name,String(index+1))));
 const chosen=available.findIndex(f=>f.id===initialFontId);
 if(chosen>=0)choice.value=String(chosen+1);
}
async function importDaFont(family){
 const picker=document.createElement('input');picker.type='file';picker.accept='.zip,application/zip';
 picker.onchange=async()=>{
  const file=picker.files?.[0];if(!file)return;
  if(file.size>7*1024*1024)return toast('ZIP exceeds 7 MB',true);
  try{
   const data=new Uint8Array(await file.arrayBuffer());
   let encoded='';const step=24*1024;
   for(let offset=0;offset<data.length;offset+=step){
    encoded+=btoa(String.fromCharCode(...data.subarray(offset,offset+step)));
   }
   // Each chunk is divisible by three, therefore no interior Base64 padding.
   const res=await api('import-dafont',{family_id:family.id,archive_base64:encoded});
   freeFontData=res.fonts;quickLibrary.fonts=freeFontData;quickLibrary.paint();
   toast(`${res.imported.name}: ${res.imported.installed_files.length} file(s) imported`);
  }catch(e){toast('Font import failed: '+e.message,true)}
 };
 picker.click();
}
async function applyQuickPreset(presetId){
 const target=clip(selected);
 if(!target)return toast('Select a timeline clip before applying a preset',true);
 try{
  const updated=await api('apply-preset',{project:doc,clip_id:target.id,preset_id:presetId,container_id:activeSeqId});
  snapshot();doc=updated.project;hideExactFrame();if(viewerMode()==='native')stopNativeStream();
  paint();syncLater();toast('Preset applied · edit its keyframes and effects in Inspector');
 }catch(error){toast(error.message,true)}
}
async function addQuickTransition(type){
 const ids=[...selectedIds];if(selected&&!ids.includes(selected))ids.push(selected);
 if(ids.length!==2)return toast('Select exactly two overlapping clips with Shift+click',true);
 const [a,b]=ids.map(clip);if(!a||!b||a.track!==b.track)return toast('Both clips must share a track',true);
 const [outgoing,incoming]=a.start<=b.start?[a,b]:[b,a];
 const overlap=Math.min(outgoing.start+outgoing.duration,incoming.start+incoming.duration)-incoming.start;
 if(overlap<2)return toast('Overlap the clips by at least two frames first',true);
 try{
  const result=await api('add-transition',{project:doc,outgoing:outgoing.id,incoming:incoming.id,type,
    duration:Math.min(15,overlap),container_id:activeSeqId});
  snapshot();doc=result.project;hideExactFrame();if(viewerMode()==='native')stopNativeStream();paint();syncLater();
  toast('Added '+type.replaceAll('_',' ')+' · FFmpeg Stable supports all Quick Edit transitions');
 }catch(error){toast(error.message,true)}
}
async function createTransition(){
 const ids=[...selectedIds];if(selected&&!ids.includes(selected))ids.push(selected);
 if(ids.length!==2)return toast('Select exactly two clips (Shift+click)',true);
 const [a,b]=ids.map(clip);
 if(!a||!b||a.track!==b.track)return toast('Select two clips on the same track',true);
 const [outgoing,incoming]=a.start<=b.start?[a,b]:[b,a];
 const overlap=Math.min(outgoing.start+outgoing.duration,incoming.start+incoming.duration)-incoming.start;
 const audio=track(outgoing.track).kind==='audio';
 if(overlap<2)return toast('Overlap the clips by at least two frames first',true);
 modal('Transition between clips',`<label>Transition</label><select id="transition-type">${audio?'<option value="audio_crossfade">Audio Crossfade</option>':'<option value="cross_dissolve">Cross Dissolve</option><option value="wipe_left">Wipe Left</option>'}</select><label>Frames (maximum ${overlap})</label><input type="number" id="transition-frames" min="2" max="${overlap}" value="${Math.min(12,overlap)}"><p class="hint">The transition uses both source clips within their real overlap. No hidden trim handles are synthesized.</p>`,async()=>{
  const duration=Number($('#transition-frames').value);
  const result=await api('add-transition',{project:doc,outgoing:outgoing.id,incoming:incoming.id,type:$('#transition-type').value,duration,container_id:activeSeqId});
  snapshot();doc=result.project;if(viewerMode()==='native')stopNativeStream();paint();syncLater();toast('Two-source transition added');
 });
}
let exactObjectUrl=null;
function hideExactFrame(){
 const img=$('#exact-frame');if(!img)return;
 img.classList.add('hidden');$('#exact-status').textContent='Fast preview';
 if(exactObjectUrl){URL.revokeObjectURL(exactObjectUrl);exactObjectUrl=null}
}
async function renderExactFrame(){
 if(play)return toast('Pause playback before rendering an accurate frame',true);
 if(view().playhead>=currentLength())return toast('Move the playhead inside the sequence',true);
 const frame=view().playhead;
 const engine=renderEngine();
 if(engine==='native' && doc.captions?.length)return toast('Caption burn-in is only supported by FFmpeg Stable',true);
 const button=$('#exact-preview');button.disabled=true;$('#exact-status').textContent='Rendering…';
 try{
  const response=await fetch('/api/preview-frame',{method:'POST',headers:{'Content-Type':'application/json','X-Meridian-Token':token},body:JSON.stringify({project:doc,frame,container_id:activeSeqId,captions:true,engine})});
  if(!response.ok){const error=await response.json();throw Error(error.error||'Frame render failed')}
  const blob=await response.blob();const url=URL.createObjectURL(blob);
  if(frame!==view().playhead||play){URL.revokeObjectURL(url);return}
  hideExactFrame();exactObjectUrl=url;$('#exact-frame').src=url;$('#exact-frame').classList.remove('hidden');
  $('#exact-status').textContent=(engine==='native'?'C++ CPU':'FFmpeg')+' · frame '+frame;
 }catch(error){hideExactFrame();toast(error.message,true)}finally{button.disabled=false}
}

function props(category){let c=clip(selected),el=$('#'+category+'-controls');el.replaceChildren();if(!c)return;let keys=category==='transform'?['x','y','scale','rotation']:category==='compositing'?['opacity']:category==='color'?['brightness','contrast','saturation','blur']:['volume'];for(const key of keys){const [label,min,max,step]=specs[key],row=document.createElement('div');row.className='property';const local=view().playhead-c.start;const anim=(c.keyframes[key]||[]).some(k=>k.frame===local);row.innerHTML=`<label></label><button class="key-button ${anim?'has-key':''}" title="Add/remove keyframe">◇</button><input type="number" min="${min}" max="${max}" step="${step}">`;row.querySelector('label').textContent=label;let input=row.querySelector('input');input.value=+at(c,key,Math.max(0,local)).toFixed(3);input.onchange=()=>{let v=Number(input.value);if(!Number.isFinite(v))return;v=Math.max(min,Math.min(max,v));edit(()=>{if(c.keyframes[key]?.length&&local>=0&&local<c.duration){let existing=c.keyframes[key].find(k=>k.frame===local);if(existing)existing.value=v;else c.keyframes[key].push({frame:local,value:v,interpolation:'linear'})}else c.properties[key]=v})};row.querySelector('.key-button').onclick=()=>toggleKey(key);el.append(row)}}
function toggleKey(key){const c=clip(selected);if(!c)return;const f=view().playhead-c.start;if(f<0||f>=c.duration){toast('Move playhead inside clip',true);return}edit(()=>{const list=c.keyframes[key]||(c.keyframes[key]=[]);const index=list.findIndex(k=>k.frame===f);if(index!==-1)list.splice(index,1);else list.push({frame:f,value:at(c,key,f),interpolation:'linear'});graphProperty=key})}
const maskUI=new MeridianMaskUI({selectedClip:()=>clip(selected),trackKind:id=>track(id)?.kind,edit,id:uid,toast});
function paintInspector(){const c=clip(selected);$('#inspector-empty').classList.toggle('hidden',!!c);$('#inspector-body').classList.toggle('hidden',!c||mode!=='inspector');$('#animation-body').classList.toggle('hidden',mode!=='animation'||!c);if(!c)return;$('#selected-name').textContent=c.sequence_id?('Nested · '+((doc.sequences||[]).find(q=>q.id===c.sequence_id)?.name||'Sequence')):asset(c.asset)?.name||'Selected clip';['transform','compositing','color','audio'].forEach(props);effectsUI.paintStack();maskUI.paint();$('#reset-transform').onclick=()=>edit(()=>{for(const k of ['x','y','scale','rotation']){c.properties[k]=defaults[k];delete c.keyframes[k]}})}
function paintGraph(){const c=clip(selected);const graph=$('#curve-graph');graph.replaceChildren();if(!c)return;const select=$('#graph-property');if(!select.options.length){for(const [key,[label]]of Object.entries(specs)){const opt=document.createElement('option');opt.value=key;opt.textContent=label;select.append(opt)}}select.value=graphProperty;const keys=(c.keyframes[graphProperty]||[]).slice().sort((a,b)=>a.frame-b.frame);const values=keys.map(k=>k.value),middle=values.length?values.reduce((a,b)=>a+b,0)/values.length:at(c,graphProperty,0),spread=Math.max(.3,Math.max(...values.map(v=>Math.abs(v-middle)),.3)*1.35);const toX=k=>20+260*k.frame/Math.max(1,c.duration-1),toY=v=>85-(v-middle)/spread*60;const ns='http://www.w3.org/2000/svg';function element(tag,attrs){const e=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))e.setAttribute(k,v);graph.append(e);return e}element('line',{x1:0,y1:85,x2:300,y2:85,stroke:'#576678','stroke-dasharray':'3 4'});let points=keys.length?Array.from({length:Math.min(300,c.duration)},(_,i)=>{const f=(c.duration-1)*i/(Math.min(300,c.duration)-1||1);return `${toX({frame:f})},${toY(at(c,graphProperty,f))}`}).join(' '):'';if(points)element('polyline',{points,fill:'none',stroke:'#98c8ff','stroke-width':'2'});for(const k of keys){const circle=element('circle',{cx:toX(k),cy:toY(k.value),r:4,fill:'#f7cb85',stroke:'#1e252e','stroke-width':1});circle.title=`frame ${k.frame}, value ${k.value}`;circle.onclick=()=>{seek(c.start+k.frame,true);$('#keyframe-mode').value=k.interpolation||'linear'};circle.onpointerdown=e=>{e.preventDefault();e.stopPropagation();const before=JSON.stringify(doc),sx=e.clientX,sy=e.clientY,frame=k.frame,val=k.value;const bounds=graph.getBoundingClientRect();let moved=false;const move=ev=>{const dx=(ev.clientX-sx)*300/Math.max(1,bounds.width),dy=(ev.clientY-sy)*170/Math.max(1,bounds.height);const nextFrame=Math.max(0,Math.min(c.duration-1,Math.round(frame+dx/260*(c.duration-1))));const occupied=keys.some(q=>q!==k&&q.frame===nextFrame);if(!occupied)k.frame=nextFrame;k.value=+(val-dy/60*spread).toFixed(4);moved=true;paintGraph()};const finish=()=>{window.removeEventListener('pointermove',move);if(moved){undos.push(before);redos.length=0;if(viewerMode()==='native')stopNativeStream();paintInspector();syncLater()}paintGraph()};window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish,{once:true})}}const t=view().playhead-c.start;element('line',{x1:toX({frame:t}),y1:0,x2:toX({frame:t}),y2:170,stroke:'#f28b78','stroke-width':1});$('#graph-help').textContent=keys.length?`${keys.length} keyframes · property ${graphProperty}. Preview curve uses linear, hold or smoothstep ease.`:'No keyframes for this property. Add one at the playhead.'}
function paint(){if(!doc)return;$('#project-name').textContent=doc.name;const back=$('#nest-back'),path=$('#nest-path');if(back)back.disabled=!activeSeqId;if(path)path.textContent=activeSeqId?('Main / '+((doc.sequences||[]).find(s=>s.id===activeSeqId)?.name||'Nested')):'Main sequence';$('#sequence-indicator').textContent=`${doc.width} × ${doc.height} · ${fps()} fps`;paintMedia();paintTimeline();paintInspector();paintGraph();paintCaptions();sourceMonitor.sync();$('#status').textContent=rendering?'Exporting…':'Ready'}
function setTab(side,which){if(side==='left'){activeTab=which;$$('[data-left]').forEach(b=>b.classList.toggle('active',b.dataset.left===which));$$('.library-body').forEach(el=>el.classList.toggle('hidden',el.id!=='library-'+which))}else{mode=which;$$('[data-right]').forEach(b=>b.classList.toggle('active',b.dataset.right===which));paintInspector()}}
function modal(title,fields,callback){$('#modal-title').textContent=title;$('#modal-content').innerHTML=fields;$('#modal-shade').classList.remove('hidden');$('#modal-confirm').onclick=async()=>{try{let result=await callback();if(result!==false)$('#modal-shade').classList.add('hidden')}catch(e){toast(e.message,true)}};$('#modal-cancel').onclick=()=>$('#modal-shade').classList.add('hidden')}
async function pick(mode){try{return (await api('pick',{mode})).paths}catch(e){toast('Native picker unavailable: '+e.message,true);return []}}
async function importPaths(paths){if(!paths.length)return;let result=await api('import',{paths});if(result.media.length){edit(()=>{const existing=new Set(doc.media.map(m=>m.path));for(const m of result.media){if(!existing.has(m.path))doc.media.push(m)}});toast(`Imported ${result.media.length} file(s)`) }if(result.errors.length)toast(result.errors.map(x=>x.path+': '+x.error).join('\n'),true)}
async function importMedia(){let paths=await pick('media');if(paths.length)return importPaths(paths);modal('Import by full file path',`<label>Local file paths (one per line)</label><textarea id="file-paths" placeholder="C:\\Users\\you\\Videos\\scene.mp4"></textarea>`,()=>importPaths($('#file-paths').value.split(/\r?\n/).map(s=>s.trim().replace(/^"|"$/g,'')).filter(Boolean)))}
async function saveProject(){let path=projectPath;if(!path){path=(await pick('project-save'))[0];if(!path)return modal('Save project',`<label>Absolute path ending in .meridian</label><input id="save-path" placeholder="C:\\Projects\\Edit.meridian">`,async()=>saveAt($('#save-path').value))}await saveAt(path)}
async function saveAt(path){if(!path)throw Error('Choose a path');if(!path.toLowerCase().endsWith('.meridian'))path+='.meridian';const res=await api('save',{project:doc,path});projectPath=res.path;toast('Project saved')}
async function openProject(){const paths=await pick('project-open');if(!paths.length)return modal('Open project',`<label>Absolute path to .meridian</label><input id="open-path" placeholder="C:\\Projects\\Edit.meridian">`,async()=>openAt($('#open-path').value));await openAt(paths[0])}
async function openAt(path){if(!path)throw Error('Choose a path');if(viewerMode()==='native')stopNativeStream();const res=await api('open',{path});for(const {el,wrapper}of mediaTags.values()){el.pause?.();wrapper.remove()}mediaTags.clear();for(const el of audioTags.values()){el.pause();transport.unroute(el)}audioTags.clear();sourceMonitor.reset();doc=res.project;projectPath=res.path;missingMedia=new Set(res.missing_media||[]);selectedMediaId=null;activeSeqId=null;nestedTrail=[];resetSelection();undos=[];redos=[];paint();toast('Project loaded')}
function renderEngine(){return $('#render-engine')?.value||'ffmpeg'}
function viewerMode(){return $('#viewer-mode')?.value||'browser'}
function stopNativeStream(){
 nativeStreamSerial++;nativeStarting=false;
 nativeFrameClient.cancel();
 const image=$('#native-frame');image.removeAttribute('src');image.classList.add('hidden');
 if(nativeImageURL){URL.revokeObjectURL(nativeImageURL);nativeImageURL=null}
 if(nativePendingImageURL){URL.revokeObjectURL(nativePendingImageURL);nativePendingImageURL=null}
 nativeStopPromise=api('native-preview-stop',{}).catch(()=>{});
}
async function startNativeStream(){
 if(!nativeReady||viewerMode()!=='native'||nativeStarting)return;
 nativeStarting=true;
 const serial=++nativeStreamSerial;
 try{
  await nativeStopPromise;
  if(serial!==nativeStreamSerial||viewerMode()!=='native')return;
  const result=await api('native-preview-start',{project:doc,container_id:activeSeqId});
  if(serial!==nativeStreamSerial||viewerMode()!=='native')return;
  nativeFrameClient.open(result.url);
  nativeFrameClient.request(view().playhead);
  $('#exact-status').textContent='C++ native · frame-addressed cache';
 }catch(e){if(serial===nativeStreamSerial){$('#exact-status').textContent='Native preview error';toast(e.message,true)}}
 finally{if(serial===nativeStreamSerial)nativeStarting=false}
}
function updateGPU(videoClips){
 const mode=viewerMode();const monitor=$('#monitor');
 monitor.classList.toggle('viewer-gpu',mode==='gpu');
 monitor.classList.toggle('viewer-native',mode==='native');
 $('#gpu-canvas').classList.toggle('hidden',mode!=='gpu');
 if(mode!=='gpu')return;
 if(!gpuPreview||gpuPreview.lost){
  try{gpuPreview=new MeridianGPUPreview($('#gpu-canvas'))}
  catch(error){$('#viewer-mode').value='browser';$('#gpu-canvas').classList.add('hidden');monitor.classList.remove('viewer-gpu');toast(error.message,true);return;}
 }
 const transitions=new Map((view().transitions||[]).filter(t=>t.type==='cross_dissolve'||t.type==='wipe_left').map(t=>[t.incoming,t]));
 const layers=videoClips.map(c=>{
  const element=mediaTags.get(c.id)?.el;
  if(!element)return null;
  const local=view().playhead-c.start;
  const t=transitions.get(c.id);
  const inside=t&&t.start<=view().playhead&&view().playhead<t.start+t.duration;
  return {id:c.id,video:element,x:at(c,'x',local)+previewSlideOffset(c,local),y:at(c,'y',local),
   scale:at(c,'scale',local),angle:at(c,'rotation',local),alpha:at(c,'opacity',local),
   brightness:at(c,'brightness',local),contrast:at(c,'contrast',local),saturation:at(c,'saturation',local),
   transition:inside?(t.type==='cross_dissolve'?1:2):0,
   progress:inside?(view().playhead-t.start)/Math.max(1,t.duration-1):1};
 }).filter(Boolean);
 try{
  gpuPreview.draw(layers,doc.width,doc.height);
  $('#exact-status').textContent='WebGL2 · GPU preview';
 }catch(e){toast('GPU preview unavailable: '+e.message,true);$('#viewer-mode').value='browser';monitor.classList.remove('viewer-gpu');$('#gpu-canvas').classList.add('hidden')}
}

async function exportProject(){if(!doc.clips.length)return toast('Add clips to export',true);let path=(await pick('export'))[0];if(!path){return modal('Export MP4',`<label>Absolute output path</label><input id="export-path" placeholder="C:\\Exports\\final.mp4"><label>Quality</label><select id="export-quality"><option value="high">High (CRF 18)</option><option value="draft">Draft (CRF 25)</option></select><label class="export-option"><input id="export-burn-captions" type="checkbox" checked> Burn captions into the video (if present)</label><p class="hint">Selected render engine: ${renderEngine()}. Native C++ CPU is experimental; use FFmpeg for captions and maximum compatibility.</p>`,async()=>startExport($('#export-path').value,$('#export-quality').value,$('#export-burn-captions').checked))}await startExport(path,'high',true)}
async function startExport(path,preset,burn_captions=true){if(renderEngine().startsWith('native') && doc.media.some(m=>/\.(png|jpe?g|webp)$/i.test(m.path)))throw Error('Title graphics and still images require FFmpeg Stable');if(renderEngine().startsWith('native') && doc.transitions?.some(t=>!['cross_dissolve','wipe_left','audio_crossfade'].includes(t.type)))throw Error('Extended transitions require FFmpeg Stable for accurate export');if(renderEngine().startsWith('native') && burn_captions && doc.captions?.length)throw Error('Use FFmpeg Stable for burned captions');if(!path)throw Error('Choose an output path');if(!path.toLowerCase().endsWith('.mp4'))path+='.mp4';await api('export',{project:doc,path,preset,burn_captions,engine:renderEngine()});rendering=true;$('#status').textContent='Exporting…';toast('Export started');pollExport()}
async function pollExport(){while(rendering){await new Promise(r=>setTimeout(r,1200));try{const status=await(await fetch('/api/export-status')).json();if(status.state==='working')continue;rendering=false;$('#status').textContent=status.state==='done'?'Export complete':'Export error';toast(status.state==='done'?'Saved MP4 to '+status.path:status.message,true&&status.state==='error')}catch(e){rendering=false;toast(e.message,true)}}}
function settings(){modal('Sequence settings',`<label>Project name</label><input id="seq-name" value="${doc.name.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;')}"><label>Size</label><select id="seq-size"><option value="1920x1080">1920 × 1080</option><option value="1280x720">1280 × 720</option><option value="2560x1440">2560 × 1440</option><option value="3840x2160">3840 × 2160</option></select><label>Frame rate</label><select id="seq-fps">${[24,25,30,50,60].map(r=>`<option value="${r}">${r} fps</option>`).join('')}</select><p class="hint">Changing the frame rate in an existing sequence changes the interpretation of clip positions. Set this before editing.</p>`,()=>{let [w,h]=$(`#seq-size`).value.split('x').map(Number),r=Number($('#seq-fps').value);if(view().clips.length&&r!==doc.fps)throw Error('Set frame rate before adding clips. Existing timelines cannot be retimed yet.');edit(()=>{doc.name=$('#seq-name').value||'Untitled';doc.width=w;doc.height=h;doc.fps=r})});$('#seq-size').value=`${doc.width}x${doc.height}`;$('#seq-fps').value=String(fps())}

// Local workspace arrangements: saved separately from project files.
const layoutKey='meridian-workspace-layout-v1';
const layoutPresets={
 editing:{order:['library','viewer','inspector'],left:23,right:24,timeline:380},
 effects:{order:['library','viewer','inspector'],left:27,right:32,timeline:460},
 color:{order:['library','viewer','inspector'],left:18,right:34,timeline:295},
 audio:{order:['library','viewer','inspector'],left:18,right:24,timeline:500},
 captions:{order:['library','viewer','inspector'],left:32,right:24,timeline:330}
};
let workspaceName='editing';
let paneOrder=['library','viewer','inspector'];
let dockLeft=23,dockRight=24,timelineHeight=380;
function bound(v,min,max){return Math.max(min,Math.min(max,v))}
function applyLayout(config){
 const order=config.order||paneOrder;
 if(order.length!==3||new Set(order).size!==3||!order.every(n=>['library','viewer','inspector'].includes(n)))return;
 paneOrder=[...order];dockLeft=bound(Number(config.left)||23,12,40);dockRight=bound(Number(config.right)||24,12,40);timelineHeight=bound(Number(config.timeline)||380,200,Math.max(200,window.innerHeight-300));
 const zone=$('#dock-zone');const panes=new Map($$('[data-pane]').map(el=>[el.dataset.pane,el]));const splitters=$$('.dock-divider');
 zone.replaceChildren(panes.get(order[0]),splitters[0],panes.get(order[1]),splitters[1],panes.get(order[2]));
 document.documentElement.style.setProperty('--dock-left',dockLeft+'%');document.documentElement.style.setProperty('--dock-right',dockRight+'%');document.documentElement.style.setProperty('--timeline-height',timelineHeight+'px');
}
function workspaceSet(name){workspaceName=name;applyLayout(layoutPresets[name]||layoutPresets.editing);$('#workspace-preset').value=name;if(name==='effects'){setTab('left','effects');setTab('right','animation')}else if(name==='editing'){setTab('left','media');setTab('right','inspector')}else if(name==='color'){setTab('right','inspector')}else if(name==='captions'){setTab('left','captions')}}
async function saveWorkspace(){try{const layout={order:paneOrder,left:dockLeft,right:dockRight,timeline:timelineHeight};await api('workspace',{layout});try{localStorage.setItem(layoutKey,JSON.stringify(layout))}catch(_){}workspaceName='custom';$('#workspace-preset').value='custom';toast('Workspace saved on this computer')}catch(err){toast('Could not save layout: '+err.message,true)}}
async function initWorkspaces(){
 $('#workspace-preset').onchange=e=>{if(e.target.value==='custom'){try{const stored=JSON.parse(localStorage.getItem(layoutKey));if(stored){applyLayout(stored);workspaceName='custom'}else workspaceSet('editing')}catch(_){workspaceSet('editing')}}else workspaceSet(e.target.value)};
 $('#workspace-save').onclick=saveWorkspace;
 $('#workspace-reset').onclick=()=>{workspaceSet('editing');toast('Editing layout restored. Click Save layout to persist the change.')};
 const stored=await(async()=>{try{const r=await fetch('/api/workspace');const d=await r.json();return d.available===false?JSON.parse(localStorage.getItem(layoutKey)):d}catch(_){try{return JSON.parse(localStorage.getItem(layoutKey))}catch(__){return null}}})();
 if(stored){applyLayout(stored);workspaceName='custom';$('#workspace-preset').value='custom'}else workspaceSet('editing');
 let dragged=null;
 for(const handle of $$('.pane-drag')){
  handle.ondragstart=e=>{dragged=handle.closest('[data-pane]').dataset.pane;e.dataTransfer.setData('text/plain',dragged);e.dataTransfer.effectAllowed='move'};
  handle.ondragend=()=>{$$('[data-pane]').forEach(el=>el.classList.remove('dock-target'));dragged=null};
 }
 for(const target of $$('[data-pane]')){
  target.ondragover=e=>{if(dragged){e.preventDefault();target.classList.add('dock-target')}};
  target.ondragleave=()=>target.classList.remove('dock-target');
  target.ondrop=e=>{if(!dragged)return;e.preventDefault();target.classList.remove('dock-target');const other=target.dataset.pane;if(other!==dragged){const a=paneOrder.indexOf(other),b=paneOrder.indexOf(dragged);[paneOrder[a],paneOrder[b]]=[paneOrder[b],paneOrder[a]];applyLayout({order:paneOrder,left:dockLeft,right:dockRight,timeline:timelineHeight});$('#workspace-preset').value='custom'}};
 }
 for(const divider of $$('.dock-divider'))divider.onpointerdown=e=>{
  e.preventDefault();divider.setPointerCapture(e.pointerId);divider.classList.add('dragging');
  divider.onpointermove=ev=>{if(!divider.hasPointerCapture(ev.pointerId))return;const zone=$('#dock-zone').getBoundingClientRect();const pct=(ev.clientX-zone.left)/zone.width*100;if(divider.dataset.divider==='first')dockLeft=bound(pct,12,40);else dockRight=bound(100-pct,12,40);document.documentElement.style.setProperty('--dock-left',dockLeft+'%');document.documentElement.style.setProperty('--dock-right',dockRight+'%');$('#workspace-preset').value='custom'};
  divider.onpointerup=ev=>{divider.classList.remove('dragging');divider.onpointermove=null;divider.onpointerup=null;if(divider.hasPointerCapture(ev.pointerId))divider.releasePointerCapture(ev.pointerId)};
 };
 const resizer=$('.timeline-resizer');resizer.onpointerdown=e=>{
  e.preventDefault();resizer.setPointerCapture(e.pointerId);
  resizer.onpointermove=ev=>{if(!resizer.hasPointerCapture(ev.pointerId))return;timelineHeight=bound(window.innerHeight-ev.clientY,200,Math.max(200,window.innerHeight-300));document.documentElement.style.setProperty('--timeline-height',timelineHeight+'px');$('#workspace-preset').value='custom'};
  resizer.onpointerup=ev=>{resizer.onpointermove=null;resizer.onpointerup=null;if(resizer.hasPointerCapture(ev.pointerId))resizer.releasePointerCapture(ev.pointerId)};
 };
}
// The subtitle track is persisted inside the .meridian document.
function paintCaptions(){
 const list=$('#caption-list');if(!list)return;
 list.replaceChildren();for(const c of (view().captions||[])){
  const row=document.createElement('div');row.className='caption-row';
  const time=document.createElement('div');time.className='caption-times';time.textContent=frameToText(c.start)+' → '+frameToText(c.start+c.duration);
  const jump=document.createElement('button');jump.textContent='Go';jump.title='Seek to subtitle';jump.onclick=()=>seek(c.start,true);time.append(jump);
  const input=document.createElement('textarea');input.value=c.text;input.setAttribute('aria-label','Edit subtitle text');input.onchange=()=>edit(()=>c.text=input.value);
  const actions=document.createElement('div');actions.className='caption-actions';
  const label=document.createElement('span');label.textContent='Start frame';const offset=document.createElement('input');offset.type='number';offset.min='0';offset.step='1';offset.value=c.start;offset.onchange=()=>edit(()=>c.start=Math.max(0,Math.round(Number(offset.value)||0)));
  const duration=document.createElement('input');duration.type='number';duration.min='1';duration.step='1';duration.value=c.duration;duration.title='Duration in frames';duration.onchange=()=>edit(()=>c.duration=Math.max(1,Math.round(Number(duration.value)||1)));
  const del=document.createElement('button');del.textContent='Delete';del.onclick=()=>edit(()=>view().captions=view().captions.filter(x=>x.id!==c.id));
  actions.append(label,offset,document.createTextNode('Duration'),duration,del);row.append(time,input,actions);list.append(row);
 }
}
let captionPolling=false;
async function generateCaptions(){if(activeSeqId)return toast('AI captions inside nested compositions are not yet supported',true);
 const c=clip(selected);if(!c)return toast('Select a clip with an audio stream in the timeline',true);
 const m=asset(c.asset);if(!m?.audio)return toast('Selected clip has no audio',true);
 await api('transcribe',{project:doc,clip_id:c.id,model:$('#caption-model').value,language:$('#caption-language').value||null});
 $('#caption-progress').textContent='Loading model / transcribing…';$('#caption-generate').disabled=true;captionPolling=true;
 try{
  while(captionPolling){
   await new Promise(resolve=>setTimeout(resolve,1200));const r=await(await fetch('/api/caption-status')).json();
   if(r.state==='working'){$('#caption-progress').textContent=`${r.message} ${r.percent||0}%`;continue}
   if(r.state==='error')throw Error(r.message);
   if(r.state==='done'){
    const incoming=(r.captions||[]).map(x=>({...x,id:uid()}));
    edit(()=>{view().captions=view().captions||[];view().captions.push(...incoming)});
    $('#caption-progress').textContent=r.message;toast(r.message);break;
   }
   throw Error('Transcription ended unexpectedly');
  }
 }catch(error){$('#caption-progress').textContent=error.message;toast(error.message,true)}
 finally{captionPolling=false;$('#caption-generate').disabled=false}
}
function exportCaptions(){
 if(activeSeqId)return toast('Export subtitles from the main sequence for now',true);
 if(!(view().captions||[]).length)return toast('No subtitles to export',true);
 modal('Export subtitles',`<label>Full destination path (.srt or .vtt)</label><input id="captions-path" placeholder="C:\\Exports\\captions.srt"><p class="hint">This exports a standalone subtitle file, not burned-in captions.</p>`,async()=>{
  const path=$('#captions-path').value.trim();if(!path)throw Error('Enter a destination path');
  const result=await api('export-subtitles',{project:doc,path});toast('Subtitles exported: '+result.path);
 });
}

// Shortcuts are application commands, not direct DOM changes. Profiles persist via local server.
const shortcutDefaults={sourceIn:'I',sourceOut:'O',sourcePlay:'Shift+Space',sourceNext:'Shift+ArrowRight',sourcePrevious:'Shift+ArrowLeft',programIn:'Ctrl+I',programOut:'Ctrl+O',slide:'Ctrl+Alt+S',insert:'Ctrl+Alt+I',trim:'Ctrl+Alt+T',slip:'Ctrl+Alt+L',roll:'Ctrl+Alt+R',overwrite:'Ctrl+Alt+O',save:'Ctrl+S',undo:'Ctrl+Z',redo:'Ctrl+Shift+Z',split:'Ctrl+K',duplicate:'Ctrl+Alt+D',ripple:'Shift+Delete',nest:'Ctrl+Alt+N',open:'Enter',back:'Alt+ArrowLeft',play:'Space',next:'ArrowRight',previous:'ArrowLeft',remove:'Delete',select:'V',razor:'C',snap:'S',edit:'Ctrl+1',effects:'Ctrl+2',keys:'Ctrl+Alt+K'};
let shortcuts={...shortcutDefaults};
const shortcutCommands={sourceIn:'Source: Mark In',sourceOut:'Source: Mark Out',sourcePlay:'Source: Play/Pause',sourceNext:'Source: Next frame',sourcePrevious:'Source: Previous frame',programIn:'Program: Mark In',programOut:'Program: Mark Out',slide:'Slide edit',insert:'Three-point insert',trim:'Precision trim',slip:'Slip source',roll:'Roll edit',overwrite:'Three-point overwrite',save:'Save project',undo:'Undo',redo:'Redo',split:'Split at playhead',duplicate:'Duplicate selected clip',ripple:'Ripple delete on track',nest:'Nest selection',open:'Open selected nest',back:'Exit nested composition',play:'Play / Pause',next:'Next frame',previous:'Previous frame',remove:'Delete selected',select:'Selection tool',razor:'Razor tool',snap:'Toggle snapping',edit:'Edit workspace',effects:'Effects workspace',keys:'Customize shortcuts'};
function shortcutFromEvent(e){const key=e.code==='Space'?'Space':e.key.length===1?e.key.toUpperCase():e.key;return `${e.ctrlKey||e.metaKey?'Ctrl+':''}${e.altKey?'Alt+':''}${e.shiftKey?'Shift+':''}${key}`}
const commandActions={sourceIn:()=>sourceMonitor.mark('in'),sourceOut:()=>sourceMonitor.mark('out'),sourcePlay:sourceMonitor.toggle,sourceNext:()=>sourceMonitor.move(Number($('#source-scrub').value)+1),sourcePrevious:()=>sourceMonitor.move(Number($('#source-scrub').value)-1),programIn:()=>sourceMonitor.programMark('in'),programOut:()=>sourceMonitor.programMark('out'),slide:slideDialog,insert:insertDialog,trim:trimDialog,slip:slipDialog,roll:rollDialog,overwrite:overwriteDialog,save:()=>saveProject().catch(e=>toast(e.message,true)),undo,redo,split:()=>splitSelected(),duplicate:duplicateSelected,ripple:rippleSelected,nest:()=>nestSelected().catch(e=>toast(e.message,true)),open:openSelectedNest,back:closeNest,play:togglePlay,next:()=>seek(view().playhead+1,true),previous:()=>seek(view().playhead-1,true),remove:delSelected,select:()=>setTool('select'),razor:()=>setTool('razor'),snap:()=>$('#snap').click(),edit:()=>workspaceSet('editing'),effects:()=>workspaceSet('effects'),keys:()=>openShortcutDialog()};
function handleShortcut(e){
 if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)||e.isComposing)return;
 const key=shortcutFromEvent(e);const action=Object.keys(shortcuts).find(a=>shortcuts[a]===key);
 if(!action)return;e.preventDefault();commandActions[action]?.();
}
async function loadShortcuts(){try{const r=await fetch('/api/shortcuts');const data=await r.json();if(data.shortcuts)shortcuts={...shortcutDefaults,...data.shortcuts}}catch(e){console.warn('Shortcuts defaults in use',e)}}
function openShortcutDialog(){
 const fields=`<p class="hint">Click a shortcut field, then press your combination. Conflicts are rejected. Ctrl also works as Command on macOS.</p><div class="shortcut-rows">${Object.entries(shortcutCommands).map(([k,label])=>`<div class="shortcut-row"><label>${label}</label><input data-action="${k}" readonly value="${shortcuts[k]||''}" aria-label="Shortcut for ${label}"></div>`).join('')}</div><button id="shortcuts-restore" type="button">Restore defaults</button>`;
 modal('Customize keyboard shortcuts',fields,async()=>{
  const bindings={};for(const input of $$('#modal-content input[data-action]'))bindings[input.dataset.action]=input.value;
  const data=await api('shortcuts',{shortcuts:bindings});shortcuts={...data.shortcuts};toast('Keyboard shortcuts saved');
 });
 for(const input of $$('#modal-content input[data-action]'))input.onkeydown=e=>{
  e.preventDefault();e.stopPropagation();if(e.key==='Tab'){input.blur();return}
  if(['Control','Meta','Shift','Alt'].includes(e.key))return;
  const combo=shortcutFromEvent(e);if(!combo||combo==='Escape')return;
  const duplicate=$$('#modal-content input[data-action]').find(other=>other!==input&&other.value===combo);
  if(duplicate){toast('Shortcut already assigned: '+shortcutCommands[duplicate.dataset.action],true);return}
  input.value=combo;
 };
 $('#shortcuts-restore').onclick=()=>{for(const input of $$('#modal-content input[data-action]'))input.value=shortcutDefaults[input.dataset.action]};
}

function setup(){
effectsUI.setup();maskUI.setup();
quickLibrary=new MeridianQuickLibrary({presets:quickPresetData,fonts:freeFontData,onApply:applyQuickPreset,
 onFontImport:importDaFont,onFontUse:(id)=>createQuickTitle(id),
 onTransition:addQuickTransition,toast});quickLibrary.setup();document.querySelector('#quick-create-title').onclick=createQuickTitle;
sourceMonitor.init();$('#track-add-video').onclick=()=>applyEditorial('add-track',{track_kind:'video'}).catch(e=>toast(e.message,true));$('#track-add-audio').onclick=()=>applyEditorial('add-track',{track_kind:'audio'}).catch(e=>toast(e.message,true));$('#edit-slide').onclick=slideDialog;$('#edit-insert').onclick=insertDialog;$('#edit-trim').onclick=trimDialog;$('#edit-slip').onclick=slipDialog;$('#edit-roll').onclick=rollDialog;$('#edit-overwrite').onclick=overwriteDialog;$('#media-relink').onclick=()=>relinkSelected().catch(e=>toast(e.message,true));
$('#nest').onclick=()=>nestSelected().catch(e=>toast(e.message,true));$('#transition-add').onclick=()=>createTransition().catch(e=>toast(e.message,true));$('#exact-preview').onclick=()=>renderExactFrame();$('#viewer-mode').onchange=()=>{stopNativeStream();if(viewerMode()!=='gpu'&&gpuPreview){gpuPreview.dispose();gpuPreview=null}showPreview();if(viewerMode()==='native')startNativeStream()};$('#nest-open').onclick=openSelectedNest;$('#nest-back').onclick=closeNest;$('#shortcuts').onclick=openShortcutDialog;
initWorkspaces().catch(e=>console.error('Workspace restore failed',e));$('#caption-generate').onclick=()=>generateCaptions().catch(e=>toast(e.message,true));$('#caption-add').onclick=()=>edit(()=>{view().captions=view().captions||[];view().captions.push({id:uid(),start:view().playhead,duration:Math.max(1,Math.round(doc.fps*2.5)),text:'New subtitle'})});$('#caption-export').onclick=exportCaptions;
$$('[data-left]').forEach(b=>b.onclick=()=>setTab('left',b.dataset.left));$$('[data-right]').forEach(b=>b.onclick=()=>setTab('right',b.dataset.right));$('#media-search').oninput=paintMedia;$('#import').onclick=$('#import-small').onclick=()=>importMedia().catch(e=>toast(e.message,true));$('#save-project').onclick=()=>saveProject().catch(e=>toast(e.message,true));$('#open-project').onclick=()=>openProject().catch(e=>toast(e.message,true));$('#new-project').onclick=async()=>{if(!confirm('Create a new project? Unsaved timeline edits will be lost.'))return;const freshDoc=(await api('new-project',{})).project;sourceMonitor.reset();edit(()=>{doc=freshDoc;activeSeqId=null;nestedTrail=[];resetSelection();projectPath=null})};$('#settings').onclick=$('#project-settings').onclick=settings;$('#export').onclick=()=>exportProject().catch(e=>toast(e.message,true));$('#play').onclick=togglePlay;$('#prev-frame').onclick=()=>seek(view().playhead-1,true);$('#next-frame').onclick=()=>seek(view().playhead+1,true);$('#split').onclick=()=>splitSelected();$('#duplicate').onclick=duplicateSelected;$('#ripple').onclick=rippleSelected;$('#delete').onclick=delSelected;$('#undo').onclick=undo;$('#redo').onclick=redo;$('#snap').onclick=()=>{snap=!snap;$('#snap').classList.toggle('active',snap)};$('#select-tool').onclick=()=>setTool('select');$('#razor-tool').onclick=()=>setTool('razor');$('#zoom').oninput=e=>{zoom=Number(e.target.value);paintTimeline()};$('#ruler').addEventListener('pointerdown',e=>{const rect=$('#ruler').getBoundingClientRect();seek((e.clientX-rect.left)/zoom*fps(),true);const move=ev=>seek((ev.clientX-rect.left)/zoom*fps(),true);window.addEventListener('pointermove',move);window.addEventListener('pointerup',()=>window.removeEventListener('pointermove',move),{once:true})});$('#graph-property').onchange=e=>{graphProperty=e.target.value;paintGraph()};$('#add-graph-key').onclick=()=>toggleKey(graphProperty);$('#delete-graph-key').onclick=()=>{const c=clip(selected);if(!c)return;let f=view().playhead-c.start;edit(()=>{c.keyframes[graphProperty]=(c.keyframes[graphProperty]||[]).filter(k=>k.frame!==f)})};$('#keyframe-mode').onchange=e=>{const c=clip(selected);if(!c)return;const k=(c.keyframes[graphProperty]||[]).find(k=>k.frame===view().playhead-c.start);if(k)edit(()=>k.interpolation=e.target.value)};document.addEventListener('keydown',handleShortcut);window.addEventListener('beforeunload',()=>{if(play)transport.pause();stopNativeStream()});
}
function setTool(value){tool=value;$('#select-tool').classList.toggle('active',value==='select');$('#razor-tool').classList.toggle('active',value==='razor')}
async function main(){const res=await(await fetch('/api/session')).json();token=res.token;nativeReady=!!res.native;$('#render-engine').querySelector('[value=native]').disabled=!nativeReady;$('#render-engine').querySelector('[value=native-hw]').disabled=!nativeReady||!res.hw_encoder;$('#render-engine').title=nativeReady?'Native engine compiled and available':'Build the native compositor using build-native.sh or build-native-windows.bat';$('#viewer-mode').querySelector('[value=native]').disabled=!nativeReady;doc=res.project;projectPath=res.project_path;effectCatalog=res.effects||[];quickPresetData=res.quick_presets||[];freeFontData=res.fonts||[];missingMedia=new Set(res.missing_media||[]);setup();await loadShortcuts();paint();if(!res.ffmpeg)toast('FFmpeg not found. Playback may work but MP4 export will not.',true)}
main().catch(e=>{document.body.textContent='Editor failed to start: '+e.message;console.error(e)});
