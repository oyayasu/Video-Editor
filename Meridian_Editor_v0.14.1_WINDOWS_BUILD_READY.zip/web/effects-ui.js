'use strict';
/* Standalone native-effects UI. Rendering specifications live in src/effects.py. */
class MeridianEffectsUI {
  constructor(services) {
    this.s = services;
    this.search = '';
    this.category = 'All categories';
    this.clipboard = null;
  }
  setup() {
    const search = document.querySelector('#effect-search');
    const category = document.querySelector('#effect-category');
    search.addEventListener('input', () => { this.search = search.value.toLowerCase(); this.paintCatalog(); });
    category.addEventListener('change', () => { this.category = category.value; this.paintCatalog(); });
    document.querySelector('#effects-copy').onclick = () => this.copy();
    document.querySelector('#effects-paste').onclick = () => this.paste();
    this.paintCatalog();
  }
  spec(type) { return this.s.catalog().find(effect => effect.type === type); }
  paintCatalog() {
    const specs = this.s.catalog();
    const categoryInput = document.querySelector('#effect-category');
    const categories = ['All categories', ...new Set(specs.map(effect => effect.category)), 'Timeline Transitions'];
    if (categoryInput.options.length !== categories.length) {
      categoryInput.replaceChildren();
      for (const name of categories) categoryInput.add(new Option(name,name));
      categoryInput.value = this.category;
    }
    const filtered = specs.filter(effect =>
      (this.category === 'All categories' || effect.category === this.category) &&
      (effect.name+' '+effect.category+' '+effect.description).toLowerCase().includes(this.search));
    const root = document.querySelector('#effect-catalog');
    root.replaceChildren();
    const groups = new Map();
    for (const effect of filtered) {
      if (!groups.has(effect.category)) groups.set(effect.category,[]);
      groups.get(effect.category).push(effect);
    }
    for (const [category, items] of groups) {
      const section = document.createElement('section');
      section.className = 'effect-category';
      const title = document.createElement('div');
      title.className = 'effect-category-title';
      title.textContent = `${category}  ·  ${items.length}`;
      section.append(title);
      for (const effect of items) {
        const item = document.createElement('button');
        item.className = 'effect-item';
        item.type = 'button';
        item.draggable = true;
        item.title = effect.description + ' — click to apply, or drag onto a clip';
        const name = document.createElement('span'); name.textContent=effect.name;
        const kind = document.createElement('small'); kind.textContent=effect.kind==='both'?'V + A':effect.kind==='video'?'VIDEO':'AUDIO';
        item.append(name,kind);
        item.onclick=() => this.apply(effect.type);
        item.ondragstart = ev => {
          ev.dataTransfer.setData('text/meridian-effect', effect.type);
          ev.dataTransfer.effectAllowed='copy';
        };
        section.append(item);
      }
      root.append(section);
    }
    const transitionSection=document.createElement('section');
    transitionSection.className='effect-category';
    const transitionItems=[['Cross Dissolve','video'],['Wipe Left','video'],['Audio Crossfade','audio']];
    const showTransitions=(this.category==='All categories'||this.category==='Timeline Transitions') &&
      transitionItems.some(([name])=>('timeline transitions '+name).toLowerCase().includes(this.search));
    if(showTransitions){
      const heading=document.createElement('div');heading.className='effect-category-title';
      heading.textContent='TIMELINE TRANSITIONS · TWO SOURCES';transitionSection.append(heading);
      for(const [label,kind] of transitionItems){
        if(!('timeline transitions '+label).toLowerCase().includes(this.search))continue;
        const button=document.createElement('button');button.type='button';button.className='effect-item';
        button.innerHTML='<span></span><small></small>';
        button.querySelector('span').textContent=label;button.querySelector('small').textContent=kind.toUpperCase();
        button.title='Select two overlapping clips on the same track; click to create a transition';
        button.onclick=()=>this.s.addTransition();transitionSection.append(button);
      }
      root.append(transitionSection);
    }
    document.querySelector('#effect-count').textContent=`${filtered.length} native effects · 3 timeline transitions`;
    if (!filtered.length && !showTransitions) {const empty=document.createElement('p');empty.className='hint';empty.textContent='No effects found.';root.append(empty);}
  }
  apply(type, clipId = null) {
    const c = clipId ? this.s.findClip(clipId) : this.s.selectedClip();
    if (!c) { this.s.toast('Select a clip before adding an effect',true); return; }
    const spec = this.spec(type);
    const kind = this.s.trackKind(c.track);
    if (!spec || (spec.kind!==kind && spec.kind!=='both')) {this.s.toast('This effect cannot be applied to a '+kind+' track',true);return;}
    if ((c.effects||[]).length>=64) {this.s.toast('Maximum of 64 effects per clip',true);return;}
    const instance = {id:this.s.id(),type,enabled:true,params:Object.fromEntries(Object.entries(spec.params).map(([k,p])=>[k,p.default])),keyframes:{}};
    this.s.edit(()=>{if(!c.effects)c.effects=[];c.effects.push(instance);});
    this.s.inspect();
    this.s.toast('Added '+spec.name);
  }
  copy() {
    const c=this.s.selectedClip();
    if (!c) {this.s.toast('Select a clip first',true);return;}
    this.clipboard=structuredClone(c.effects||[]);
    this.s.toast(`Copied ${this.clipboard.length} effect(s)`);
  }
  paste() {
    const c=this.s.selectedClip();
    if (!c || !this.clipboard) {this.s.toast('Copy effects and select a destination clip',true);return;}
    const kind=this.s.trackKind(c.track);
    if (this.clipboard.some(effect => !this.spec(effect.type) || ![kind,'both'].includes(this.spec(effect.type).kind))) {
      this.s.toast('Some copied effects are incompatible with this track',true);return;
    }
    if ((c.effects||[]).length+this.clipboard.length>64){this.s.toast('Maximum of 64 effects per clip',true);return;}
    this.s.edit(()=>{c.effects=[...(c.effects||[]),...this.clipboard.map(effect=>({...structuredClone(effect),id:this.s.id()}))];});
  }
  paintStack() {
    const root=document.querySelector('#effect-stack');
    root.replaceChildren();
    const c=this.s.selectedClip();
    if (!c) return;
    const effects=c.effects||[];
    if (!effects.length) {
      const hint=document.createElement('p');hint.className='effect-empty';
      hint.textContent='No native effects. Browse the Effects panel to add one.';
      root.append(hint);return;
    }
    for (let i=0;i<effects.length;i++) {
      const instance=effects[i],spec=this.spec(instance.type);
      if (!spec)continue;
      const card=document.createElement('section');card.className='effect-stack-card';
      const heading=document.createElement('div');heading.className='effect-stack-heading';
      const power=document.createElement('input');power.type='checkbox';power.checked=instance.enabled;
      power.title='Enable effect';power.setAttribute('aria-label','Enable '+spec.name);
      power.onchange=()=>this.s.edit(()=>{instance.enabled=power.checked;});
      const label=document.createElement('strong');label.textContent=spec.name;
      const up=this.action('↑','Move up',()=>this.move(c,i,-1));up.disabled=i===0;
      const down=this.action('↓','Move down',()=>this.move(c,i,+1));down.disabled=i===effects.length-1;
      const remove=this.action('×','Remove effect',()=>this.s.edit(()=>{c.effects.splice(i,1);}));
      heading.append(power,label,up,down,remove);card.append(heading);
      for (const [key,param] of Object.entries(spec.params)) {
        const row=document.createElement('label');row.className='effect-param';
        const caption=document.createElement('span');caption.textContent=param.label;
        const input=document.createElement('input');input.type='number';input.min=String(param.min);input.max=String(param.max);input.step=String(param.step);input.value=String(instance.params[key]);
        input.setAttribute('aria-label',spec.name+' '+param.label);
        const animatable=(spec.animatable||[]).includes(key);
        const local=this.s.playhead()-c.start;
        const keys=instance.keyframes?.[key]||[];
        const currentKey=keys.find(k=>k.frame===local);
        if(currentKey)input.value=String(currentKey.value);
        input.onchange=()=>{
          const value=Number(input.value);
          if (!Number.isFinite(value)) {input.value=String(instance.params[key]);return;}
          const safe=Math.max(param.min,Math.min(param.max,value));
          this.s.edit(()=>{
            const existing=instance.keyframes?.[key]?.find(k=>k.frame===local);
            if(existing)existing.value=safe;else instance.params[key]=key==='frames'?Math.round(safe):safe;
          });
        };
        row.append(caption,input);
        if(animatable){
          const diamond=this.action(currentKey?'◆':'◇', 'Toggle parameter keyframe at the playhead',()=>{
            if(local<0||local>=c.duration){this.s.toast('Playhead must be inside the clip',true);return}
            this.s.edit(()=>{
              instance.keyframes ||= {};
              const curve=instance.keyframes[key] ||= [];
              const at=curve.findIndex(k=>k.frame===local);
              if(at>=0)curve.splice(at,1);
              else curve.push({frame:local,value:Number(input.value),interpolation:'linear'});
            });
          });
          diamond.classList.add('effect-key-button');if(currentKey)diamond.classList.add('has-key');row.append(diamond);
        }
        card.append(row);
      }
      root.append(card);
    }
  }
  action(label,title,click) {
    const button=document.createElement('button');button.type='button';button.textContent=label;button.title=title;button.onclick=click;return button;
  }
  move(c,index,direction) {
    const to=index+direction;
    if (to<0||to>=c.effects.length)return;
    this.s.edit(()=>{[c.effects[index],c.effects[to]]=[c.effects[to],c.effects[index]];});
  }
}
