/* Meridian Effects: nondestructive geometric mattes, no node UI. */
'use strict';
class MeridianMaskUI {
  constructor(api){this.api=api}
  setup(){
    document.querySelector('#mask-add-rectangle').onclick=()=>this.add('rectangle');
    document.querySelector('#mask-add-ellipse').onclick=()=>this.add('ellipse');
  }
  add(shape){
    const clip=this.api.selectedClip();
    if(!clip){this.api.toast('Select a video clip first',true);return}
    if(this.api.trackKind(clip.track)!=='video'){this.api.toast('Masks only apply to video',true);return}
    if((clip.masks||[]).length>=16){this.api.toast('16 masks maximum',true);return}
    this.api.edit(()=>{
      (clip.masks??=[]).push({id:this.api.id(),shape,mode:'add',enabled:true,invert:false,
        x:.5,y:.5,width:.5,height:.5,feather:.02,opacity:1});
    });
    this.api.toast('Mask added · Render frame to inspect the matte');
  }
  paint(){
    const root=document.querySelector('#mask-stack');root.replaceChildren();
    const clip=this.api.selectedClip();
    const addRect=document.querySelector('#mask-add-rectangle');
    const addEllipse=document.querySelector('#mask-add-ellipse');
    const available=!!clip&&this.api.trackKind(clip.track)==='video';
    addRect.disabled=addEllipse.disabled=!available;
    if(!available)return;
    const masks=clip.masks||[];
    if(!masks.length){const p=document.createElement('p');p.className='hint';p.textContent='No layer masks. Add a rectangle or ellipse to limit visibility.';root.append(p);return}
    for(const [index,mask] of masks.entries()){
      const card=document.createElement('section');card.className='effect-stack-card';
      const head=document.createElement('div');head.className='effect-stack-heading';
      const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=mask.enabled;
      enabled.setAttribute('aria-label','Enable mask');enabled.onchange=()=>this.commit(()=>{mask.enabled=enabled.checked});
      const name=document.createElement('strong');name.textContent=`${index+1} · ${mask.shape}`;
      const remove=this.button('×','Remove mask',()=>this.api.edit(()=>clip.masks.splice(index,1)));
      head.append(enabled,name,remove);card.append(head);
      const mode=this.select('Combine mode',mask.mode,['add','subtract','intersect'],value=>this.commit(()=>{mask.mode=value}));card.append(mode);
      const invert=document.createElement('label');invert.className='effect-param';
      invert.append(document.createTextNode('Invert'),(()=>{const c=document.createElement('input');c.type='checkbox';c.checked=mask.invert;c.onchange=()=>this.commit(()=>{mask.invert=c.checked});return c})());card.append(invert);
      for(const [key,label,min,max,step] of [
        ['x','Center X',0,1,.01],['y','Center Y',0,1,.01],
        ['width','Width',.01,1,.01],['height','Height',.01,1,.01],
        ['feather','Feather',0,.25,.005],['opacity','Mask opacity',0,1,.01]]){
        const row=document.createElement('label');row.className='effect-param';
        const text=document.createElement('span');text.textContent=label;
        const input=document.createElement('input');input.type='number';input.min=min;input.max=max;input.step=step;input.value=mask[key];
        input.setAttribute('aria-label','Mask '+label);
        input.onchange=()=>{const n=Number(input.value);if(!Number.isFinite(n)){input.value=mask[key];return}
          this.commit(()=>{mask[key]=Math.max(min,Math.min(max,n))})};row.append(text,input);card.append(row);
      }
      root.append(card);
    }
  }
  commit(mutator){requestAnimationFrame(()=>this.api.edit(mutator))}
  button(text,title,callback){const b=document.createElement('button');b.textContent=text;b.title=title;b.type='button';b.onclick=callback;return b}
  select(label,current,values,callback){const row=document.createElement('label');row.className='effect-param';
    const span=document.createElement('span');span.textContent=label;const select=document.createElement('select');
    for(const v of values)select.add(new Option(v,v));select.value=current;select.setAttribute('aria-label',label);select.onchange=()=>callback(select.value);
    row.append(span,select);return row}
}
