/* Meridian Source Monitor: independent transport, exclusive Out marks, patched
   three-point editing. The backend remains authoritative for all edits. */
const sourceMonitor = (() => {
  let sourceId = null, frame = 0, programIn = null, programOut = null;
  let activeMedia = null, playing = false, patchV, patchA;
  const byId = id => document.getElementById(id);
  const mediaElement = () => activeMedia?.video ? byId('source-video') : byId('source-audio');
  const length = () => activeMedia ? Math.max(1,Math.round(activeMedia.duration_seconds * fps())) : 1;
  const markPair = () => doc?.source_ranges?.[sourceId] || {in:null, out:null};
  const readable = val => val == null ? '—' : frameToText(val);
  const available = () => activeMedia && !missingMedia.has(sourceId);

  function refreshPatches() {
    const list = view().tracks.filter(t => !t.locked);
    for (const [id,kind] of [['source-patch-video','video'],['source-patch-audio','audio']]) {
      const control = byId(id);
      const old = control.value;
      control.replaceChildren(new Option('Off',''));
      for (const t of list.filter(t => t.kind === kind)) control.add(new Option(t.name,t.id));
      const isPresent = [...control.options].some(o => o.value === old);
      const saved = kind === 'video' ? patchV : patchA;
      const chosen = saved === null ? '' : [saved,old,kind === 'video' ? 'V1' : 'A1'].find(x => x && [...control.options].some(o => o.value === x));
      control.value = (activeMedia?.[kind] && chosen) ? chosen : '';
      control.disabled = !activeMedia?.[kind];
      if (activeMedia?.[kind]) {
        if (kind === 'video') patchV = control.value || null;
        else patchA = control.value || null;
      }
    }
  }
  function paintMarks() {
    const source = markPair();
    const end = length();
    byId('source-in-tc').textContent = readable(source.in);
    byId('source-out-tc').textContent = readable(source.out == null ? null : source.out-1);
    const range = byId('source-range-mark');
    const inFrame = source.in ?? 0, outFrame = source.out ?? end;
    range.style.left = (100*inFrame/end)+'%';
    range.style.width = (100*(outFrame-inFrame)/end)+'%';
    byId('program-in-tc').textContent = readable(programIn);
    byId('program-out-tc').textContent = readable(programOut == null ? null : programOut-1);
    byId('source-help').textContent = activeMedia ? `Selected: ${outFrame-inFrame} frames · ${fps()} fps` : 'Select a source to begin.';
  }
  function updateUI() {
    byId('source-tc').textContent = frameToText(frame);
    byId('source-scrub').value = String(frame);
    byId('source-play').textContent = playing ? '❚❚' : '▶';
    paintMarks();
  }
  function pause() {
    playing = false;
    for (const id of ['source-video','source-audio']) byId(id).pause();
    byId('source-play').textContent = '▶';
  }
  function move(to) {
    if (!available()) return;
    frame = Math.max(0,Math.min(length()-1,Math.round(to)));
    const el = mediaElement();
    // Media tags seek to timestamps; the editor's frame count and edit points
    // remain integer frames regardless of browser codec seek accuracy.
    if (el && Math.abs(el.currentTime-frame/fps()) >= 0.01) {
      try { el.currentTime = frame/fps(); } catch (_) { /* Metadata may still be loading. */ }
    }
    updateUI();
  }
  function open(id) {
    const m = doc.media.find(x=>x.id===id);
    if (!m) return;
    pause();
    const same = sourceId === id;
    sourceId = id; activeMedia = m; selectedMediaId = id;
    frame = same ? Math.min(frame,length()-1) : 0;
    for (const name of ['source-video','source-audio']) {
      const element=byId(name);
      element.removeAttribute('src');element.load();
    }
    const online = available();
    byId('source-video').classList.toggle('hidden', !online || !m.video);
    byId('source-empty').classList.toggle('hidden',online);
    byId('source-audio-label').classList.toggle('hidden', !online || m.video);
    byId('source-filename').textContent = m.name + (online ? '' : ' · OFFLINE');
    if (!online) byId('source-empty').textContent='Source offline — use Relink selected.';
    const el = mediaElement();
    if (online) {
      el.src = '/api/media/'+encodeURIComponent(m.id);
      el.load();
    }
    byId('source-scrub').max = String(length()-1);
    refreshPatches();updateUI();
    if (!same) paintMedia();
  }
  function sync() {
    if (!doc) return;
    if (sourceId) {
      const newer = doc.media.find(m=>m.id===sourceId);
      if (!newer) {reset();return;} else if (activeMedia?.path!==newer.path || activeMedia?.duration_seconds!==newer.duration_seconds) {
        open(newer.id);
      } else activeMedia=newer;
    }
    refreshPatches();updateUI();
  }
  function mark(which) {
    if (!available())return;
    const old=markPair();
    const next={in:old.in, out:old.out};
    next[which] = which==='out'?frame+1:frame;
    if (next.in != null && next.out != null && next.in>=next.out) {
      toast('In must be before Out. Clear the conflicting mark first.',true);return;
    }
    snapshot();
    doc.source_ranges ||= {};
    doc.source_ranges[sourceId]=next;
    syncLater();paintMarks();
  }
  function clear() {
    if (!sourceId)return;
    if (!doc.source_ranges?.[sourceId])return;
    snapshot();delete doc.source_ranges[sourceId];syncLater();paintMarks();
  }
  function programMark(which) {
    const value=which==='out'?view().playhead+1:view().playhead;
    const other=which==='out'?programIn:programOut;
    if (other != null && (which==='out'?value<=other:value>=other)) {
      toast('Sequence In must precede sequence Out.',true);return;
    }
    if (which==='out')programOut=value;
    else programIn=value;
    paintMarks();
  }
  function clearProgram(){programIn=null;programOut=null;paintMarks();}
  function reset(){
    pause();programIn=null;programOut=null;sourceId=null;activeMedia=null;frame=0;
    for(const id of ['source-video','source-audio']){
      const el=byId(id);el.removeAttribute('src');el.load();
    }
    byId('source-video').classList.add('hidden');
    byId('source-audio-label').classList.add('hidden');
    byId('source-empty').classList.remove('hidden');
    byId('source-empty').textContent='Double-click media to open in Source Monitor';
    byId('source-filename').textContent='No source loaded';
    sync();
  }
  async function execute(operation) {
    if (!available())return toast('Open an online source first.',true);
    if (rendering)return toast('Wait until the current export finishes.',true);
    const v=byId('source-patch-video').value||null, a=byId('source-patch-audio').value||null;
    if (!v&&!a)return toast('Choose a video or audio destination track.',true);
    const {in:source_in,out:source_out}=markPair();
    const payload={project:doc,action:operation,asset_id:sourceId,
      source_in,source_out,video_track:v,audio_track:a,
      program_in:programIn??view().playhead,program_out:programOut,container_id:activeSeqId};
    const originalSourceId=sourceId;
    const r=await api('source-edit',payload);
    snapshot();doc=r.project;
    resetSelection();
    for(const id of r.clip_ids)selectedIds.add(id);
    selected=r.clip_ids[0];
    if(viewerMode()==='native')stopNativeStream();
    paint();syncLater();
    seek(r.range.program_out,true);
    if (sourceId!==originalSourceId)open(originalSourceId);
    toast(`${operation==='insert'?'Inserted':'Overwrote'} ${r.range.duration} frames · ${r.clip_ids.length} patched track(s)`);
  }
  function toggle(){
    if (!available())return;
    if(playing){pause();return}
    if(play)togglePlay(); // Avoid two independent audio sources simultaneously.
    const marks=markPair();
    const out=marks.out??length();
    if(frame>=out-1)move(marks.in??0);
    const el=mediaElement();
    playing=true;updateUI();
    el.play().catch(error=>{pause();toast('Source playback unavailable: '+error.message,true)});
  }
  function init(){
    for(const [id,fn] of [['source-prev',()=>{pause();move(frame-1)}],['source-next',()=>{pause();move(frame+1)}],
      ['source-play',toggle],['source-mark-in',()=>mark('in')],['source-mark-out',()=>mark('out')],
      ['source-clear',clear],['source-insert',()=>execute('insert').catch(e=>toast(e.message,true))],
      ['source-overwrite',()=>execute('overwrite').catch(e=>toast(e.message,true))],
      ['program-mark-in',()=>programMark('in')],['program-mark-out',()=>programMark('out')],
      ['program-clear-marks',clearProgram]])byId(id).addEventListener('click',fn);
    byId('source-scrub').addEventListener('input',e=>{pause();move(Number(e.target.value))});
    for(const [id,kind] of [['source-patch-video','video'],['source-patch-audio','audio']])
      byId(id).addEventListener('change',e=>{if(kind==='video')patchV=e.target.value||null;else patchA=e.target.value||null});
    for(const id of ['source-video','source-audio']){
      const el=byId(id);
      el.addEventListener('timeupdate',()=>{
        if(!playing || el!==mediaElement())return;
        const now=Math.min(length()-1,Math.max(0,Math.floor(el.currentTime*fps()+1e-5)));
        const out=markPair().out??length();
        if(now>=out){pause();move(out-1);return}
        frame=now;updateUI();
      });
      el.addEventListener('ended',pause);
    }
    sync();
  }
  return {init,open,sync,reset,move,pause,toggle,mark,programMark,clearProgram,execute,
    get currentId(){return sourceId}};
})();
