'use strict';
/* Meridian WebGL2 monitor: GPU layer transforms, alpha compositing and two
 * native-like transition types. This is a preview backend, NOT a GPU exporter.
 * All graphics resources belong to this instance, never to the project file.
 */
class MeridianGPUPreview {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl2', {alpha:false, antialias:false, preserveDrawingBuffer:false});
    if (!gl) throw new Error('WebGL2 is not supported by this browser/driver');
    this.gl=gl;
    const vs=`#version 300 es
    in vec2 a_position;
    in vec2 a_uv;
    out vec2 v_uv;
    void main(){gl_Position=vec4(a_position,0.,1.);v_uv=a_uv;}`;
    const fs=`#version 300 es
    precision highp float;
    uniform sampler2D u_image;
    uniform float u_alpha,u_brightness,u_contrast,u_saturation,u_progress;
    uniform int u_transition;
    uniform float u_width;
    in vec2 v_uv;
    out vec4 color;
    void main(){
       if(u_transition==2 && gl_FragCoord.x/u_width>u_progress) discard;
       vec4 pixel=texture(u_image,v_uv);
       vec3 rgb=(pixel.rgb-0.5)*u_contrast+0.5+u_brightness;
       float luminance=dot(rgb,vec3(.2126,.7152,.0722));
       rgb=mix(vec3(luminance),rgb,u_saturation);
       float trans=u_transition==1?u_progress:1.;
       color=vec4(clamp(rgb,0.,1.),pixel.a*u_alpha*trans);
    }`;
    const shader=(kind,source)=>{
      const handle=gl.createShader(kind);gl.shaderSource(handle,source);gl.compileShader(handle);
      if(!gl.getShaderParameter(handle,gl.COMPILE_STATUS)){
        const error=gl.getShaderInfoLog(handle);gl.deleteShader(handle);throw Error('GPU shader compile failed: '+error);
      }
      return handle;
    };
    const vertex=shader(gl.VERTEX_SHADER,vs),fragment=shader(gl.FRAGMENT_SHADER,fs);
    this.program=gl.createProgram();gl.attachShader(this.program,vertex);gl.attachShader(this.program,fragment);
    gl.linkProgram(this.program);gl.deleteShader(vertex);gl.deleteShader(fragment);
    if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(this.program));
    this.buffer=gl.createBuffer();this.locations={};
    for(const key of ['u_alpha','u_brightness','u_contrast','u_saturation','u_progress','u_transition','u_width','u_image'])
      this.locations[key]=gl.getUniformLocation(this.program,key);
    this.position=gl.getAttribLocation(this.program,'a_position');
    this.uv=gl.getAttribLocation(this.program,'a_uv');
    this.textures=new Map();
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;});
    canvas.addEventListener('webglcontextrestored',()=>{this.lost=true;});
  }
  dispose(){
    const gl=this.gl;
    for(const t of this.textures.values())gl.deleteTexture(t);
    this.textures.clear();gl.deleteBuffer(this.buffer);gl.deleteProgram(this.program);
  }
  draw(layers,seqWidth,seqHeight){
    if(this.lost)return false;
    const gl=this.gl, canvas=this.canvas;
    const dpr=Math.min(2,window.devicePixelRatio||1);
    const w=Math.max(1,Math.round(canvas.clientWidth*dpr)),h=Math.max(1,Math.round(canvas.clientHeight*dpr));
    if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
    gl.viewport(0,0,w,h);
    gl.disable(gl.DEPTH_TEST);
    gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(this.program);
    gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
    gl.enableVertexAttribArray(this.position);gl.vertexAttribPointer(this.position,2,gl.FLOAT,false,16,0);
    gl.enableVertexAttribArray(this.uv);gl.vertexAttribPointer(this.uv,2,gl.FLOAT,false,16,8);
    gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
    gl.activeTexture(gl.TEXTURE0);gl.uniform1i(this.locations.u_image,0);gl.uniform1f(this.locations.u_width,w);
    const inUse=new Set();
    for(const layer of layers){
      const video=layer.video;
      const isImage=video instanceof HTMLImageElement;
      const sourceWidth=isImage?video.naturalWidth:video.videoWidth;
      const sourceHeight=isImage?video.naturalHeight:video.videoHeight;
      if((isImage?!video.complete:video.readyState<2)||!sourceWidth||!sourceHeight)continue;
      let texture=this.textures.get(layer.id);
      if(!texture){texture=gl.createTexture();this.textures.set(layer.id,texture);
        gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      }
      inUse.add(layer.id);
      gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      try{gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,video);}catch(_){continue;}
      const ratio=Math.min(seqWidth/sourceWidth,seqHeight/sourceHeight);
      const sx=sourceWidth*ratio*layer.scale,sy=sourceHeight*ratio*layer.scale;
      const cos=Math.cos(layer.angle*Math.PI/180),sin=Math.sin(layer.angle*Math.PI/180);
      const cx=seqWidth/2+layer.x,cy=seqHeight/2+layer.y;
      const points=[[-.5,-.5,0,0],[.5,-.5,1,0],[.5,.5,1,1],[-.5,-.5,0,0],[.5,.5,1,1],[-.5,.5,0,1]];
      const vertices=new Float32Array(24);
      for(let i=0;i<6;i++){
        const [x,y,u,v]=points[i],px=x*sx,py=y*sy;
        const xp=cx+cos*px-sin*py,yp=cy+sin*px+cos*py;
        vertices[i*4]=2*xp/seqWidth-1;
        vertices[i*4+1]=1-2*yp/seqHeight;
        vertices[i*4+2]=u;vertices[i*4+3]=v;
      }
      gl.bufferData(gl.ARRAY_BUFFER,vertices,gl.STREAM_DRAW);
      gl.uniform1f(this.locations.u_alpha,layer.alpha);
      gl.uniform1f(this.locations.u_brightness,layer.brightness);
      gl.uniform1f(this.locations.u_contrast,layer.contrast);
      gl.uniform1f(this.locations.u_saturation,layer.saturation);
      gl.uniform1f(this.locations.u_progress,layer.progress);
      gl.uniform1i(this.locations.u_transition,layer.transition);
      gl.drawArrays(gl.TRIANGLES,0,6);
    }
    for(const [id,texture] of this.textures)if(!inUse.has(id)){
      gl.deleteTexture(texture);this.textures.delete(id);
    }
    return true;
  }
}
