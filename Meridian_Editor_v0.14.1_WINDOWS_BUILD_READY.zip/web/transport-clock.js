'use strict';
// A single Web Audio clock for the timeline. Media elements are routed through
// this context, but codec seek accuracy and device latency still need validation.
class MeridianTransportClock {
 constructor(makeContext=()=>new (window.AudioContext||window.webkitAudioContext)(), fallback=()=>performance.now()/1000){
  this.makeContext=makeContext;this.fallback=fallback;this.context=null;this.frameOrigin=0;this.fps=30;
  this.timeOrigin=0;this.playing=false;this.sourceNodes=new WeakMap();
 }
 async start(frame,fps){
  if(!(fps>0)||!Number.isInteger(frame)||frame<0)throw Error('Invalid transport origin');
  if(!this.context){try{this.context=this.makeContext()}catch(_){this.context=null}}
  if(this.context?.state==='suspended')await this.context.resume();
  this.fps=fps;this.frameOrigin=frame;this.timeOrigin=this.now();this.playing=true;
 }
 now(){return this.context?this.context.currentTime:this.fallback()}
 frame(){return Math.max(0,this.frameOrigin+(this.playing?Math.floor(Math.max(0,this.now()-this.timeOrigin)*this.fps+1e-7):0))}
 reanchor(frame){this.frameOrigin=frame;this.timeOrigin=this.now()}
 pause(){this.frameOrigin=this.frame();this.playing=false}
 route(element){
  if(!this.context||this.sourceNodes.has(element))return;
  const node=this.context.createMediaElementSource(element);
  node.connect(this.context.destination);this.sourceNodes.set(element,node);
 }
 unroute(element){const node=this.sourceNodes.get(element);if(node){node.disconnect();this.sourceNodes.delete(element)}}
}
if(typeof module!=='undefined')module.exports={MeridianTransportClock};
