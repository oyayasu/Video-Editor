'use strict';
// Bound to a single server-side preview session. Only the latest requested
// timeline frame may update the monitor; obsolete requests are discarded.
class MeridianFrameClient {
 constructor(fetcher=fetch, display=()=>{}){
  this.fetcher=fetcher;this.display=display;this.url='';this.requested=null;
  this.inflight=false;this.generation=0;this.controller=null;
 }
 open(url){this.cancel();this.url=url}
 request(frame){
  if(!this.url||!Number.isInteger(frame)||frame<0)return;
  this.requested=frame;
  if(!this.inflight)this.pump();
 }
 async pump(){
  const frame=this.requested, generation=this.generation;
  this.inflight=true;this.controller=new AbortController();
  try{
   const response=await this.fetcher(`${this.url}?frame=${frame}`,{signal:this.controller.signal});
   if(!response.ok)throw Error(`Native preview HTTP ${response.status}`);
   const status=response.headers?.get?.('X-Meridian-Cache') || 'MISS';
   const data=await response.blob();
   if(this.generation===generation && this.requested===frame)this.display(data,frame,status);
  }catch(error){
   if(this.generation===generation&&error.name!=='AbortError')this.onError?.(error);
  }finally{
   if(this.generation===generation){
    this.inflight=false;this.controller=null;
    if(this.requested!==frame && this.requested!==null)this.pump();
   }
  }
 }
 cancel(){
  this.generation++;
  this.controller?.abort();this.url='';this.requested=null;this.inflight=false;this.controller=null;
 }
}
if(typeof module!=='undefined')module.exports={MeridianFrameClient};
