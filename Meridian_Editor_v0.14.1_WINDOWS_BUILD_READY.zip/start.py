"""Launch with `python start.py` (Python 3.10+ and FFmpeg)."""
from src.server import launch
if __name__=='__main__':launch()
