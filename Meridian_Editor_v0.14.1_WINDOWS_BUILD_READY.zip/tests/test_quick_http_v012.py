"""HTTP endpoints for one-click packs and text plate generator."""
import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer

from src.model import fresh, create_clip
from src.server import App, handler_factory

class QuickHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App();cls.http=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(cls.app))
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.http.server_address[1]}'
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close();cls.thread.join(timeout=2)
    def request(self,path,data=None):
        payload=json.dumps(data).encode() if data is not None else None
        headers={'X-Meridian-Token':self.app.session} if data is not None else {}
        if data is not None:headers['Content-Type']='application/json'
        with urllib.request.urlopen(urllib.request.Request(self.url+path,payload,headers),timeout=20) as r:
            return json.load(r)
    def project(self):
        d=fresh();m=dict(id='asset',path=str(Path(__file__).parent.joinpath('fixtures/sample.mp4').resolve()),
            name='source.mp4',duration_seconds=2.0,duration_frames=60,video=True,audio=True,width=320,height=180)
        d['media']=[m];d['clips']=[create_clip(m,'V1',0,0,40)];return d
    def test_session_exposes_pack_and_font_metadata(self):
        session=self.request('/api/session');self.assertGreaterEqual(len(session['quick_presets']),80)
        self.assertGreaterEqual(len(session['fonts']),35)
    def test_preset_endpoint_commits_changes_without_ignoring_kind(self):
        d=self.project();result=self.request('/api/apply-preset',
             dict(project=d,clip_id=d['clips'][0]['id'],preset_id='warm-cinema'))
        self.assertEqual(len(result['project']['clips'][0]['effects']),3)
        self.assertEqual(d['clips'][0]['effects'],[])
    def test_title_endpoint_returns_existing_alpha_asset(self):
        d=self.project();result=self.request('/api/create-title',
             dict(project=d,text='TEST TITLE',size=78,color='#FFFFFF',duration=2))
        m=result['media'];self.assertTrue(Path(m['path']).is_file());self.assertTrue(m['video'])
        self.assertEqual(m['width'],d['width'])
        from PIL import Image
        im=Image.open(m['path']);self.assertEqual(im.mode,'RGBA')
        self.assertEqual(im.getpixel((0,0))[3],0)
    def test_invalid_font_rejected_without_asset(self):
        from urllib.error import HTTPError
        d=self.project()
        with self.assertRaises(HTTPError) as cm:
            self.request('/api/create-title',dict(project=d,text='X',font_path='/tmp/missing-font.ttf'))
        self.assertEqual(cm.exception.code,400)

if __name__=='__main__':unittest.main()
