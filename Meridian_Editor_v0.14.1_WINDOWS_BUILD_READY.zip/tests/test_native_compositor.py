"""Native CPU compositor tests: pixels first, not just successful FFmpeg status."""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from src.model import fresh, create_clip, add_transition
from src.native_render import NativeCompositor, native_available, native_export, native_frame

HAVE_NATIVE = native_available() and bool(shutil.which('ffprobe'))


def sample_pixel(png_or_mp4, time=None, stdin=False):
    cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error']
    if time is not None:
        cmd += ['-ss', str(time)]
    cmd += ['-f', 'png_pipe', '-i', 'pipe:0'] if stdin else ['-i', str(png_or_mp4)]
    cmd += ['-vf', 'scale=1:1:flags=neighbor,format=rgb24', '-frames:v', '1',
            '-f', 'rawvideo', '-pix_fmt', 'rgb24', 'pipe:1']
    result = subprocess.run(cmd, input=png_or_mp4 if stdin else None, capture_output=True, check=True)
    return tuple(result.stdout)


@unittest.skipUnless(HAVE_NATIVE, 'Compile C++ compositor and install FFmpeg before running these tests')
class NativePixelTests(unittest.TestCase):
    def setUp(self):
        self.core = NativeCompositor()

    def test_api_and_opaque_black(self):
        self.assertEqual(self.core.lib.meridian_api_version(), 2)
        self.assertEqual(bytes(self.core.clear(2, 2)), bytes((0,0,0,255) * 4))
        self.assertEqual(bytes(self.core.clear(2, 2, True)), bytes(16))

    def test_half_alpha_source_over_opaque_blue(self):
        blue = self.core.clear(1,1)
        self.core.over(blue,1,1,bytes((0,0,255,255)),1,1,0,0)
        self.core.over(blue,1,1,bytes((255,0,0,255)),1,1,0,0,.5)
        self.assertEqual(tuple(blue), (128,0,128,255))

    def test_straight_alpha_preserved(self):
        result = self.core.clear(1,1,transparent=True)
        self.core.over(result,1,1,bytes((240,20,30,128)),1,1,0,0)
        self.assertEqual(tuple(result), (240,20,30,128))

    def test_cross_dissolve_and_wipe(self):
        result = self.core.clear(4,1)
        self.core.over(result,4,1,bytes((255,0,0,255)*4),4,1,0,0)
        self.core.over(result,4,1,bytes((0,0,255,255)*4),4,1,0,0,1,1,.5)
        self.assertEqual(tuple(result[0:4]), (128,0,128,255))
        result = self.core.clear(4,1)
        self.core.over(result,4,1,bytes((0,0,255,255)*4),4,1,0,0,1,2,.5)
        self.assertEqual(tuple(result[0:4]), (0,0,255,255))
        self.assertEqual(tuple(result[12:16]), (0,0,0,255))

    def test_affine_identity_matches_simple_compositor(self):
        source=bytes((255,20,0,255)*4)
        a=self.core.clear(2,2)
        b=self.core.clear(2,2)
        self.core.over(a,2,2,source,2,2,0,0)
        self.core.over_affine(b,2,2,source,2,2,1,1,1,0)
        self.assertEqual(bytes(a),bytes(b))

    def test_affine_scale_and_rotation_preserve_center_pixel(self):
        output=self.core.clear(5,5)
        self.core.over_affine(output,5,5,bytes((250,10,20,255)),1,1,2.5,2.5,2,35)
        center=tuple(output[(2*5+2)*4:(2*5+2)*4+4])
        self.assertEqual(center,(250,10,20,255))

    def test_negative_offset_clipped(self):
        result = self.core.clear(2,2)
        self.core.over(result,2,2,bytes((20,30,40,255)*4),2,2,-1,-1)
        self.assertEqual(tuple(result[0:4]), (20,30,40,255))
        self.assertEqual(tuple(result[4:8]), (0,0,0,255))

    def test_rejects_invalid_opacity(self):
        frame=self.core.clear(1,1)
        with self.assertRaisesRegex(Exception,'rejected'):
            self.core.over(frame,1,1,bytes((0,0,0,255)),1,1,0,0,1.5)


@unittest.skipUnless(HAVE_NATIVE, 'Compile C++ compositor and install FFmpeg before running these tests')
class NativeMediaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='meridian-native-tests-')
        cls.folder = Path(cls.tmp.name)
        for color in ('red', 'blue'):
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                            '-f','lavfi','-i',f'color=c={color}:s=320x180:r=30:d=2',
                            '-c:v','mpeg4',str(cls.folder/f'{color}.mp4')], check=True)

        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                        '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1',
                        str(cls.folder/'tone.wav')], check=True)

    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()

    def make_doc(self, cross=False):
        doc = fresh()
        doc['width'], doc['height']=1280,720
        doc['media']=[{'id': c, 'path':str(self.folder/f'{c}.mp4'), 'name':c,
                       'duration_seconds':2, 'video':True, 'audio':False,
                       'width':320,'height':180} for c in ('red','blue')]
        doc['clips']=[create_clip(doc['media'][0],'V1',0,duration=18)]
        if cross:
            doc['clips'].append(create_clip(doc['media'][1],'V1',9,duration=18))
            add_transition(doc,doc['clips'][0]['id'],doc['clips'][1]['id'],'cross_dissolve',9)
        return doc

    def test_still_and_export_are_visually_consistent(self):
        doc=self.make_doc()
        still=native_frame(doc,0)
        self.assertTrue(still.startswith(b'\x89PNG'))
        target=self.folder/'native-test.mp4'
        native_export(doc,str(target),'draft')
        a=sample_pixel(still, stdin=True)
        b=sample_pixel(target, time=0)
        for channel1, channel2 in zip(a,b):
            self.assertLess(abs(channel1-channel2), 10)

    def test_real_cross_dissolve_looks_purple_midpoint(self):
        doc=self.make_doc(cross=True)
        first=sample_pixel(native_frame(doc,9), stdin=True)
        middle=sample_pixel(native_frame(doc,13), stdin=True)
        last=sample_pixel(native_frame(doc,17), stdin=True)
        self.assertGreater(first[0],200)
        self.assertLess(first[2],40)
        self.assertGreater(middle[0],70)
        self.assertGreater(middle[2],70)
        self.assertLess(last[0],40)
        self.assertGreater(last[2],200)

    def test_video_with_audio_track_muxes_audio(self):
        doc = self.make_doc()
        doc['media'].append({'id':'tone', 'path':str(self.folder/'tone.wav'), 'name':'Tone',
                             'duration_seconds':1, 'video':False, 'audio':True,
                             'width':0,'height':0})
        doc['clips'].append(create_clip(doc['media'][-1], 'A1', 0, duration=18))
        target = self.folder/'native-audio-test.mp4'
        native_export(doc,str(target),'draft')
        result = subprocess.run(['ffprobe','-v','error','-select_streams','a',
                                 '-show_entries','stream=codec_name', '-of','csv=p=0',str(target)],
                                capture_output=True,text=True,check=True)
        self.assertIn('aac',result.stdout)

    def test_animated_scale_changes_coverage(self):
        doc=self.make_doc()
        c=doc['clips'][0]
        c['keyframes']['scale']=[{'frame':0,'value':1.,'interpolation':'linear'},
                                 {'frame':10,'value':0.25,'interpolation':'linear'}]
        # First frame fills canvas, later frame leaves the left edge black.
        # Compare a pixel near the left edge without averaging the whole image.
        full=native_frame(doc,0)
        small=native_frame(doc,10)
        def left_pixel(png):
            cp=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error',
                               '-f','png_pipe','-i','pipe:0',
                               '-vf','crop=1:1:10:360,format=rgb24',
                               '-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],
                              input=png,capture_output=True,check=True)
            return tuple(cp.stdout)
        self.assertGreater(left_pixel(full)[0],200)
        self.assertEqual(left_pixel(small),(0,0,0))

    def test_animated_x_and_opacity_change_pixel(self):
        doc=self.make_doc()
        clip=doc['clips'][0]
        clip['keyframes']['opacity']=[{'frame':0,'value':0.,'interpolation':'linear'},
                                      {'frame':10,'value':1.,'interpolation':'linear'}]
        beginning=sample_pixel(native_frame(doc,0),stdin=True)
        ending=sample_pixel(native_frame(doc,10),stdin=True)
        self.assertEqual(beginning,(0,0,0))
        self.assertGreater(ending[0],200)
        clip['keyframes']['x']=[{'frame':0,'value':0.,'interpolation':'linear'},
                                 {'frame':10,'value':1280.,'interpolation':'linear'}]
        outside=sample_pixel(native_frame(doc,10), stdin=True)
        self.assertEqual(outside,(0,0,0))

if __name__=='__main__':unittest.main()
