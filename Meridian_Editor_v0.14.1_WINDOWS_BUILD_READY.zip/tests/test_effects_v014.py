"""Effects workspace regression: original presets, matte validation and export.

Use a generated FFmpeg fixture from previous tests; no Adobe assets are used.
"""
import copy
import io
import math
import shutil
import unittest
from pathlib import Path

from src.after_effects_fx import AE_EFFECTS, COMPOSITE_EFFECTS, COMPOSITE_TYPES, filter_for
from src.effects import EFFECTS, create_instance
from src.masks import new_mask, mask_filter
from src.model import fresh, create_clip, validate
from src.render import render_frame

FIXTURE=Path(__file__).parent/'fixtures'/'sample.mp4'

class EffectsModelV014(unittest.TestCase):
    def setUp(self):
        self.doc=fresh()
        self.media={'id':'f','path':str(FIXTURE.resolve()),'name':'sample.mp4',
                    'duration_seconds':3.,'video':True,'audio':True,'width':160,'height':90}
        self.doc['media']=[self.media]
        self.clip=create_clip(self.media,'V1',0,duration=10)
        self.doc['clips']=[self.clip]

    def test_effects_registered_and_not_duplicate(self):
        self.assertEqual(16,len(AE_EFFECTS))
        self.assertEqual(2,len(COMPOSITE_EFFECTS))
        self.assertEqual(len(EFFECTS),len({e['type'] for e in EFFECTS}))
        for entry in AE_EFFECTS+COMPOSITE_EFFECTS:
            with self.subTest(type=entry['type']):
                self.clip['effects']=[create_instance(entry['type'])]
                validate(self.doc)
                if entry['type'] not in COMPOSITE_TYPES:
                    self.assertTrue(filter_for(entry['type'],self.clip['effects'][0]['params']))

    def test_mask_validation_and_legacy_document(self):
        self.clip.pop('masks')
        validate(self.doc)
        self.clip['masks']=[new_mask('rectangle'),new_mask('ellipse')]
        validate(self.doc)
        self.assertIn('alpha(X,Y)',mask_filter(self.clip))
        self.clip['masks'][1]['id']=self.clip['masks'][0]['id']
        with self.assertRaisesRegex(ValueError,'duplicated'):validate(self.doc)

    def test_invalid_numbers_and_data(self):
        cases=[('x',float('nan')),('y',-0.1),('width',0),('height',1.2),('feather',.26),('opacity',2)]
        for key,value in cases:
            with self.subTest(key=key):
                mask=new_mask();mask[key]=value
                self.clip['masks']=[mask]
                with self.assertRaises(ValueError):validate(self.doc)

    def test_masks_rejected_on_audio(self):
        self.clip['track']='A1';self.clip['masks']=[new_mask()]
        with self.assertRaisesRegex(ValueError,'video'):validate(self.doc)

    def test_subtract_and_intersection_generate_different_mattes(self):
        self.clip['masks']=[new_mask('ellipse')]
        add=mask_filter(self.clip)
        self.clip['masks'][0]['mode']='subtract'
        sub=mask_filter(self.clip)
        self.assertNotEqual(add,sub)
        self.clip['masks'].append(new_mask('rectangle'))
        self.clip['masks'][1]['mode']='intersect'
        self.assertIn('min(',mask_filter(self.clip))

    def test_alpha_preservation_and_disabled_masks(self):
        self.clip['masks']=[new_mask()]
        self.clip['masks'][0]['enabled']=False
        self.assertIsNone(mask_filter(self.clip))

@unittest.skipUnless(shutil.which('ffmpeg') and FIXTURE.exists(), 'FFmpeg fixture required')
class EffectsRenderV014(unittest.TestCase):
    def prepare(self):
        d=fresh();d['width']=1280;d['height']=720
        m={'id':'f','path':str(FIXTURE.resolve()),'name':'sample.mp4',
           'duration_seconds':3,'video':True,'audio':True,'width':160,'height':90}
        d['media']=[m];c=create_clip(m,'V1',0,duration=5);d['clips']=[c]
        return d,c

    def test_every_new_effect_renders_frame(self):
        for entry in AE_EFFECTS+COMPOSITE_EFFECTS:
            with self.subTest(effect=entry['type']):
                d,c=self.prepare();c['effects']=[create_instance(entry['type'])]
                output=render_frame(d,1,False)
                self.assertTrue(output.startswith(b'\x89PNG\r\n\x1a\n'))
                self.assertGreater(len(output),2500)

    def test_composite_order_and_stacked_geometric_masks(self):
        d,c=self.prepare()
        c['effects']=[create_instance('ae_sepia'),create_instance('ae_glow'),create_instance('ae_drop_shadow')]
        c['masks']=[new_mask('ellipse'),new_mask('rectangle')]
        c['masks'][1]['mode']='intersect'
        out=render_frame(d,1,False)
        self.assertGreater(len(out),3000)

    def test_geometric_mattes_have_real_coverage(self):
        from PIL import Image
        for shape in ('ellipse','rectangle'):
            with self.subTest(shape=shape):
                d,c=self.prepare();m=new_mask(shape);m['feather']=0;c['masks']=[m]
                pic=Image.open(io.BytesIO(render_frame(d,1,False))).convert('RGB')
                center=sum(pic.getpixel((640,360)))
                outside=sum(pic.getpixel((80,80)))
                self.assertGreater(center,outside+30)

    def test_drop_shadow_preserves_foreground_and_shades_background(self):
        from PIL import Image,ImageDraw
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            base=Image.new('RGBA',(1280,720),(245,245,245,255))
            overlay=Image.new('RGBA',(1280,720),(0,0,0,0))
            ImageDraw.Draw(overlay).rectangle([400,250,600,450],fill=(220,20,15,255))
            background=Path(tmp)/'background.png';foreground=Path(tmp)/'foreground.png'
            base.save(background);overlay.save(foreground)
            d=fresh();d['width']=1280;d['height']=720
            a=dict(id='background',path=str(background),name='background.png',duration_seconds=1,
                   video=True,audio=False,width=1280,height=720)
            b=dict(id='foreground',path=str(foreground),name='foreground.png',duration_seconds=1,
                   video=True,audio=False,width=1280,height=720)
            d['media']=[a,b]
            aclip=create_clip(a,'V1',0,duration=3)
            bclip=create_clip(b,'V2',0,duration=3)
            bclip['effects']=[create_instance('ae_drop_shadow')]
            d['clips']=[aclip,bclip]
            img=Image.open(io.BytesIO(render_frame(d,1,False))).convert('RGB')
            self.assertEqual((220,20,15),img.getpixel((550,350)))
            self.assertLess(img.getpixel((605,350))[0],180)
            self.assertEqual((245,245,245),img.getpixel((300,200)))

    def test_inverted_mask_hides_center(self):
        from PIL import Image
        d,c=self.prepare();m=new_mask('ellipse');m['mode']='subtract';m['feather']=0;c['masks']=[m]
        pic=Image.open(io.BytesIO(render_frame(d,1,False))).convert('RGB')
        self.assertGreater(sum(pic.getpixel((80,80))),sum(pic.getpixel((640,360)))+30)

if __name__=='__main__':unittest.main()

# Explicit native guard: never silently omit a complex effect in export.
class NativeFeatureGuardV014(unittest.TestCase):
    def test_native_rejects_new_mattes_and_compositing_filters(self):
        from src.native_render import NativeTimeline, RenderError
        doc=fresh()
        m={'id':'f','path':str(FIXTURE.resolve()),'name':'sample.mp4',
           'duration_seconds':3,'video':True,'audio':True,'width':160,'height':90}
        doc['media']=[m]
        c=create_clip(m,'V1',0,duration=5)
        doc['clips']=[c]
        c['masks']=[new_mask()]
        with self.assertRaisesRegex(RenderError, 'masks require FFmpeg'):
            NativeTimeline(doc)
        c['masks']=[]
        c['effects']=[create_instance('ae_glow')]
        with self.assertRaisesRegex(RenderError, 'require FFmpeg'):
            NativeTimeline(doc)
