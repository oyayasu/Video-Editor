"""Fast release-configuration checks. These do not emulate a Windows build."""
import ast
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class BuildLayoutTests(unittest.TestCase):
    def test_python_entry_and_desktop_module_compile(self):
        for name in ('desktop_entry.py', 'src/desktop.py'):
            with self.subTest(name=name):
                ast.parse((ROOT / name).read_text(encoding='utf-8'))

    def test_installer_contains_no_machine_wide_dependency(self):
        installer = (ROOT / 'packaging/meridian.iss').read_text(encoding='utf-8')
        self.assertIn('PrivilegesRequired=lowest', installer)
        self.assertIn('MeridianEditor.exe', installer)
        self.assertIn('recursesubdirs', installer)
        self.assertIn('ArchitecturesAllowed=x64compatible', installer)
        self.assertNotIn('python.exe', installer)

    def test_bundle_contains_required_assets_and_native_optional(self):
        spec = (ROOT / 'packaging/meridian.spec').read_text(encoding='utf-8')
        for item in ('desktop_entry.py', 'web', 'ffmpeg.exe', 'ffprobe.exe',
                     'meridian_compositor.dll', 'PySide6.QtWebEngineCore'):
            with self.subTest(item=item):
                self.assertIn(item, spec)

    def test_workflow_only_manual_trigger_and_uploads_artifacts(self):
        workflow = (ROOT / '.github/workflows/build-windows.yml').read_text(encoding='utf-8')
        self.assertRegex(workflow, r'on:\s*\n\s*workflow_dispatch:')
        for piece in ('windows-2022', 'setup-python@v5', 'build-windows.ps1',
                      'upload-artifact@v4', 'Meridian-Windows-v0.14.1'):
            self.assertIn(piece, workflow)
        self.assertNotRegex(workflow, r'\n\s*push:')

    def test_release_zip_does_not_contain_dependency_binaries(self):
        self.assertFalse((ROOT / 'packaging/_stage/ffmpeg-release-essentials.zip').exists())
        self.assertTrue((ROOT / 'packaging/THIRD_PARTY_NOTICES.md').is_file())


if __name__ == '__main__':
    unittest.main()
