"""Loopback API contract tests with a temporary server instance."""
from __future__ import annotations

import copy
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from src.server import App, handler_factory
from src.model import create_clip, fresh, media_item
from src.media import ffprobe
from src.native_render import native_available
from pathlib import Path


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(cls.app))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.base=f'http://127.0.0.1:{cls.server.server_address[1]}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def request(self,path,data=None):
        encoded=json.dumps(data).encode() if data is not None else None
        headers={'X-Meridian-Token':self.app.session, 'Content-Type':'application/json'} if data is not None else {}
        request=urllib.request.Request(self.base+path,data=encoded,headers=headers)
        with urllib.request.urlopen(request,timeout=25) as response:
            return json.load(response) if 'application/json' in response.headers['Content-Type'] else response.read()

    def project(self):
        doc=fresh()
        m={'id':'testasset','name':'footage.mp4','path':'/some/absolute/file.mp4','video':True,'audio':False,
           'duration_seconds':10,'width':1280,'height':720}
        doc['media']=[m]
        doc['clips']=[create_clip(m,'V1',0,duration=12)]
        return doc

    def test_session_exposes_effect_registry(self):
        result=self.request('/api/session')
        self.assertEqual(len(result['effects']),67)
        self.assertEqual(len({effect['type'] for effect in result['effects']}),67)
        self.assertIsInstance(self.request('/effects-ui.js'),bytes)
        self.assertEqual(result['native'],native_available())

    def test_operations_through_http(self):
        doc=self.project()
        chosen=doc['clips'][0]['id']
        duplicate=self.request('/api/timeline-edit',{'project':doc,'action':'duplicate','clip_id':chosen})
        self.assertEqual(len(duplicate['project']['clips']),2)
        split=self.request('/api/timeline-edit',{'project':doc,'action':'split','clip_id':chosen,'frame':6})
        self.assertEqual(len(split['project']['clips']),2)
        deleted=self.request('/api/timeline-edit',{'project':doc,'action':'ripple-delete','clip_id':chosen})
        self.assertEqual(len(deleted['project']['clips']),0)

    def test_two_source_transition_over_http(self):
        doc=self.project()
        another=copy.deepcopy(doc['clips'][0])
        another['id']='second-clip';another['start']=6
        doc['clips'].append(another)
        result=self.request('/api/add-transition',{
            'project':doc,'outgoing':doc['clips'][0]['id'],
            'incoming':another['id'],'type':'cross_dissolve','duration':4})
        self.assertEqual(len(result['project']['transitions']),1)
        self.assertEqual(result['transition']['duration'],4)

    def test_rendered_frame_http_returns_real_png(self):
        fixture=Path(__file__).parent/'fixtures'/'sample.mp4'
        if not fixture.exists():self.skipTest('No fixture')
        doc=fresh();doc.update(width=1280,height=720)
        m=media_item(fixture,ffprobe(fixture));doc['media']=[m]
        doc['clips']=[create_clip(m,'V1',0,duration=12)]
        raw=self.request('/api/preview-frame',{'project':doc,'frame':4,'captions':False})
        self.assertTrue(raw.startswith(b'\x89PNG\r\n\x1a\n'))

    @unittest.skipUnless(native_available(), 'Native compositor not compiled')
    def test_native_rendered_frame_http(self):
        fixture=Path(__file__).parent/'fixtures'/'sample.mp4'
        if not fixture.exists():self.skipTest('No fixture')
        doc=fresh();doc.update(width=1280,height=720)
        m=media_item(fixture,ffprobe(fixture));doc['media']=[m]
        doc['clips']=[create_clip(m,'V1',0,duration=12)]
        result=self.request('/api/preview-frame',{
            'project':doc,'frame':4,'captions':False,'engine':'native'})
        self.assertTrue(result.startswith(b'\x89PNG\r\n\x1a\n'))

    @unittest.skipUnless(native_available(), 'Native compositor not compiled')
    def test_native_export_http(self):
        import tempfile,time
        fixture=Path(__file__).parent/'fixtures'/'sample.mp4'
        if not fixture.exists():self.skipTest('No fixture')
        doc=fresh();doc.update(width=1280,height=720)
        m=media_item(fixture,ffprobe(fixture));doc['media']=[m]
        doc['clips']=[create_clip(m,'V1',0,duration=8)]
        with tempfile.TemporaryDirectory() as folder:
            target=str(Path(folder)/'native-via-http.mp4')
            self.request('/api/export',{'project':doc,'path':target,
                                       'preset':'draft','burn_captions':False,'engine':'native'})
            status={}
            for _ in range(80):
                status=self.request('/api/export-status')
                if status['state']!='working':break
                time.sleep(.1)
            self.assertEqual(status['state'],'done',status)
            self.assertGreater(Path(target).stat().st_size,100)

    def test_frame_endpoint_rejects_invalid_index(self):
        fixture=Path(__file__).parent/'fixtures'/'sample.mp4'
        if not fixture.exists():self.skipTest('No fixture')
        doc=fresh();doc.update(width=1280,height=720)
        m=media_item(fixture,ffprobe(fixture));doc['media']=[m]
        doc['clips']=[create_clip(m,'V1',0,duration=12)]
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/api/preview-frame',{'project':doc,'frame':999})
        self.assertEqual(error.exception.code,400)

    def test_rejects_missing_session_token(self):
        encoded=json.dumps({'project':fresh(),'frame':0}).encode()
        request=urllib.request.Request(self.base+'/api/preview-frame',
                                       data=encoded,headers={'Content-Type':'application/json'})
        with self.assertRaises(urllib.error.HTTPError) as err:
            urllib.request.urlopen(request,timeout=5)
        self.assertEqual(err.exception.code,403)

    def test_fresh_project_endpoint(self):
        result=self.request('/api/new-project',{})
        self.assertEqual(result['project']['clips'],[])
        self.assertEqual(result['project']['schema'],1)


if __name__=='__main__':unittest.main()
