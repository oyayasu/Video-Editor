"""Tests for editorial operations shared by UI and model."""
import copy
import unittest

from src.model import create_clip, duplicate_clip, fresh, nest_clips, ripple_delete, split, validate
from src.effects import create_instance


class TimelineOperationTests(unittest.TestCase):
    def setUp(self):
        self.doc=fresh()
        m={'id':'m', 'path':'/path/to/media.mov','name':'media.mov',
           'duration_seconds':12,'video':True,'audio':True,'width':1280,'height':720}
        self.doc['media']=[m]
        self.clip=create_clip(m,'V1',10,0,20)
        self.clip['effects']=[create_instance('gamma')]
        self.doc['clips']=[self.clip,create_clip(m,'V1',30,0,18),create_clip(m,'A1',30,0,18)]

    def test_duplicate_deep_copies_effects(self):
        extra=duplicate_clip(self.doc,self.clip['id'])
        self.assertEqual(extra['start'],30)
        self.assertNotEqual(extra['id'],self.clip['id'])
        self.assertEqual(extra['effects'],self.clip['effects'])
        extra['effects'][0]['params']['gamma']=1.6
        self.assertEqual(self.clip['effects'][0]['params']['gamma'],1)
        validate(self.doc)

    def test_ripple_only_moves_later_clips_on_its_track(self):
        ripple_delete(self.doc,self.clip['id'])
        remaining={c['track']:c for c in self.doc['clips']}
        self.assertEqual(remaining['V1']['start'],10)
        self.assertEqual(remaining['A1']['start'],30)
        validate(self.doc)

    def test_ripple_rejects_overlapping_clip(self):
        self.doc['clips'][1]['start']=20
        before=copy.deepcopy(self.doc)
        with self.assertRaisesRegex(ValueError,'overlapping'):ripple_delete(self.doc,self.clip['id'])
        self.assertEqual(self.doc,before)

    def test_nested_split_and_duplicate_preserve_effects(self):
        seq,_=nest_clips(self.doc,[self.clip['id']])
        inner=seq['clips'][0]
        other=split(self.doc,inner['id'],10,seq['id'])
        self.assertEqual(other['source_in'],10)
        self.assertEqual(other['effects'],inner['effects'])
        dupe=duplicate_clip(self.doc,other['id'],seq['id'])
        self.assertEqual(dupe['start'],20)
        validate(self.doc)

    def test_locked_tracks_rejected(self):
        for track in self.doc['tracks']:
            if track['id']=='V1':track['locked']=True
        with self.assertRaisesRegex(ValueError,'locked'):duplicate_clip(self.doc,self.clip['id'])
        with self.assertRaisesRegex(ValueError,'locked'):ripple_delete(self.doc,self.clip['id'])
        with self.assertRaisesRegex(ValueError,'locked'):split(self.doc,self.clip['id'],11)


if __name__=='__main__':unittest.main()
