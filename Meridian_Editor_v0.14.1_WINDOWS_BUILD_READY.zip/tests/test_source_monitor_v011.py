"""v0.11 Source/Program editorial regression tests: ranges, patching, atomicity."""
import copy
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from src.model import create_clip, fresh, save, load, validate
from src.server import App, handler_factory
from src.source_monitor import source_frame_count, three_point_edit


class SourceEditingTests(unittest.TestCase):
    def setUp(self):
        self.doc = fresh()
        self.media = dict(id='source-1', name='source.mp4', path='/tmp/source-1.mp4',
                          duration_seconds=12.0, video=True, audio=True, width=1920, height=1080)
        self.doc['media'] = [self.media]

    def edit(self, operation='overwrite', **kwargs):
        return three_point_edit(self.doc,operation, asset_id=self.media['id'], **kwargs)

    def test_source_count_and_project_roundtrip(self):
        self.assertEqual(source_frame_count(self.media, 30),360)
        self.doc['source_ranges'][self.media['id']]={'in':25,'out':61}
        validate(self.doc)
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'project.meridian';save(self.doc,file)
            self.assertEqual(load(file)['source_ranges']['source-1'],{'in':25,'out':61})

    def test_legacy_project_without_markers(self):
        self.doc.pop('source_ranges')
        validate(self.doc)
        self.assertEqual(self.edit(video_track='V1',source_in=0,source_out=10)[2]['duration'],10)

    def test_invalid_marker_metadata(self):
        invalid=[{'in':10,'out':10},{'in':-1,'out':9},{'in':2,'out':361},
                 {'in':False,'out':15},{'in':'1','out':5},{'in':12,'out':3}]
        for pair in invalid:
            self.doc['source_ranges']={'source-1':pair}
            with self.subTest(pair=pair),self.assertRaises(ValueError):validate(self.doc)

    def test_single_source_video_patch(self):
        out,ids,range_=self.edit(video_track='V2',source_in=11,source_out=42,program_in=75)
        c=out['clips'][0]
        self.assertEqual((c['track'],c['start'],c['source_in'],c['duration']),('V2',75,11,31))
        self.assertEqual(ids,[c['id']])
        self.assertEqual(range_['program_out'],106)
        self.assertEqual(self.doc['clips'],[])

    def test_audio_only_patch(self):
        out,ids,_=self.edit(video_track=None,audio_track='A2',source_in=5,source_out=25,program_in=0)
        self.assertEqual(len(ids),1)
        self.assertEqual((out['clips'][0]['track'],out['clips'][0]['duration']),('A2',20))

    def test_overwrite_both_patches_split_existing_clips(self):
        for target in ('V1','A1'):
            self.doc['clips'].append(create_clip(self.media,target,10,3,90))
        before=copy.deepcopy(self.doc)
        out,ids,_=self.edit(video_track='V1',audio_track='A1',source_in=15,source_out=45,program_in=30)
        self.assertEqual(len(ids),2)
        for kind in ('V1','A1'):
            clips=[c for c in out['clips'] if c['track']==kind]
            self.assertEqual(sorted((c['start'],c['duration']) for c in clips),[(10,20),(30,30),(60,40)])
            self.assertEqual(next(c for c in clips if c['start']==30)['source_in'],15)
        self.assertEqual(self.doc,before)
        validate(out)

    def test_insert_both_patches_ripples_only_once(self):
        for track in ('V1','A1','V2'):
            self.doc['clips'].append(create_clip(self.media,track,60,0,15))
        out,ids,rng=self.edit('insert',video_track='V1',audio_track='A1',source_in=30,source_out=42,program_in=40)
        self.assertEqual(len(ids),2)
        self.assertEqual(rng['duration'],12)
        for track in ('V1','A1','V2'):
            self.assertIn((72,15),[(c['start'],c['duration']) for c in out['clips'] if c['track']==track])
        for track in ('V1','A1'):
            self.assertIn((40,12),[(c['start'],c['duration']) for c in out['clips'] if c['track']==track])
        validate(out)

    def test_insert_crosses_split_audio_video_and_captions(self):
        for track in ('V1','A1'):
            self.doc['clips'].append(create_clip(self.media,track,0,0,100))
        self.doc['captions']=[dict(id='subtitle',start=12,duration=80,text='hello')]
        out,_,_=self.edit('insert',video_track='V1',audio_track='A1',source_in=0,source_out=10,program_in=30)
        for track in ('V1','A1'):
            self.assertEqual(sorted((c['start'],c['duration']) for c in out['clips'] if c['track']==track),[(0,30),(30,10),(40,70)])
        self.assertEqual(sorted((c['start'],c['duration']) for c in out['captions']),[(12,18),(40,62)])

    def test_reverse_three_point_source_out_only(self):
        out,_,rng=self.edit(video_track='V1',source_out=45,program_in=10,program_out=30)
        self.assertEqual((rng['source_in'],rng['source_out'],rng['duration']),(25,45,20))
        self.assertEqual(out['clips'][0]['source_in'],25)

    def test_forward_three_point_source_in_only(self):
        _,_,rng=self.edit(video_track='V1',source_in=100,program_in=0,program_out=25)
        self.assertEqual((rng['source_in'],rng['source_out'],rng['duration']),(100,125,25))

    def test_default_source_range_entire_media(self):
        _,_,rng=self.edit(video_track='V1',program_in=0)
        self.assertEqual(rng['duration'],360)

    def test_four_point_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError,'durations disagree'):
            self.edit(video_track='V1',source_in=0,source_out=10,program_in=5,program_out=20)

    def test_atomicity_for_failed_second_patch(self):
        next(t for t in self.doc['tracks'] if t['id']=='A1')['locked']=True
        before=copy.deepcopy(self.doc)
        with self.assertRaisesRegex(ValueError,'locked'):
            self.edit('insert',video_track='V1',audio_track='A1',source_in=0,source_out=20,program_in=5)
        self.assertEqual(self.doc,before)

    def test_incompatible_source_and_target(self):
        self.media['audio']=False
        with self.assertRaisesRegex(ValueError,'no audio stream'):
            self.edit(audio_track='A1',source_in=0,source_out=20,program_in=5)
        with self.assertRaisesRegex(ValueError,'Invalid or locked'):
            self.edit(video_track='A1',source_in=0,source_out=20,program_in=5)

    def test_source_out_boundary_is_exclusive(self):
        _,_,r=self.edit(video_track='V1',source_in=359,source_out=360,program_in=5)
        self.assertEqual(r['duration'],1)
        with self.assertRaises(ValueError):
            self.edit(video_track='V1',source_in=360,source_out=361,program_in=5)

    def test_no_patches_or_boolean_frames_rejected(self):
        with self.assertRaisesRegex(ValueError,'patch'):
            self.edit(video_track=None,audio_track=None)
        for field in ('source_in','source_out','program_in','program_out'):
            with self.subTest(field=field),self.assertRaises(ValueError):
                kwargs={'video_track':'V1','source_in':3,'source_out':15,'program_in':5}
                kwargs[field]=True
                self.edit(**kwargs)

    def test_insert_nested_is_explicitly_unsupported(self):
        with self.assertRaisesRegex(ValueError,'nested'):
            self.edit('insert',video_track='V1',source_in=0,source_out=5,container_id='missing')

    def test_edit_never_mutates_project_on_invalid_handles(self):
        before=copy.deepcopy(self.doc)
        with self.assertRaises(ValueError):
            self.edit(video_track='V1',source_in=355,program_in=0,program_out=20)
        self.assertEqual(before,self.doc)


class SourceApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(cls.app))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.server.server_address[1]}'
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)
    def request(self,body,authorized=True):
        req=urllib.request.Request(self.url+'/api/source-edit',data=json.dumps(body).encode(),
            headers={'Content-Type':'application/json',**({'X-Meridian-Token':self.app.session} if authorized else {})})
        with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
    def project(self):
        d=fresh();d['media']=[dict(id='one',name='test.mp4',path='/tmp/test.mp4',duration_seconds=3.,
                                  video=True,audio=True,width=1280,height=720)]
        return d
    def test_http_two_stream_edit(self):
        doc=self.project()
        result=self.request(dict(project=doc,action='insert',asset_id='one',video_track='V1',audio_track='A1',
                                 source_in=3,source_out=15,program_in=10))
        self.assertEqual(len(result['clip_ids']),2)
        self.assertEqual({c['track'] for c in result['project']['clips']},{'A1','V1'})
        self.assertEqual(result['range']['duration'],12)
    def test_http_invalid_request_is_atomic(self):
        doc=self.project()
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request(dict(project=doc,action='insert',asset_id='one',video_track='V1',audio_track='A1',
                              source_in=89,source_out=99,program_in=10))
        self.assertEqual(caught.exception.code,400)
    def test_http_denies_unauthorized_request(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request(dict(project=self.project(),action='overwrite',asset_id='one',video_track='V1'),authorized=False)
        self.assertEqual(caught.exception.code,403)

if __name__=='__main__': unittest.main()
