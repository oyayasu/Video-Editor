"""End-to-end HTTP tests against the loopback server for v0.10 editing actions."""
from __future__ import annotations
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from src.server import App,handler_factory,clean_shortcuts
from src.model import fresh,create_clip

class EditingHttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(cls.app))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.server.server_address[1]}'
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)
    def project(self):
        d=fresh()
        media={'id':'m','name':'media.mp4','path':'/tmp/whatever.mp4','video':True,'audio':True,
               'duration_seconds':10.,'width':1280,'height':720}
        d['media']=[media]
        d['clips']=[create_clip(media,'V1',15,5,20)]
        return d
    def req(self,path,body,token=True):
        request=urllib.request.Request(self.url+path,data=json.dumps(body).encode(),
                                       headers={'Content-Type':'application/json',**({'X-Meridian-Token':self.app.session} if token else {})})
        with urllib.request.urlopen(request,timeout=10) as res:return json.load(res)
    def test_edit_pipeline_creates_a_valid_result(self):
        doc=self.project();clip=doc['clips'][0]
        answer=self.req('/api/editorial-edit',dict(project=doc,action='trim-left',clip_id=clip['id'],frame=20))
        out=answer['project']['clips'][0]
        self.assertEqual((out['start'],out['source_in'],out['duration']),(20,10,15))
        self.assertEqual(doc['clips'][0]['start'],15)
    def test_three_point_insert_and_add_track_over_http(self):
        doc=self.project()
        updated=self.req('/api/editorial-edit',dict(project=doc,action='add-track',track_kind='video'))['project']
        self.assertIn('V3',[t['id'] for t in updated['tracks']])
        result=self.req('/api/editorial-edit',dict(project=updated,action='insert',asset='m',track='V3',start=16,source_in=0,duration=8))
        self.assertEqual(len(result['project']['clips']),3)
        self.assertEqual(result['selected_id'], next(c['id'] for c in result['project']['clips'] if c['track']=='V3'))
    def test_rejects_untrusted_request(self):
        with self.assertRaises(urllib.error.HTTPError) as e:
            self.req('/api/editorial-edit',dict(project=self.project(),action='slip',clip_id='bad',delta=1),token=False)
        self.assertEqual(e.exception.code,403)
    def test_legacy_shortcuts_can_be_loaded_without_losing_bindings(self):
        old={'save':'Ctrl+S','undo':'Ctrl+Z','redo':'Ctrl+Shift+Z'}
        self.assertEqual(clean_shortcuts(old,partial=True),old)
        with self.assertRaises(ValueError):clean_shortcuts(old)

    def test_media_offline_status_in_session(self):
        with urllib.request.urlopen(self.url+'/api/session') as response:data=json.load(response)
        self.assertIn('missing_media',data)
        self.assertIsInstance(data['missing_media'],list)

if __name__=='__main__':unittest.main()
