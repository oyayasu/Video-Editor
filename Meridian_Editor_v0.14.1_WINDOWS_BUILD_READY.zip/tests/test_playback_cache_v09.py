"""Frame-addressed native preview, cache eviction, seeking and audio-clock tests."""
from __future__ import annotations

import json
import shutil
import subprocess
import threading
import unittest
from unittest.mock import patch
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from src.frame_cache import FrameSessionRegistry, NativeFrameCache, jpeg_frame
from src.model import create_clip, fresh
from src.native_render import native_available
from src.server import App, handler_factory
from src.hardware import candidates, probe_encoder, available_h264_encoder

ROOT = Path(__file__).resolve().parent


def project():
    sample = ROOT / 'fixtures' / 'sample.mp4'
    doc = fresh()
    doc['width'], doc['height'] = 1280, 720
    doc['media'] = [{'id': 'sample', 'path': str(sample), 'name': 'sample',
                     'duration_seconds': 2, 'video': True, 'audio': False,
                     'width': 320, 'height': 180}]
    doc['clips'] = [create_clip(doc['media'][0], 'V1', 0, duration=12)]
    return doc


class PreviewEncodingTests(unittest.TestCase):
    def test_pillow_optional_and_ffmpeg_fallback_both_produce_jpeg(self):
        rgba = bytes((220, 40, 30, 255)) * (320 * 180)
        for use_fallback in (False, True):
            with self.subTest(fallback=use_fallback):
                if use_fallback:
                    with patch('src.frame_cache.Image', None):
                        output = jpeg_frame(rgba, 320, 180, 320)
                else:
                    output = jpeg_frame(rgba, 320, 180, 320)
                self.assertTrue(output.startswith(b'\xff\xd8'))
                self.assertTrue(output.endswith(b'\xff\xd9'))


class HardwareDetectionTests(unittest.TestCase):
    def test_encoder_order_matches_platform(self):
        self.assertEqual(candidates('darwin'), ('h264_videotoolbox',))
        self.assertEqual(candidates('win32')[0], 'h264_amf')

    def test_probe_does_not_accept_unrecognized_names(self):
        self.assertFalse(probe_encoder('h264_fake'))

    def test_detection_is_hardware_gated_not_just_listed(self):
        # No guaranteed GPU in test environment; returning None is valid.
        self.assertIn(available_h264_encoder(), (None,*candidates()))


class FakeCache:
    def __init__(self, doc):
        self.closed = False
        self.requests = []

    def get(self, frame):
        self.requests.append(frame)
        return b'image', False

    def close(self):
        self.closed = True


class RegistryTests(unittest.TestCase):
    def test_replacement_and_stop_release_resources(self):
        registry = FrameSessionRegistry(factory=FakeCache)
        first = registry.start(project())
        previous = registry._session[2]
        second = registry.start(project())
        self.assertNotEqual(first, second)
        self.assertTrue(previous.closed)
        with self.assertRaises(KeyError): registry.get(first, 0)
        self.assertEqual(registry.get(second, 3), (b'image', False))
        registry.stop()
        self.assertTrue(registry._session is None)

    def test_inactivity_expires_session(self):
        now = [0]
        registry = FrameSessionRegistry(factory=FakeCache, monotonic=lambda: now[0])
        token = registry.start(project())
        now[0] = 121
        with self.assertRaises(KeyError):registry.get(token, 0)
        self.assertIsNone(registry._session)

    def test_invalid_cache_sizes_and_frame(self):
        with self.assertRaises(ValueError):NativeFrameCache(project(), max_bytes=5)
        with self.assertRaises(ValueError):NativeFrameCache(project(), width=1)
        with NativeFrameCache(project()) as cache:  # explicitly registered below
            with self.assertRaises(ValueError):cache.get(500)


@unittest.skipUnless(native_available(), 'Native C++ compositor required')
class NativeFrameTests(unittest.TestCase):
    def test_cache_hit_and_backwards_random_seek(self):
        cache = NativeFrameCache(project(), max_bytes=128*1024, width=320)
        try:
            a, hit = cache.get(7)
            self.assertFalse(hit)
            self.assertTrue(a.startswith(b'\xff\xd8') and a.endswith(b'\xff\xd9'))
            b, hit = cache.get(7)
            self.assertTrue(hit)
            self.assertEqual(a, b)
            first, _ = cache.get(0)
            later, _ = cache.get(10)
            self.assertNotEqual(first, later)
            self.assertLessEqual(cache.cached_bytes, cache.limit)
            self.assertEqual(cache.get(7)[0], a)
        finally:
            cache.close()
            self.assertEqual(cache.cached_bytes, 0)

    def test_encoder_failure_drops_broken_decoder_and_recovers(self):
        cache = NativeFrameCache(project(), max_bytes=128*1024, width=320)
        try:
            with patch('src.frame_cache.jpeg_frame', side_effect=RuntimeError('encoder stopped')):
                with self.assertRaisesRegex(RuntimeError, 'encoder stopped'):
                    cache.get(2)
            self.assertIsNone(cache._timeline)
            self.assertEqual(cache._last, -1)
            image, hit = cache.get(2)
            self.assertFalse(hit)
            self.assertTrue(image.startswith(b'\xff\xd8'))
        finally:
            cache.close()

    def test_lru_evicts_when_memory_is_bounded(self):
        cache = NativeFrameCache(project(), max_bytes=1800, width=320)
        try:
            for frame in (0, 1, 2, 3):cache.get(frame)
            self.assertLessEqual(cache.cached_bytes, 1800)
            self.assertGreater(cache.misses, 0)
        finally:cache.close()


@unittest.skipUnless(native_available(), 'Native C++ compositor required')
class HTTPFrameTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = App()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), handler_factory(cls.app))
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = 'http://127.0.0.1:' + str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.app.frame_cache.stop()
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(3)

    def request(self, path, payload=None, auth=True):
        headers = {'Content-Type': 'application/json'}
        if auth:headers['X-Meridian-Token'] = self.app.session
        body = json.dumps(payload).encode() if payload is not None else None
        return urllib.request.urlopen(urllib.request.Request(self.url+path, body, headers=headers), timeout=25)

    def test_request_by_frame_with_expiring_ticket(self):
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request('/api/native-preview-start', {'project':project()},auth=False)
        self.assertEqual(denied.exception.code, 403)
        with self.request('/api/native-preview-start', {'project':project()}) as res:
            url = json.load(res)['url']
        with self.request(url+'?frame=6') as res:
            jpeg = res.read()
            self.assertEqual(res.headers['X-Meridian-Cache'],'MISS')
            self.assertTrue(jpeg.startswith(b'\xff\xd8'))
        with self.request(url+'?frame=6') as res:
            self.assertEqual(res.headers['X-Meridian-Cache'],'HIT')
            self.assertEqual(res.read(),jpeg)
        with self.assertRaises(urllib.error.HTTPError) as invalid:
            self.request(url+'?frame=-1')
        self.assertEqual(invalid.exception.code, 400)
        with self.request('/api/native-preview-stop', {}) as res:
            self.assertTrue(json.load(res)['ok'])
        with self.assertRaises(urllib.error.HTTPError) as expired:
            self.request(url+'?frame=6')
        self.assertEqual(expired.exception.code, 404)


@unittest.skipUnless(shutil.which('node'), 'Node.js required')
class JavaScriptPlaybackTests(unittest.TestCase):
    def node(self, source):
        run = subprocess.run(['node', '-e', source], cwd=str(ROOT.parent), capture_output=True, text=True, timeout=15)
        self.assertEqual(run.returncode,0,run.stderr)

    def test_audio_clock_advances_pauses_and_seeks(self):
        self.node('''
const assert=require('node:assert/strict');
const {MeridianTransportClock}=require('./web/transport-clock');
let time=0;
const context={state:'running',get currentTime(){return time},destination:{},createMediaElementSource(el){return {connect(){}}}};
(async()=>{
const c=new MeridianTransportClock(()=>context,()=>-100);
await c.start(10,30);time=0.11;assert.equal(c.frame(),13);
c.reanchor(120);time=0.21;assert.equal(c.frame(),123);
c.pause();time=4;assert.equal(c.frame(),123);
let routes=0;context.createMediaElementSource=()=>{routes++;return {connect(){}}};
const e={};c.route(e);c.route(e);assert.equal(routes,1);
})().catch(e=>{console.error(e);process.exitCode=1});''')

    def test_client_forwards_cache_diagnostic(self):
        self.node('''
const assert=require('node:assert/strict');
const {MeridianFrameClient}=require('./web/frame-client');
let result;
const c=new MeridianFrameClient(async()=>({ok:true,headers:{get:()=> 'HIT'},blob:async()=> 'jpeg'}),
(blob,frame,status)=>{result={blob,frame,status}});
(async()=>{
 c.open('/api/native-frame/token');c.request(5);
 await new Promise(resolve=>setImmediate(resolve));
 assert.deepEqual(result,{blob:'jpeg',frame:5,status:'HIT'});
})().catch(e=>{console.error(e);process.exitCode=1});''')

    def test_client_discards_late_frames_and_can_cancel(self):
        self.node('''
const assert=require('node:assert/strict');
const {MeridianFrameClient}=require('./web/frame-client');
let callbacks=[],deferred=[];
const c=new MeridianFrameClient((url)=>new Promise(resolve=>deferred.push(()=>resolve({ok:true,blob:async()=>({url})}))),(_,f)=>callbacks.push(f));
(async()=>{
c.open('/api/native-frame/abc');c.request(1);c.request(2);
deferred.shift()();await new Promise(r=>setImmediate(r));
assert.deepEqual(callbacks,[]);
deferred.shift()();await new Promise(r=>setImmediate(r));
assert.deepEqual(callbacks,[2]);
c.cancel();c.request(3);assert.deepEqual(callbacks,[2]);
})().catch(e=>{console.error(e);process.exitCode=1});''')


if __name__ == '__main__': unittest.main()
