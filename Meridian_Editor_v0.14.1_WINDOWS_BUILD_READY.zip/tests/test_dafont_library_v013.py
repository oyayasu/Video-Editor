"""Tests for curated DaFont import and local title rendering.
Synthetic archives contain a renamed system font, not downloaded DaFont bytes.
No third-party font assets are included in the distributable source archive.
"""
import base64
import io
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from src import font_library
from src.server import App, handler_factory
from src.titles import create_title


SYSTEM_FONTS = (
    Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
    Path('/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf'),
)


def available_font():
    for path in SYSTEM_FONTS:
        if path.is_file():
            return path.read_bytes()
    raise unittest.SkipTest('No local font available for synthetic archive validation')


def archive_bytes(member_name='PublicPixel.ttf', content=None):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('fonts/' + member_name, available_font() if content is None else content)
        z.writestr('LICENSE.txt', 'Synthetic fixture only; not a downloaded DaFont font.')
    return buf.getvalue()


class DaFontLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.library = Path(self.temp.name) / 'fonts'

    def test_all_sources_are_dafont_and_explicitly_free_commercial(self):
        fonts = font_library.catalog(self.library)
        self.assertEqual(17, len(fonts))
        self.assertEqual(len({f['id'] for f in fonts}), 17)
        for item in fonts:
            self.assertTrue(item['source'].startswith('https://www.dafont.com/'))
            self.assertIn(item['license'], ('SIL OFL 1.1', 'CC0 1.0'))
            self.assertTrue(item['commercial_use'])
            self.assertFalse(item['bundled'])
            self.assertFalse(item['installed'])

    def test_import_zip_and_generate_transparent_title(self):
        raw = archive_bytes()
        result = font_library.import_archive('public-pixel', base64.b64encode(raw).decode(), self.library)
        self.assertEqual(['PublicPixel.ttf'], result['installed_files'])
        font = font_library.catalog(self.library)
        self.assertTrue(next(f for f in font if f['id']=='public-pixel')['installed'])
        path = font_library.font_path('public-pixel', 'PublicPixel.ttf', self.library)
        self.assertEqual(available_font(), Path(path).read_bytes())
        title_path = create_title(text='Teste de fonte', width=1280, height=720, size=74,
                                  directory=Path(self.temp.name) / 'titles', font_path=path)
        from PIL import Image
        img = Image.open(title_path).convert('RGBA')
        self.assertEqual((1280,720), img.size)
        self.assertEqual(0, img.getpixel((0,0))[3])
        self.assertGreater(img.getchannel('A').getbbox()[2], 0)

    def test_reject_personal_use_or_unknown_family(self):
        with self.assertRaisesRegex(ValueError, 'catálogo'):
            font_library.import_archive('available', base64.b64encode(archive_bytes()).decode(), self.library)

    def test_zip_wrong_font_rejected_without_files_written(self):
        with self.assertRaisesRegex(ValueError, 'não contém'):
            font_library.import_archive('public-pixel', base64.b64encode(archive_bytes('Other.ttf')).decode(), self.library)
        self.assertFalse((self.library/'public-pixel').exists())

    def test_corrupt_font_rejected(self):
        with self.assertRaisesRegex(ValueError, 'inválido'):
            font_library.import_archive('public-pixel', base64.b64encode(archive_bytes(content=b'Fake font')).decode(), self.library)

    def test_oversized_archive_rejected(self):
        with self.assertRaisesRegex(ValueError, 'grande'):
            font_library.import_archive('public-pixel', 'a'* (font_library.MAX_ARCHIVE_BYTES * 4), self.library)

    def test_variant_traversal_rejected(self):
        raw = archive_bytes()
        font_library.import_archive('public-pixel', base64.b64encode(raw).decode(), self.library)
        for variant in ('../PublicPixel.ttf', 'evil.ttf', '/etc/passwd'):
            with self.assertRaises(ValueError):
                font_library.font_path('public-pixel', variant, self.library)

    def test_api_import_then_use_font_for_title(self):
        # A real HTTP loopback request against the same handler shipped in the app.
        import src.server as server
        app=App()
        with patch.object(server, 'FONT_LIBRARY', self.library), patch.object(server, 'CACHE', Path(self.temp.name)):
            http=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(app))
            thread=threading.Thread(target=http.serve_forever,daemon=True)
            thread.start()
            try:
                url=f'http://127.0.0.1:{http.server_address[1]}'
                def req(endpoint, data=None):
                    payload=json.dumps(data).encode() if data is not None else None
                    headers={'Host':'127.0.0.1'}
                    if data is not None:
                        headers.update({'Content-Type':'application/json', 'X-Meridian-Token':app.session})
                    r=urllib.request.Request(url+endpoint,data=payload,headers=headers)
                    with urllib.request.urlopen(r,timeout=15) as res:
                        return res.read(),res.headers
                response,_=req('/api/session')
                self.assertEqual(54,len(json.loads(response)['fonts']))
                uploaded,_=req('/api/import-dafont',{'family_id':'public-pixel','archive_base64':base64.b64encode(archive_bytes()).decode()})
                self.assertTrue(next(f for f in json.loads(uploaded)['fonts'] if f['id']=='public-pixel')['installed'])
                data,headers=req('/api/installed-font/public-pixel/PublicPixel.ttf')
                self.assertEqual(available_font(),data)
                self.assertIn('font/ttf',headers.get('Content-Type'))
                project=app.project
                made,_=req('/api/create-title',{'project':project,'text':'VIDEOTEST','size':80,
                    'duration':1, 'font_id':'public-pixel','font_variant':'PublicPixel.ttf'})
                self.assertTrue(Path(json.loads(made)['media']['path']).is_file())
            finally:
                http.shutdown();http.server_close();thread.join(5)

if __name__=='__main__': unittest.main()
