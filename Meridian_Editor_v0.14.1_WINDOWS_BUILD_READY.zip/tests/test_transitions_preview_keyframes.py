"""Regression tests for true two-source transitions and the export/preview graph.

The fixtures are generated using FFmpeg at test time, so we can assert actual
pixel behavior instead of just a successful FFmpeg return code.
"""
import copy
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from src.model import (add_transition, create_clip, fresh, load, media_item,
                       ripple_delete, save, split, validate, nest_clips)
from src.effects import create_instance, effect_value_at, filters_for
from src.render import render, render_frame, make_command

HAS_FFMPEG=bool(shutil.which('ffmpeg') and shutil.which('ffprobe'))


def raw_pixel_samples(data, from_file=False, frame=None):
    """Get left/center/right RGB pixels after nearest-neighbor 3x1 resize."""
    args=['ffmpeg','-hide_banner','-loglevel','error']
    if from_file:
        args.extend(['-i',str(data),'-vf',f'select=eq(n\\,{frame}),scale=3:1:flags=neighbor,format=rgb24'])
    else:
        args.extend(['-f','image2pipe','-c:v','png','-i','pipe:0',
                     '-vf','scale=3:1:flags=neighbor,format=rgb24'])
    args.extend(['-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
    cp=subprocess.run(args,input=None if from_file else data,capture_output=True,check=True)
    if len(cp.stdout)!=9:raise AssertionError('Expected exactly 3 RGB pixels')
    return [tuple(cp.stdout[i:i+3]) for i in (0,3,6)]


class TransitionModelTests(unittest.TestCase):
    def setUp(self):
        self.doc=fresh()
        self.doc['media']=[{'id':f'm{i}','path':f'/fake-{i}.mp4','name':f'm{i}',
                            'duration_seconds':4,'video':True,'audio':True,'width':320,'height':180}
                           for i in range(2)]
        self.a=create_clip(self.doc['media'][0],'V1',0,duration=45)
        self.b=create_clip(self.doc['media'][1],'V1',30,duration=45)
        self.doc['clips']=[self.a,self.b]

    def test_old_project_without_transition_field_remains_valid(self):
        self.doc.pop('transitions')
        validate(self.doc)

    def test_create_and_roundtrip(self):
        t=add_transition(self.doc,self.b['id'],self.a['id'],'cross_dissolve',12)
        self.assertEqual(t['start'],30)
        self.assertEqual(t['duration'],12)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'test.meridian';save(self.doc,path)
            self.assertEqual(load(path)['transitions'],self.doc['transitions'])

    def test_rejects_wrong_track_and_nonoverlap(self):
        self.b['track']='V2'
        with self.assertRaisesRegex(ValueError,'same track'):add_transition(self.doc,self.a['id'],self.b['id'])
        self.b['track']='V1';self.b['start']=50
        with self.assertRaisesRegex(ValueError,'Overlap'):add_transition(self.doc,self.a['id'],self.b['id'])

    def test_rejects_bad_transition_length(self):
        with self.assertRaisesRegex(ValueError,'exceeds'):add_transition(self.doc,self.a['id'],self.b['id'],duration=16)

    def test_rejects_stale_transition_reference(self):
        add_transition(self.doc,self.a['id'],self.b['id'],duration=9)
        self.doc['transitions'][0]['incoming']='nobody'
        with self.assertRaisesRegex(ValueError,'missing'):validate(self.doc)

    def test_split_prunes_transition_and_preserves_effect_curves(self):
        fx=create_instance('brightness_contrast');fx['keyframes']={'brightness':[
            dict(frame=0,value=-.25,interpolation='linear'),
            dict(frame=40,value=.25,interpolation='linear')]}
        self.a['effects']=[fx]
        add_transition(self.doc,self.a['id'],self.b['id'],duration=12)
        right=split(self.doc,self.a['id'],20)
        self.assertEqual(self.doc['transitions'],[])
        self.assertAlmostEqual(effect_value_at(self.a['effects'][0],'brightness',19),-.0125,places=4)
        self.assertAlmostEqual(effect_value_at(right['effects'][0],'brightness',0),0.0,places=4)

    def test_ripple_refuses_to_delete_overlapping_transition(self):
        add_transition(self.doc,self.a['id'],self.b['id'],duration=12)
        # The edit is refused due to overlap, without silently orphaning a transition.
        with self.assertRaisesRegex(ValueError,'overlapping'):ripple_delete(self.doc,self.a['id'])
        self.assertEqual(len(self.doc['transitions']),1)

    def test_nest_preserves_internal_transition(self):
        original=add_transition(self.doc,self.a['id'],self.b['id'],duration=9)
        seq,refs=nest_clips(self.doc,[self.a['id'],self.b['id']])
        self.assertEqual(len(seq['transitions']),1)
        self.assertEqual(seq['transitions'][0]['start'],original['start'])
        self.assertEqual(self.doc['transitions'],[])
        validate(self.doc)

    def test_transition_creation_is_atomic_on_error(self):
        add_transition(self.doc,self.a['id'],self.b['id'],duration=12)
        before=copy.deepcopy(self.doc['transitions'])
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            add_transition(self.doc,self.a['id'],self.b['id'],duration=9)
        self.assertEqual(self.doc['transitions'],before)

    def test_animatable_effect_keys_validate(self):
        fx=create_instance('saturation')
        fx['keyframes']={'amount':[{'frame':0,'value':0,'interpolation':'ease'},
                                   {'frame':30,'value':3,'interpolation':'linear'}]}
        self.a['effects']=[fx];validate(self.doc)
        self.assertAlmostEqual(effect_value_at(fx,'amount',15),1.5)
        self.assertIn('eval=frame',filters_for(self.a,30,'video')[0])
        fx['keyframes']['amount'][1]['frame']=50
        with self.assertRaisesRegex(ValueError,'effect keyframe'):validate(self.doc)

    def test_unsupported_animated_filter_rejected(self):
        fx=create_instance('mosaic');fx['keyframes']={'block':[{'frame':0,'value':8}]}
        self.a['effects']=[fx]
        with self.assertRaisesRegex(ValueError,'Unsupported effect'):validate(self.doc)

    def test_audio_transitions_are_separate(self):
        self.a['track']='A1';self.b['track']='A1'
        good=add_transition(self.doc,self.a['id'],self.b['id'],'audio_crossfade',10)
        self.assertEqual(good['type'],'audio_crossfade')
        self.doc['transitions'].clear()
        with self.assertRaisesRegex(ValueError,'incompatible'):add_transition(self.doc,self.a['id'],self.b['id'],'cross_dissolve',10)


@unittest.skipUnless(HAS_FFMPEG,'FFmpeg and FFprobe required')
class TransitionVideoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder=tempfile.TemporaryDirectory()
        root=Path(cls.folder.name)
        cls.files={}
        for color in ('red','blue'):
            path=root/(color+'.mp4')
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                            '-i',f'color=c={color}:s=320x180:r=30:d=2',
                            '-c:v','libx264','-pix_fmt','yuv420p',str(path)],check=True)
            cls.files[color]=path

    @classmethod
    def tearDownClass(cls):cls.folder.cleanup()

    def video_doc(self,transition):
        doc=fresh();doc.update(width=1280,height=720,fps=30)
        items=[media_item(self.files[color],{'duration':2,'video':True,'audio':False,'width':320,'height':180})
               for color in ('red','blue')]
        doc['media']=items
        a=create_clip(items[0],'V1',0,duration=45)
        b=create_clip(items[1],'V1',30,duration=45)
        doc['clips']=[a,b]
        add_transition(doc,a['id'],b['id'],transition,15)
        return doc

    def test_cross_dissolve_blends_both_sources(self):
        doc=self.video_doc('cross_dissolve')
        start=raw_pixel_samples(render_frame(doc,30))[1]
        middle=raw_pixel_samples(render_frame(doc,36))[1]
        end=raw_pixel_samples(render_frame(doc,44))[1]
        self.assertGreater(start[0],230);self.assertLess(start[2],20)
        self.assertGreater(middle[0],80);self.assertGreater(middle[2],70)
        self.assertGreater(end[2],220);self.assertLess(end[0],20)

    def test_wipe_has_left_and_right_different_at_midpoint(self):
        doc=self.video_doc('wipe_left')
        left,center,right=raw_pixel_samples(render_frame(doc,36))
        self.assertGreater(left[2],230)
        self.assertGreater(right[0],230)
        self.assertLess(center[2],50)

    def test_preview_is_consistent_with_mp4_export_at_same_frame(self):
        doc=self.video_doc('cross_dissolve')
        png=render_frame(doc,36)
        with tempfile.TemporaryDirectory() as td:
            mp4=Path(td)/'comparison.mp4';render(doc,mp4,'draft')
            snapshot=raw_pixel_samples(png)
            encoded=raw_pixel_samples(mp4,from_file=True,frame=36)
        for pixel_a,pixel_b in zip(snapshot,encoded):
            self.assertLess(max(abs(a-b) for a,b in zip(pixel_a,pixel_b)),15)

    def test_animated_brightness_changes_generated_pixels(self):
        doc=self.video_doc('cross_dissolve');doc['clips']=doc['clips'][:1];doc['transitions']=[]
        fx=create_instance('brightness_contrast')
        fx['keyframes']={'brightness':[{'frame':0,'value':-.35},{'frame':30,'value':.35}]}
        doc['clips'][0]['effects']=[fx]
        dark=raw_pixel_samples(render_frame(doc,2))[1]
        bright=raw_pixel_samples(render_frame(doc,35))[1]
        self.assertGreater(sum(bright),sum(dark)+50)

    def test_animated_audio_gain_export(self):
        from src.media import ffprobe
        source=Path(__file__).parent/'fixtures'/'sample.mp4'
        if not source.exists():self.skipTest('No audio fixture')
        m=media_item(source,ffprobe(source))
        doc=fresh();doc.update(width=1280,height=720);doc['media']=[m]
        audio=create_clip(m,'A1',0,duration=24)
        effect=create_instance('audio_gain')
        effect['keyframes']={'gain':[{'frame':0,'value':-12},{'frame':20,'value':12}]}
        audio['effects']=[effect];doc['clips']=[audio]
        validate(doc)
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'gain.mp4';render(doc,out,'draft')
            self.assertTrue(ffprobe(out)['audio'])

    def test_audio_crossfade_export(self):
        source=Path(__file__).parent/'fixtures'/'sample.mp4'
        from src.media import ffprobe
        if not source.exists() or not ffprobe(source)['audio']:self.skipTest('No audio fixture')
        m=media_item(source,ffprobe(source));doc=fresh();doc.update(width=1280,height=720)
        doc['media']=[m]
        # Clip duration under source length; incoming starts within the outgoing.
        count=min(24,int(m['duration_seconds']*30)-2)
        if count<14:self.skipTest('Audio sample is too short')
        a=create_clip(m,'A1',0,duration=count)
        b=create_clip(m,'A1',count-10,duration=count)
        doc['clips']=[a,b]
        add_transition(doc,a['id'],b['id'],'audio_crossfade',8)
        command=' '.join(make_command(doc,'/tmp/audio-crossfade.mp4','draft'))
        self.assertIn('afade=t=in:st=0:d=0.26666667',command)
        self.assertIn('afade=t=out:st=0.46666667:d=0.26666667',command)
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'audio-crossfade.mp4';render(doc,output,'draft')
            self.assertGreater(output.stat().st_size,3000)
            self.assertTrue(ffprobe(output)['audio'])


if __name__=='__main__':unittest.main()
