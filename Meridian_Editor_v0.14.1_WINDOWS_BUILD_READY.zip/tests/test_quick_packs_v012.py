"""Quick Edit regressions: authored recipes, license metadata, and export paths."""
from __future__ import annotations
import copy
from pathlib import Path
import unittest

from src.model import fresh, create_clip, add_transition, validate
from src.quick_packs import PRESETS, font_catalog, apply_preset, catalog
from src.render import make_command, render_frame

FIXTURE=Path(__file__).parent/'fixtures'/'sample.mp4'

def project(kind='video', duration=55):
    doc=fresh()
    media={'id':'fixture','path':str(FIXTURE.resolve()),'name':'sample.mp4',
           'duration_frames':60,'duration_seconds':2.0,'video':True,'audio':True,
           'width':320,'height':180}
    doc['media']=[media]
    doc['width']=1280;doc['height']=720
    c=create_clip(media,'V1' if kind=='video' else 'A1',0,0,duration)
    doc['clips']=[c]
    return doc,c

class QuickPackTests(unittest.TestCase):
    def test_all_recipes_validate_and_do_not_mutate_input(self):
        for recipe in PRESETS:
            with self.subTest(recipe=recipe['id']):
                doc,clip=project(recipe['kind'])
                original=copy.deepcopy(doc)
                applied=apply_preset(doc,clip['id'],recipe['id'])
                validate(applied)
                self.assertEqual(doc,original)
                self.assertEqual(applied['clips'][0]['id'],clip['id'])

    def test_catalog_unique_and_explicitly_versioned(self):
        self.assertEqual(len(catalog()),len(PRESETS))
        self.assertEqual(len({p['id'] for p in PRESETS}),len(PRESETS))
        self.assertGreaterEqual(len(PRESETS),80)
        self.assertNotIn('effects',catalog()[0])

    def test_font_manifest_no_bundled_files(self):
        fonts=font_catalog()
        self.assertGreaterEqual(len(fonts),35)
        self.assertTrue(all(f['commercial_use'] and not f['bundled'] for f in fonts))
        self.assertEqual(37,len([f for f in fonts if f['provider']=='Google Fonts']))
        self.assertEqual(17,len([f for f in fonts if f['provider']=='DaFont']))

    def test_invalid_presets_leave_source_unchanged(self):
        doc,clip=project()
        for pid in ['missing','voice-clear']:
            with self.assertRaisesRegex(ValueError,'Unknown preset|incompatible'):
                apply_preset(doc,clip['id'],pid)
        self.assertEqual(doc['clips'][0]['effects'],[])

    def test_locked_track_rejected(self):
        doc,clip=project();next(t for t in doc['tracks'] if t['id']=='V1')['locked']=True
        with self.assertRaisesRegex(ValueError,'locked'):
            apply_preset(doc,clip['id'],'bright-airy')

    def test_motion_only_replaces_target_axis(self):
        doc,clip=project()
        clip['keyframes']={'y':[{'frame':0,'value':20,'interpolation':'hold'}]}
        applied=apply_preset(doc,clip['id'],'motion-in-left-smooth')
        self.assertEqual(applied['clips'][0]['keyframes']['y'],clip['keyframes']['y'])
        self.assertEqual(applied['clips'][0]['keyframes']['x'][-1]['value'],0)

    def test_audio_preset_builds_ffmpeg(self):
        doc,clip=project('audio')
        doc=apply_preset(doc,clip['id'],'voice-clear')
        cmd=make_command(doc,Path('/tmp/preview.mp4'),'draft')
        self.assertIn('highpass=f=', ''.join(cmd))
        self.assertIn('acompressor=', ''.join(cmd))

    def test_color_recipe_real_export_still(self):
        doc,clip=project()
        doc=apply_preset(doc,clip['id'],'warm-cinema')
        data=render_frame(doc,5)
        self.assertTrue(data.startswith(b'\x89PNG\r\n\x1a\n'))

    def test_motion_recipe_real_export_still(self):
        doc,clip=project()
        doc=apply_preset(doc,clip['id'],'motion-in-bottom-fast')
        data=render_frame(doc,2)
        self.assertTrue(data.startswith(b'\x89PNG\r\n\x1a\n'))

    def test_all_video_transition_variants_render(self):
        types=['cross_dissolve','wipe_left','wipe_right','wipe_up','wipe_down',
               'soft_wipe_left','soft_wipe_right','soft_wipe_up','soft_wipe_down',
               'diagonal_tl','diagonal_br','circle_reveal']
        # Exhaustive 12-way smoke rendered manually; CI samples two here.
        for typ in ('soft_wipe_right','circle_reveal'):
            with self.subTest(transition=typ):
                doc,a=project(duration=30)
                b=copy.deepcopy(a)
                b['id']='second';b['start']=20;b['duration']=30
                doc['clips'].append(b)
                add_transition(doc,a['id'],b['id'],typ,10)
                image=render_frame(doc,22)
                self.assertTrue(image.startswith(b'\x89PNG\r\n\x1a\n'))

    def test_unsupported_native_transitions_reject_instead_of_silent_noop(self):
        import inspect
        from src.native_render import NativeTimeline
        self.assertIn('Extended transitions require FFmpeg Stable', inspect.getsource(NativeTimeline))

if __name__=='__main__': unittest.main()
