import tempfile
import threading
import time
import unittest
from pathlib import Path

from src.desktop import DialogDispatcher
from src import server


class PackagingTests(unittest.TestCase):
    def test_backend_can_be_started_and_stopped(self):
        httpd = server.make_server()
        self.assertEqual(httpd.server_address[0], '127.0.0.1')
        self.assertGreater(httpd.server_address[1], 0)
        httpd.server_close()

    def test_dialog_requests_from_worker_are_serviced(self):
        dispatcher = DialogDispatcher()
        output = []
        t = threading.Thread(target=lambda: output.extend(dispatcher.request('media')))
        t.start()
        for _ in range(100):
            if not dispatcher.pending.empty():
                break
            time.sleep(0.005)
        self.assertTrue(dispatcher.process_one(lambda mode: ['/tmp/a.mp4']))
        t.join(timeout=2)
        self.assertFalse(t.is_alive())
        self.assertEqual(output, ['/tmp/a.mp4'])

    def test_dialog_invalid_mode(self):
        dispatcher = DialogDispatcher()
        with self.assertRaises(ValueError):
            dispatcher.request('cmd')

    def test_request_provider_restored(self):
        previous = server.DESKTOP_DIALOG_PROVIDER
        try:
            server.DESKTOP_DIALOG_PROVIDER = lambda mode: ['x']
            self.assertEqual(server.native_dialog('media'), ['x'])
        finally:
            server.DESKTOP_DIALOG_PROVIDER = previous

    def test_canceled_dialog(self):
        dispatcher = DialogDispatcher()
        output = []
        t = threading.Thread(target=lambda: output.append(dispatcher.request('export')))
        t.start()
        for _ in range(100):
            if not dispatcher.pending.empty(): break
            time.sleep(.005)
        self.assertTrue(dispatcher.process_one(lambda mode: []))
        t.join(timeout=2)
        self.assertEqual(output, [[]])


if __name__ == '__main__':
    unittest.main()
