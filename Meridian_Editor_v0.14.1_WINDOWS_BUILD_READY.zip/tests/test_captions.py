import json
import unittest
from unittest.mock import patch
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from src.captions import map_segments_to_clip, subtitles_to_text, recognize
from src.model import fresh, validate
from src.server import clean_workspace

class CaptionTests(unittest.TestCase):
    def test_source_in_trim_and_offset(self):
        clip={'start':90,'source_in':60,'duration':90}
        segments=[{'start':0,'end':1,'text':'too early'},
                  {'start':1.8,'end':2.5,'text':' first '},
                  {'start':4.5,'end':6,'text':' last '},
                  {'start':6,'end':7,'text':'too late'}]
        captions=map_segments_to_clip(segments,clip,30)
        self.assertEqual(captions,[{'start':90,'duration':15,'text':'first'},
                                   {'start':165,'duration':15,'text':'last'}])
    def test_srt_and_vtt_timing(self):
        captions=[{'id':'a','start':45,'duration':30,'text':'Olá, mundo'}]
        self.assertIn('00:00:01,500 --> 00:00:02,500',subtitles_to_text(captions,30))
        self.assertIn('00:00:01.500 --> 00:00:02.500',subtitles_to_text(captions,30,'vtt'))
        self.assertTrue(subtitles_to_text(captions,30,'vtt').startswith('WEBVTT'))
    def test_round_trip_project_captions(self):
        d=fresh();d['captions']=[{'id':'caption1','start':5,'duration':28,'text':'Hello'}]
        self.assertIs(validate(d),d)
        self.assertEqual(json.loads(json.dumps(d))['captions'],d['captions'])
    def test_bad_caption_time(self):
        d=fresh();d['captions']=[{'id':'a','start':3.25,'duration':3,'text':'x'}]
        with self.assertRaises(ValueError):validate(d)
    def test_optional_local_recognizer_adapter_with_mock(self):
        events=[]
        class FakeModel:
            def __init__(self,model,device,compute_type):
                self.assertions=(model,device,compute_type)
                self_test=self.assertions
                if self_test!=('large-v3-turbo','cpu','int8'):
                    raise AssertionError(self_test)
            def transcribe(self,path,language,beam_size,vad_filter,word_timestamps):
                if language!='pt' or beam_size!=5 or not word_timestamps:
                    raise AssertionError('Unexpected recognizer parameters')
                segments=[SimpleNamespace(start=.2,end=.8,text=' Olá ')]
                return segments,SimpleNamespace(duration=1.0)
        fake=SimpleNamespace(WhisperModel=FakeModel)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'audio.wav';path.write_bytes(b'fixture')
            with patch.dict(sys.modules,{'faster_whisper':fake}):
                result=recognize(path,model='turbo',language='pt',progress=lambda message,n:events.append((message,n)))
        self.assertEqual(result,[{'start':.2,'end':.8,'text':'Olá'}])
        self.assertGreaterEqual(len(events),2)
    def test_bad_workspace(self):
        with self.assertRaises(ValueError):clean_workspace({'order':['library','library','viewer'],'left':20,'right':20,'timeline':400})
    def test_good_workspace(self):
        layout={'order':['inspector','viewer','library'],'left':22,'right':32,'timeline':385}
        self.assertEqual(clean_workspace(layout),layout)

if __name__=='__main__':unittest.main()
