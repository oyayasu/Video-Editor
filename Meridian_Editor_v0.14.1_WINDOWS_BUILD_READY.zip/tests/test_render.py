import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from src.model import fresh, media_item, create_clip
from src.media import ffprobe
from src.render import render, make_command, RenderError

FIXTURE=Path(__file__).parent/'fixtures'/'sample.mp4'

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe') and FIXTURE.exists(), 'FFmpeg and test sample required')
class ExportTests(unittest.TestCase):
    def doc(self):
        d=fresh();d['width']=1280;d['height']=720;d['fps']=30
        m=media_item(FIXTURE,ffprobe(FIXTURE));d['media']=[m]
        return d,m
    def test_export_animation_audio(self):
        doc,m=self.doc()
        v=create_clip(m,'V1',0,0,24)
        v['keyframes']['x']=[{'frame':0,'value':-100,'interpolation':'ease'},
                              {'frame':23,'value':100,'interpolation':'linear'}]
        a=create_clip(m,'A1',0,0,24)
        doc['clips']=[v,a]
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'result.mp4'
            render(doc,file,'draft')
            info=ffprobe(file)
            self.assertTrue(info['video'])
            self.assertTrue(info['audio'])
            self.assertAlmostEqual(info['duration'],.8,delta=.08)
    def test_static_color_blur_rotation(self):
        doc,m=self.doc()
        c=create_clip(m,'V1',0,0,24);doc['clips']=[c]
        c['properties'].update(opacity=.75,brightness=.12,contrast=1.1,blur=.5,rotation=4)
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'render.mp4';render(doc,file,'draft')
            self.assertGreater(file.stat().st_size,1000)
    def test_render_with_embedded_subtitles(self):
        doc,m=self.doc()
        doc['clips']=[create_clip(m,'V1',0,0,24)]
        doc['captions']=[{'id':'sub1','start':3,'duration':15,'text':'Meridian test'}]
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'captioned.mp4'
            render(doc,file,'draft',burn_captions=True)
            info=ffprobe(file)
            self.assertTrue(info['video'])
            self.assertGreater(file.stat().st_size,1500)
    def test_disallows_missing_media(self):
        doc,m=self.doc()
        doc['clips']=[create_clip(m,'V1',0,0,20)]
        m['path']='/this/path/does/not/exist.mp4'
        with self.assertRaises(RenderError):make_command(doc,'/tmp/nowhere.mp4')
if __name__=='__main__':unittest.main()
