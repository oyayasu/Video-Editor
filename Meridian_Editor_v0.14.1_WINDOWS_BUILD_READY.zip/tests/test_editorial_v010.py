"""Regression tests for trim, slip, roll, three-point overwrite and relink."""
import copy
from pathlib import Path
import tempfile
import unittest

from src.model import fresh, create_clip, validate
from src.editorial import apply_edit, relink


class EditingOperations(unittest.TestCase):
    def setUp(self):
        self.doc = fresh()
        self.media = {'id':'source', 'path':'/tmp/test.mov','name':'test.mov',
                      'video':True, 'audio':True, 'duration_seconds':12,
                      'width':1920, 'height':1080}
        self.doc['media'] = [self.media]
        self.a=create_clip(self.media,'V1',20,10,30)
        self.b=create_clip(self.media,'V1',50,60,25)
        self.doc['clips']=[self.a,self.b]

    def apply(self,action,**kwargs):
        return apply_edit(self.doc,action,**kwargs)

    def test_trim_left_rebases_source_and_keyframes(self):
        self.a['keyframes']={'opacity':[{'frame':0,'value':0,'interpolation':'linear'},
                                        {'frame':20,'value':1,'interpolation':'linear'}]}
        doc,_=self.apply('trim-left',clip_id=self.a['id'],frame=30)
        clip=doc['clips'][0]
        self.assertEqual((clip['start'],clip['source_in'],clip['duration']),(30,20,20))
        self.assertEqual(clip['keyframes']['opacity'][0]['value'],.5)
        self.assertEqual(clip['keyframes']['opacity'][1]['frame'],10)
        self.assertEqual(self.a['start'],20)

    def test_trim_right_preserves_timeline(self):
        doc,_=self.apply('trim-right',clip_id=self.a['id'],frame=35)
        self.assertEqual((doc['clips'][0]['start'],doc['clips'][0]['duration']),(20,15))

    def test_trim_left_extend_uses_available_handle(self):
        doc,_=self.apply('trim-left',clip_id=self.a['id'],frame=13)
        self.assertEqual((doc['clips'][0]['start'],doc['clips'][0]['source_in'],doc['clips'][0]['duration']),(13,3,37))

    def test_trim_beyond_handles_is_atomic(self):
        original=copy.deepcopy(self.doc)
        with self.assertRaises(ValueError):self.apply('trim-left',clip_id=self.a['id'],frame=0)
        self.assertEqual(self.doc,original)

    def test_slip_media_without_moving_timeline_or_animation(self):
        self.a['keyframes']={'x':[{'frame':4,'value':10,'interpolation':'ease'}]}
        doc,_=self.apply('slip',clip_id=self.a['id'],delta=8)
        edited=doc['clips'][0]
        self.assertEqual((edited['start'],edited['source_in'],edited['duration']),(20,18,30))
        self.assertEqual(edited['keyframes'],self.a['keyframes'])

    def test_slip_invalid_no_mutation(self):
        original=copy.deepcopy(self.doc)
        with self.assertRaisesRegex(ValueError,'handles'):self.apply('slip',clip_id=self.a['id'],delta=-11)
        self.assertEqual(self.doc,original)

    def test_roll_advances_cut_without_moving_far_edges(self):
        doc,_=self.apply('roll',outgoing=self.a['id'],incoming=self.b['id'],frame=55)
        a,b=doc['clips']
        self.assertEqual((a['start'],a['duration'],b['start'],b['duration'],b['source_in']), (20,35,55,20,65))
        self.assertEqual(b['start']+b['duration'],75)

    def test_roll_backward_into_media_handles(self):
        doc,_=self.apply('roll',outgoing=self.a['id'],incoming=self.b['id'],frame=45)
        a,b=doc['clips']
        self.assertEqual((a['duration'],b['start'],b['source_in'],b['duration']),(25,45,55,30))

    def test_roll_gap_rejected(self):
        self.b['start']=51
        with self.assertRaisesRegex(ValueError,'shared cut'):self.apply('roll',outgoing=self.a['id'],incoming=self.b['id'],frame=53)

    def test_roll_locked_track_rejected(self):
        next(t for t in self.doc['tracks'] if t['id']=='V1')['locked']=True
        with self.assertRaisesRegex(ValueError,'locked'):self.apply('roll',outgoing=self.a['id'],incoming=self.b['id'],frame=55)

    def test_overwrite_splits_source_clip_and_preserves_outer_segments(self):
        doc, selected=self.apply('overwrite',asset=self.media['id'],track='V1',start=30,source_in=100,duration=10)
        self.assertEqual(len(doc['clips']),4)
        self.assertEqual(sorted((c['start'],c['duration']) for c in doc['clips']),[(20,10),(30,10),(40,10),(50,25)])
        right=next(c for c in doc['clips'] if c['start']==40)
        self.assertEqual(right['source_in'],30)
        self.assertIn(selected,{c['id'] for c in doc['clips']})

    def test_overwrite_crosses_multiple_clips(self):
        doc, selected=self.apply('overwrite',asset=self.media['id'],track='V1',start=25,source_in=120,duration=40)
        spans=sorted((c['start'],c['duration']) for c in doc['clips'])
        self.assertEqual(spans,[(20,5),(25,40),(65,10)])
        self.assertEqual(len([c for c in doc['clips'] if c['id']==selected]),1)
        validate(doc)

    def test_overwrite_preserves_effect_keyframes_of_uncovered_region(self):
        self.a['keyframes']={'x':[{'frame':0,'value':10,'interpolation':'linear'},
                                   {'frame':20,'value':30,'interpolation':'linear'}]}
        doc,_=self.apply('overwrite',asset='source',track='V1',start=26,source_in=90,duration=7)
        right=next(c for c in doc['clips'] if c['start']==33)
        self.assertEqual(right['source_in'],23)
        self.assertAlmostEqual(right['keyframes']['x'][0]['value'],23)

    def test_overwrite_invalid_stream_or_range(self):
        for kwargs in (dict(asset='missing',track='V1',start=0,source_in=0,duration=10),
                       dict(asset='source',track='V1',start=0,source_in=350,duration=20)):
            with self.assertRaises(ValueError):self.apply('overwrite',**kwargs)

    def test_slide_preserves_center_source_and_outer_edges(self):
        third=create_clip(self.media,'V1',75,100,20)
        self.doc['clips'].append(third)
        doc,_=self.apply('slide',clip_id=self.b['id'],delta=3)
        a,b,c=doc['clips']
        self.assertEqual((a['duration'],b['start'],b['source_in'],c['start'],c['source_in'],c['duration']),
                         (33,53,60,78,103,17))
        self.assertEqual(c['start']+c['duration'],95)

    def test_insert_shifts_all_unlocked_tracks_and_splits_crossing_clips(self):
        aclip=create_clip(self.media,'A1',10,10,55)
        self.doc['clips'].append(aclip)
        self.doc['captions']=[{'id':'caption','start':30,'duration':25,'text':'Hello'}]
        doc, selected=self.apply('insert',asset='source',track='V1',start=40,source_in=100,duration=12)
        self.assertEqual(sorted((c['start'],c['duration']) for c in doc['clips'] if c['track']=='V1'),
                         [(20,20),(40,12),(52,10),(62,25)])
        self.assertEqual(sorted((c['start'],c['duration']) for c in doc['clips'] if c['track']=='A1'),
                         [(10,30),(52,25)])
        self.assertEqual(sorted((c['start'],c['duration']) for c in doc['captions']),[(30,10),(52,15)])
        validate(doc)

    def test_insert_rejects_content_on_locked_tracks(self):
        self.doc['clips'].append(create_clip(self.media,'A1',30,0,50))
        next(t for t in self.doc['tracks'] if t['id']=='A1')['locked']=True
        before=copy.deepcopy(self.doc)
        with self.assertRaisesRegex(ValueError,'Locked track'):
            self.apply('insert',asset='source',track='V1',start=40,source_in=0,duration=10)
        self.assertEqual(self.doc,before)

    def test_track_management_is_non_destructive(self):
        doc,_=self.apply('add-track',track_kind='video')
        self.assertIn('V3',[t['id'] for t in doc['tracks']])
        doc,_=apply_edit(doc,'rename-track',track_id='V3',name='  Overlay  ')
        self.assertEqual(next(t['name'] for t in doc['tracks'] if t['id']=='V3'),'Overlay')
        doc,_=apply_edit(doc,'remove-track',track_id='V3')
        self.assertNotIn('V3',[t['id'] for t in doc['tracks']])
        with self.assertRaisesRegex(ValueError,'empty'):
            self.apply('remove-track',track_id='V1')

    def test_track_audio_created_last(self):
        doc,_=self.apply('add-track',track_kind='audio')
        self.assertEqual(doc['tracks'][-1]['id'],'A3')
        validate(doc)

    def test_nested_trim(self):
        from src.model import nest_clips
        seq,_=nest_clips(self.doc,[self.a['id']])
        doc,_=self.apply('trim-right',container_id=seq['id'],clip_id=self.a['id'],frame=15)
        self.assertEqual(doc['sequences'][0]['clips'][0]['duration'],15)

    def test_relink_maintains_id_and_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'new.mov';p.write_bytes(b'test')
            doc=relink(self.doc,'source',str(p),dict(duration=12,video=True,audio=True,width=1280,height=720))
            self.assertEqual(doc['media'][0]['id'],'source')
            self.assertEqual(doc['media'][0]['path'],str(p))
            self.assertEqual(self.doc['media'][0]['path'],'/tmp/test.mov')
            validate(doc)

    def test_relink_short_media_and_stream_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'short.mov';p.write_bytes(b'test')
            with self.assertRaisesRegex(ValueError,'shorter'):
                relink(self.doc,'source',str(p),dict(duration=1,video=True,audio=True))
            with self.assertRaisesRegex(ValueError,'incompatible'):
                relink(self.doc,'source',str(p),dict(duration=12,video=True,audio=False))

if __name__=='__main__':unittest.main()
