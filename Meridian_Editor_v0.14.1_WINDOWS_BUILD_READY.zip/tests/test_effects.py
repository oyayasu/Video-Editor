"""Effect contract, validation and real encoder integration tests."""
from __future__ import annotations

import copy
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from src.effects import EFFECTS, catalog, create_instance, filters_for, horizontal_animation_expression
from src.after_effects_fx import COMPOSITE_TYPES
from src.media import ffprobe
from src.model import create_clip, fresh, media_item, nest_clips, validate
from src.render import render

FIXTURE=Path(__file__).parent/'fixtures'/'sample.mp4'


class EffectModelTests(unittest.TestCase):
    def setUp(self):
        self.doc=fresh()
        self.doc['media']=[{'id':'fixture','path':str(FIXTURE.resolve()),'name':'sample.mp4',
                            'duration_seconds':1,'video':True,'audio':True,'width':160,'height':90}]
        self.video=create_clip(self.doc['media'][0],'V1',0,duration=18)
        self.audio=create_clip(self.doc['media'][0],'A1',0,duration=18)
        self.doc['clips']=[self.video,self.audio]

    def test_catalog_has_unique_types_and_categories(self):
        items=catalog()
        self.assertEqual(len({item['type'] for item in items}),len(items))
        self.assertGreaterEqual(len({item['category'] for item in items}),4)
        self.assertGreaterEqual(len(items),17)
        self.assertTrue(all('description' in item for item in items))

    def test_every_effect_validates_on_compatible_track(self):
        for spec in EFFECTS:
            with self.subTest(effect=spec['type']):
                doc=copy.deepcopy(self.doc)
                target=doc['clips'][1 if spec['kind']=='audio' else 0]
                target['effects']=[create_instance(spec['type'])]
                validate(doc)
                if spec['type'] in COMPOSITE_TYPES:
                    self.assertIn(spec['type'],COMPOSITE_TYPES)
                elif spec['type'].startswith('slide_'):
                    self.assertNotEqual(horizontal_animation_expression(target,30),'0')
                else:
                    self.assertGreater(len(filters_for(target,30,'audio' if spec['kind']=='audio' else 'video')),0)

    def test_rejects_wrong_track_range_unknown_and_duplicates(self):
        self.video['effects']=[create_instance('highpass')]
        with self.assertRaisesRegex(ValueError,'incompatible'):validate(self.doc)
        self.video['effects']=[create_instance('hue')]
        self.video['effects'][0]['params']['degrees']=float('nan')
        with self.assertRaisesRegex(ValueError,'out of range'):validate(self.doc)
        self.video['effects']=[create_instance('hue')]
        self.video['effects'][0]['params']['degrees']=900
        with self.assertRaisesRegex(ValueError,'out of range'):validate(self.doc)
        self.video['effects']=[create_instance('hue')]
        self.video['effects'].append(copy.deepcopy(self.video['effects'][0]))
        with self.assertRaisesRegex(ValueError,'Duplicate'):validate(self.doc)
        self.video['effects']=[dict(id='abc',type='arbitrary',enabled=True,params={})]
        with self.assertRaisesRegex(ValueError,'Unrecognized'):validate(self.doc)

    def test_fades_clip_length_is_clamped(self):
        fx=create_instance('fade_out');fx['params']['frames']=180
        self.video['effects']=[fx];validate(self.doc)
        self.assertIn('nb_frames=18',filters_for(self.video,30,'video')[0])
        self.assertIn('st=0',filters_for(self.audio | {'effects':[fx]},30,'audio')[0])

    def test_nest_keeps_effects(self):
        self.video['effects']=[create_instance('gamma')]
        seq,_=nest_clips(self.doc,[self.video['id']])
        self.assertEqual(seq['clips'][0]['effects'],self.video['effects'])
        validate(self.doc)


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe') and FIXTURE.exists(), 'FFmpeg required')
class EffectRenderTests(unittest.TestCase):
    def test_all_video_effects_export_individually(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc=fresh();doc['width']=1280;doc['height']=720
            m=media_item(FIXTURE,ffprobe(FIXTURE));doc['media']=[m]
            for spec in EFFECTS:
                if spec['kind'] not in ('video','both'):continue
                with self.subTest(effect=spec['type']):
                    c=create_clip(m,'V1',0,duration=8)
                    c['effects']=[create_instance(spec['type'])]
                    doc['clips']=[c]
                    out=Path(tmp)/(spec['type']+'.mp4')
                    render(doc,out,preset='draft')
                    self.assertTrue(ffprobe(out)['video'])

    def test_audio_stack_and_two_fades_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc=fresh();doc['width']=1280;doc['height']=720
            m=media_item(FIXTURE,ffprobe(FIXTURE));doc['media']=[m]
            video=create_clip(m,'V1',0,duration=15)
            audio=create_clip(m,'A1',0,duration=15)
            audio['effects']=[create_instance(t) for t in ('highpass','lowpass','compressor','echo','fade_in','fade_out')]
            doc['clips']=[video,audio]
            out=Path(tmp)/'audio.mp4'
            render(doc,out,preset='draft')
            info=ffprobe(out)
            self.assertTrue(info['video'] and info['audio'])
            self.assertGreater(out.stat().st_size,2500)


if __name__=='__main__':unittest.main()
