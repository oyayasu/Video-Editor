import copy
import tempfile
import unittest
from pathlib import Path
from src.model import *
from src.render import curve_expression

class ModelTests(unittest.TestCase):
    def setUp(self):
        self.doc=fresh()
        self.m={'id':'media1','path':'/tmp/notreal.mp4','duration_seconds':10,'video':True,'audio':True,'name':'test'}
        self.doc['media'].append(self.m)
        self.c=create_clip(self.m,'V1',45,2,150,fps=30)
        self.doc['clips'].append(self.c)
    def test_json_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.meridian';save(self.doc,p)
            self.assertEqual(load(p),self.doc)
    def test_split_preserves_source(self):
        other=split(self.doc,self.c['id'],105)
        self.assertEqual((self.c['duration'],other['duration'],other['source_in'],other['start']), (60,90,62,105))
    def test_keyframe_interpolation(self):
        self.c['keyframes']['x']=[{'frame':0,'value':0,'interpolation':'ease'},{'frame':100,'value':100}]
        self.assertEqual(value_at(self.c,'x',50),50)
        self.assertAlmostEqual(value_at(self.c,'x',25),15.625)
        self.assertIn('if(lt(t,',curve_expression(self.c,'x',30))
    def test_invalid_media_id(self):
        self.c['asset']='notfound'
        with self.assertRaises(ValueError):validate(self.doc)
    def test_split_keyframes(self):
        self.c['keyframes']['opacity']=[{'frame':0,'value':0},{'frame':100,'value':1}]
        right=split(self.doc,self.c['id'],95)
        self.assertAlmostEqual(right['keyframes']['opacity'][0]['value'],.5)
        self.assertEqual(self.c['keyframes']['opacity'][0]['frame'],0)
if __name__=='__main__':unittest.main()
