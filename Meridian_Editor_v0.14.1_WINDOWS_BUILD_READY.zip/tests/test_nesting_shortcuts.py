"""Contract tests: sequences, recursive rendering, keyboard personalization."""
import copy
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from src.model import fresh, media_item, create_clip, nest_clips, validate
from src.media import ffprobe
from src.render import render, materialize_nested
from src.server import clean_shortcuts, SHORTCUT_ACTIONS


class NestedCompositionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
            raise unittest.SkipTest('FFmpeg required')
        cls.tmp = tempfile.TemporaryDirectory(prefix='meridian-nest-tests-')
        cls.file = Path(cls.tmp.name) / 'source.mp4'
        result = subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
            '-f','lavfi','-i','color=c=red:s=160x90:r=24:d=1',
            '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1',
            '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(cls.file)],
            capture_output=True,text=True)
        if result.returncode:raise RuntimeError(result.stderr)

    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()

    def project(self):
        doc=fresh();doc['fps']=24;doc['width']=1280;doc['height']=720
        media=media_item(str(self.file),ffprobe(self.file));doc['media'].append(media)
        video=create_clip(media,'V1',0,duration=18,fps=24)
        audio=create_clip(media,'A1',0,duration=18,fps=24)
        doc['clips'].extend([video,audio]);validate(doc)
        return doc

    def test_mixed_video_audio_nest_is_reversible_and_valid(self):
        doc=self.project();ids=[c['id'] for c in doc['clips']]
        seq,instances=nest_clips(doc,ids,'Scene 01')
        self.assertEqual(len(instances),2)
        self.assertEqual(set(x['sequence_id'] for x in instances),{seq['id']})
        self.assertEqual(len(seq['clips']),2)
        self.assertEqual(set(x['id'] for x in seq['clips']),set(ids))
        self.assertEqual(seq['duration'],18)
        validate(json.loads(json.dumps(doc)))

    def test_cycle_is_rejected(self):
        doc=self.project();seq,instances=nest_clips(doc,[doc['clips'][0]['id']],'Cycle test')
        seq['clips'].append(copy.deepcopy(instances[0]))
        with self.assertRaisesRegex(ValueError,'cycle'):validate(doc)

    def test_missing_sequence_is_rejected(self):
        doc=self.project();seq,instances=nest_clips(doc,[doc['clips'][0]['id']],'Missing')
        doc['sequences'].clear()
        with self.assertRaisesRegex(ValueError,'missing nested sequence'):validate(doc)

    def test_nested_render_contains_video_and_audio(self):
        doc=self.project();seq,instances=nest_clips(doc,[c['id'] for c in doc['clips']],'Mix')
        output=Path(self.tmp.name)/'mix.mp4'
        render(doc,str(output),preset='draft')
        probe=ffprobe(output)
        self.assertTrue(probe['video'])
        self.assertTrue(probe['audio'])
        self.assertGreater(probe['duration'],0.65)
        self.assertLess(probe['duration'],0.95)


    def test_precomposition_preserves_alpha(self):
        doc=self.project();nest_clips(doc,[doc['clips'][0]['id']],'Alpha')
        with tempfile.TemporaryDirectory(prefix='meridian-alpha-') as tmp:
            prepared=materialize_nested(doc,tmp,'draft')
            intermediate=next(m for m in prepared['media'] if m['id'].startswith('nested_'))
            cp=subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
                               '-show_entries','stream=pix_fmt','-of','default=nw=1',
                               intermediate['path']],capture_output=True,text=True,check=True)
            self.assertIn('yuva',cp.stdout)

    def test_two_level_nesting_renders(self):
        doc=self.project();inner,_=nest_clips(doc,[c['id'] for c in doc['clips']],'Inner')
        nest_clips(doc,[c['id'] for c in doc['clips']],'Outer')
        output=Path(self.tmp.name)/'double.mp4'
        render(doc,str(output),preset='draft')
        self.assertTrue(ffprobe(output)['video'])


class ShortcutValidationTests(unittest.TestCase):
    def test_distinct_valid_bindings(self):
        choices={k:'Ctrl+Alt+'+('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[i]) for i,k in enumerate(sorted(SHORTCUT_ACTIONS))}
        self.assertEqual(clean_shortcuts(choices),choices)

    def test_open_nest_enter_key(self):
        choices={k:'Ctrl+Alt+'+('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[i]) for i,k in enumerate(sorted(SHORTCUT_ACTIONS))}
        choices['open']='Enter'
        self.assertEqual(clean_shortcuts(choices)['open'],'Enter')

    def test_conflict_detection(self):
        choices={k:'Ctrl+Alt+'+('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[i]) for i,k in enumerate(sorted(SHORTCUT_ACTIONS))}
        keys=list(choices);choices[keys[1]]=choices[keys[0]]
        with self.assertRaisesRegex(ValueError,'Conflicting'):clean_shortcuts(choices)

    def test_invalid_key_rejected(self):
        choices={k:'Ctrl+Alt+'+('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[i]) for i,k in enumerate(sorted(SHORTCUT_ACTIONS))}
        choices['save']='Ctrl+Shift+Ctrl+Q'
        with self.assertRaises(ValueError):clean_shortcuts(choices)

if __name__=='__main__':unittest.main()
