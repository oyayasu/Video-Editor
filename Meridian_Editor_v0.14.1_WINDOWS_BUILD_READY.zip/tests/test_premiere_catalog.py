"""Meridian Premiere reference and original-effects regression tests."""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import unittest
from collections import Counter
from pathlib import Path

from src.effects import BY_TYPE, EFFECTS, create_instance, filters_for
from src.after_effects_fx import COMPOSITE_TYPES
from src.media import ffprobe
from src.model import create_clip, fresh, media_item, validate
from src.render import render

ROOT = Path(__file__).resolve().parent.parent
FIXTURE = ROOT / 'tests' / 'fixtures' / 'sample.mp4'


class ReferenceCatalogTests(unittest.TestCase):
    def test_status_count_and_references(self):
        path = ROOT / 'docs' / 'PREMIERE_26_CATALOG.json'
        catalog = json.loads(path.read_text(encoding='utf-8'))
        records = catalog['entries']
        by_status = Counter((item['media_type'], item['adobe_status']) for item in records)
        self.assertEqual(by_status['video_effect', 'active_26'], 90)
        self.assertEqual(by_status['video_transition', 'active_26'], 81)
        self.assertGreaterEqual(by_status['audio_effect', 'audio_reference_2026'], 30)
        self.assertGreater(len(records), 300)
        self.assertTrue(all(item.get('name') and item.get('category') for item in records))
        self.assertTrue(all(item['meridian_analog'] in BY_TYPE
                            for item in records if item.get('meridian_analog')))
        self.assertTrue(all(item.get('parity') != 'full'
                            for item in records))

    def test_all_meridian_effects_have_executable_handlers(self):
        self.assertEqual(len(BY_TYPE), len(EFFECTS))
        self.assertEqual(len(EFFECTS), 67)
        for spec in EFFECTS:
            if spec['type'] in ('slide_in', 'slide_out') or spec['type'] in COMPOSITE_TYPES:
                continue
            clip = dict(duration=8, start=0, effects=[create_instance(spec['type'])])
            with self.subTest(effect=spec['type']):
                self.assertTrue(filters_for(clip, 30, 'audio' if spec['kind'] == 'audio' else 'video'))

    def test_reject_invalid_new_param(self):
        doc = fresh()
        doc['media'] = [dict(id='m', path=str(FIXTURE), name='fixture', duration_seconds=2,
                             video=True, audio=True, width=160, height=90)]
        clip = create_clip(doc['media'][0], 'V1', 0, duration=8)
        clip['effects'] = [create_instance('mosaic')]
        doc['clips'] = [clip]
        validate(doc)
        clip['effects'][0]['params']['block'] = 100000
        with self.assertRaises(ValueError):
            validate(doc)


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe') and FIXTURE.exists(), 'FFmpeg unavailable')
class PremiereEffectRenderTests(unittest.TestCase):
    def test_every_new_audio_effect_exports_individually(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = fresh()
            doc['width'] = 1280
            doc['height'] = 720
            media = media_item(FIXTURE, ffprobe(FIXTURE))
            doc['media'] = [media]
            for spec in EFFECTS:
                if spec['kind'] != 'audio' or spec['type'] in ('highpass', 'lowpass', 'compressor', 'echo'):
                    continue
                with self.subTest(effect=spec['type']):
                    audio = create_clip(media, 'A1', 0, duration=8)
                    audio['effects'] = [create_instance(spec['type'])]
                    doc['clips'] = [audio]
                    out = Path(tmp) / (spec['type'] + '.mp4')
                    render(doc, out, 'draft')
                    self.assertTrue(ffprobe(out)['audio'])

    def test_chroma_key_plus_posterize_preserve_alpha(self):
        clip = {'duration': 8, 'start': 0, 'effects': [create_instance('chroma_key'), create_instance('posterize')]}
        key_only = filters_for(clip | {'effects': clip['effects'][:1]}, 30, 'video')
        with_posterize = filters_for(clip, 30, 'video')

        def alpha(chain):
            cmd = ['ffmpeg', '-loglevel', 'error', '-f', 'lavfi', '-i',
                   'color=c=green:s=16x16:d=0.1:r=30', '-vf',
                   'format=rgba,' + ','.join(chain) + ',format=rgba',
                   '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-']
            run = subprocess.run(cmd, capture_output=True, check=True)
            return run.stdout[3::4]

        baseline = alpha(key_only)
        result = alpha(with_posterize)
        self.assertEqual(len(result), 16 * 16)
        self.assertEqual(baseline, result)
        self.assertTrue(any(v < 255 for v in result))

    def test_meridian_effect_filter_order_is_preserved(self):
        clip = {'start': 0, 'duration': 20, 'effects': [create_instance('brightness_contrast'),
                                                         create_instance('mosaic'), create_instance('flip_horizontal')]}
        result = filters_for(clip, 30, 'video')
        self.assertTrue(result[0].startswith('eq='))
        self.assertTrue(result[1].startswith('pixelize='))
        self.assertEqual(result[2], 'hflip')


if __name__ == '__main__':
    unittest.main()
