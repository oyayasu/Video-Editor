"""Built-in effect specifications and FFmpeg adapters.

The effect registry is the single source of truth for both the UI and the
renderer. Parameters are always numerical, range-checked before reaching
FFmpeg. Effects are evaluated in the order stored on each clip.
"""
from __future__ import annotations

import math
import uuid

from .effects_extended import EXTRA_EFFECTS, extended_filter
from .after_effects_fx import AE_EFFECTS, COMPOSITE_EFFECTS, filter_for as ae_filter

# (name, minimum, maximum, default, increment)
def parameter(name, minimum, maximum, default, step=0.1):
    return dict(label=name, min=minimum, max=maximum, default=default, step=step)


EFFECTS = (
    dict(type='gamma', name='Gamma', category='Color Correction', kind='video',
         description='Adjust midtone brightness without moving the white point.',
         params={'gamma':parameter('Gamma', 0.2, 3, 1, 0.05)}),
    dict(type='hue', name='Hue Shift', category='Color Correction', kind='video',
         description='Rotate hues on the color wheel.',
         params={'degrees':parameter('Degrees', -180, 180, 0, 1)}),
    dict(type='monochrome', name='Black & White', category='Color Correction', kind='video',
         description='Remove chroma while retaining luminance.', params={}),
    dict(type='color_balance', name='RGB Shadows Balance', category='Color Correction', kind='video',
         description='Adjust red and blue shadow components.',
         params={'red':parameter('Red',-0.8,0.8,0,0.05),'blue':parameter('Blue',-0.8,0.8,0,0.05)}),
    dict(type='gaussian_blur', name='Gaussian Blur', category='Blur & Sharpen', kind='video',
         description='Apply a Gaussian image blur.',
         params={'radius':parameter('Radius',0.1,16,2,0.1)}),
    dict(type='sharpen', name='Unsharp Mask', category='Blur & Sharpen', kind='video',
         description='Sharpen luma detail with an unsharp mask.',
         params={'amount':parameter('Amount',0,3,1,0.1)}),
    dict(type='denoise', name='Spatial / Temporal Denoise', category='Blur & Sharpen', kind='video',
         description='Reduce spatial and temporal image noise.',
         params={'strength':parameter('Strength',0.1,12,4,0.1)}),
    dict(type='vignette', name='Vignette', category='Stylize', kind='video',
         description='Darken the edges of the image.',
         params={'strength':parameter('Strength',0.1,1,0.5,0.05)}),
    dict(type='invert', name='Invert Colors', category='Stylize', kind='video',
         description='Invert image RGB channels.',params={}),
    dict(type='highpass', name='High-Pass Filter', category='Audio · Filter & EQ', kind='audio',
         description='Reduce low-frequency rumble.',
         params={'frequency':parameter('Cutoff (Hz)',20,12000,120,1)}),
    dict(type='lowpass', name='Low-Pass Filter', category='Audio · Filter & EQ', kind='audio',
         description='Reduce high frequencies.',
         params={'frequency':parameter('Cutoff (Hz)',100,19000,7500,1)}),
    dict(type='compressor', name='Dynamic Compressor', category='Audio · Amplitude & Dynamics', kind='audio',
         description='Reduce audio dynamic range above a threshold.',
         params={'threshold':parameter('Threshold',0.01,0.9,0.15,0.01),
                 'ratio':parameter('Ratio',1,12,3,0.5)}),
    dict(type='echo', name='Echo / Delay', category='Audio · Reverb & Delay', kind='audio',
         description='Add a controlled single-tap echo.',
         params={'delay':parameter('Delay (ms)',20,900,180,1),
                 'decay':parameter('Decay',0.05,0.8,0.3,0.05)}),
    dict(type='slide_in', name='Slide In From Left', category='Animation', kind='video',
         description='Move a clip horizontally into frame without adding keyframes.',
         params={'distance':parameter('Distance (px)',1,4000,420,1),
                 'frames':parameter('Duration (frames)',2,600,12,1)}),
    dict(type='slide_out', name='Slide Out To Right', category='Animation', kind='video',
         description='Move a clip horizontally out of frame.',
         params={'distance':parameter('Distance (px)',1,4000,420,1),
                 'frames':parameter('Duration (frames)',2,600,12,1)}),
    dict(type='fade_in', name='Fade In', category='Transitions', kind='both',
         description='Fade from transparency (video) or silence (audio).',
         params={'frames':parameter('Duration (frames)',1,600,12,1)}),
    dict(type='fade_out', name='Fade Out', category='Transitions', kind='both',
         description='Fade to transparency (video) or silence (audio).',
         params={'frames':parameter('Duration (frames)',1,600,12,1)}),
)
EFFECTS += EXTRA_EFFECTS + AE_EFFECTS + COMPOSITE_EFFECTS
BY_TYPE = {entry['type']:entry for entry in EFFECTS}


def catalog():
    """JSON-compatible public metadata; all entries are implemented in export."""
    return [dict(effect,animatable=list(ANIMATABLE.get(effect['type'],()))) for effect in EFFECTS]


# Explicitly limited to parameters FFmpeg can evaluate per video frame or audio block.
ANIMATABLE = {
    'brightness_contrast': ('brightness','contrast'),
    'saturation': ('amount',),
    'audio_gain': ('gain',),
}

def effect_value_at(instance, name, frame):
    """Evaluate an effect parameter at a local integer timeline frame."""
    keys=sorted(instance.get('keyframes',{}).get(name,[]),key=lambda x:x['frame'])
    default=float(instance['params'][name])
    if not keys:return default
    if frame<=keys[0]['frame']:return float(keys[0]['value'])
    if frame>=keys[-1]['frame']:return float(keys[-1]['value'])
    for a,b in zip(keys,keys[1:]):
        if a['frame']<=frame<=b['frame']:
            if a.get('interpolation')=='hold':return float(a['value'])
            p=(frame-a['frame'])/(b['frame']-a['frame'])
            if a.get('interpolation')=='ease':p=p*p*(3-2*p)
            return float(a['value'])+(float(b['value'])-float(a['value']))*p
    return default

def effect_curve_expression(instance, name, fps):
    """Build a FFmpeg frame-evaluated expression using *clip-local* time t."""
    keys=sorted(instance.get('keyframes',{}).get(name,[]),key=lambda x:x['frame'])
    if not keys:return format_num(instance['params'][name])
    expr=format_num(keys[-1]['value'])
    for a,b in reversed(list(zip(keys,keys[1:]))):
        start=format_num(a['frame']/fps);end=format_num(b['frame']/fps)
        if a.get('interpolation')=='hold':value=format_num(a['value'])
        else:
            p=f'((t-{start})/({end}-{start}))'
            if a.get('interpolation')=='ease':p=f'({p}*{p}*(3-2*{p}))'
            value=f'({format_num(a["value"])}+({format_num(b["value"])}-{format_num(a["value"])})*{p})'
        expr=f'if(lt(t,{end}),{value},{expr})'
    return f'if(lt(t,{format_num(keys[0]["frame"]/fps)}),{format_num(keys[0]["value"])},{expr})'


def create_instance(effect_type):
    spec = BY_TYPE.get(effect_type)
    if spec is None:
        raise ValueError('Unknown effect: ' + str(effect_type))
    return {'id':uuid.uuid4().hex[:12], 'type':effect_type, 'enabled':True,
            'params':{key:info['default'] for key,info in spec['params'].items()},'keyframes':{}}


def validate_clip_effects(clip, kind):
    instances = clip.get('effects', [])
    if not isinstance(instances,list) or len(instances)>64:
        raise ValueError('Invalid effect stack (maximum 64 effects per clip)')
    ids = set()
    for instance in instances:
        if not isinstance(instance,dict):
            raise ValueError('Invalid effect instance')
        effect_id = instance.get('id')
        if not isinstance(effect_id,str) or not effect_id or len(effect_id)>64 or effect_id in ids:
            raise ValueError('Duplicate or invalid effect instance ID')
        ids.add(effect_id)
        spec = BY_TYPE.get(instance.get('type'))
        if spec is None:
            raise ValueError('Unrecognized effect type')
        if spec['kind'] not in (kind,'both'):
            raise ValueError('Effect incompatible with clip track')
        if type(instance.get('enabled')) is not bool:
            raise ValueError('Invalid effect enabled state')
        params = instance.get('params')
        if not isinstance(params,dict) or set(params)!=set(spec['params']):
            raise ValueError('Invalid effect parameters for '+spec['name'])
        for key, definition in spec['params'].items():
            value = params[key]
            if type(value) not in (int,float) or not math.isfinite(value) or not definition['min']<=value<=definition['max']:
                raise ValueError('Effect parameter out of range: '+key)
        curves=instance.get('keyframes',{})
        if not isinstance(curves,dict) or set(curves)-set(ANIMATABLE.get(spec['type'],())):
            raise ValueError('Unsupported effect parameter animation')
        for param_name, keys in curves.items():
            if not isinstance(keys,list) or len(keys)>2000: raise ValueError('Invalid effect keyframe list')
            frames=set()
            for point in keys:
                if not isinstance(point,dict):raise ValueError('Invalid effect keyframe')
                frame=point.get('frame');value=point.get('value')
                if type(frame) is not int or not 0<=frame<clip['duration'] or frame in frames:
                    raise ValueError('Invalid or duplicate effect keyframe frame')
                if type(value) not in (int,float) or not math.isfinite(value) or not spec['params'][param_name]['min']<=value<=spec['params'][param_name]['max']:
                    raise ValueError('Effect keyframe value out of range')
                if point.get('interpolation','linear') not in ('linear','hold','ease'):
                    raise ValueError('Invalid effect keyframe interpolation')
                frames.add(frame)
        if spec['type'] in ('fade_in','fade_out','slide_in','slide_out') and int(params['frames'])!=params['frames']:
            raise ValueError('Fade duration must be integer frames')
        if spec['type'] in ('posterize','mosaic','rgb_split','video_noise','horizontal_blur','vertical_blur'):
            key = {'posterize':'levels', 'mosaic':'block', 'rgb_split':'pixels',
                   'video_noise':'amount', 'horizontal_blur':'radius', 'vertical_blur':'radius'}[spec['type']]
            if int(params[key]) != params[key]:
                raise ValueError('Expected integer parameter: ' + key)


def format_num(number):
    return format(float(number),'.6f').rstrip('0').rstrip('.') or '0'


def _fade(instance, clip, fps, kind):
    count = min(clip['duration'],int(instance['params']['frames']))
    duration = format_num(count/fps)
    if instance['type']=='fade_in':
        return f"{'fade=type=in:start_frame=0:nb_frames=' + str(count) + ':alpha=1' if kind=='video' else 'afade=t=in:st=0:d=' + duration}"
    start_frame = max(0,clip['duration']-count)
    return (f'fade=type=out:start_frame={start_frame}:nb_frames={count}:alpha=1'
            if kind=='video' else f'afade=t=out:st={format_num(start_frame/fps)}:d={duration}')


def filters_for(clip, fps, kind):
    """Generate a safe ordered FFmpeg filter chain from validated instances."""
    validate_clip_effects(clip,kind)
    result=[]
    for instance in clip.get('effects',[]):
        if not instance['enabled']:
            continue
        typ=instance['type']; p=instance['params']; f=format_num
        if typ in ('fade_in','fade_out'):
            result.append(_fade(instance,clip,fps,kind))
        elif kind=='video':
            if typ in ('slide_in','slide_out'):continue  # evaluated in overlay X expression
            if typ=='brightness_contrast':
                result.append(f'eq=brightness=\'{effect_curve_expression(instance,"brightness",fps)}\':'
                              f'contrast=\'{effect_curve_expression(instance,"contrast",fps)}\':eval=frame')
                continue
            if typ=='saturation':
                result.append(f'eq=saturation=\'{effect_curve_expression(instance,"amount",fps)}\':eval=frame')
                continue
            if typ=='gamma':result.append(f'eq=gamma={f(p["gamma"])}')
            elif typ=='hue':result.append(f'hue=h={f(p["degrees"])}')
            elif typ=='monochrome':result.append('hue=s=0')
            elif typ=='color_balance':result.append(f'colorbalance=rs={f(p["red"])}:bs={f(p["blue"])}')
            elif typ=='gaussian_blur':result.append(f'gblur=sigma={f(p["radius"])}')
            elif typ=='sharpen':result.append(f'unsharp=5:5:{f(p["amount"])}:5:5:0')
            elif typ=='denoise':result.append(f'hqdn3d=luma_spatial={f(p["strength"])}')
            elif typ=='vignette':result.append(f'vignette=angle=PI/{f(3+6*p["strength"])}')
            elif typ=='invert':result.append('negate')
            else:
                generated = (None if typ in ('ae_glow','ae_drop_shadow') else ae_filter(typ,p)) if typ.startswith('ae_') else extended_filter(typ, p, 'video')
                if generated: result.append(generated)
        else:
            if typ=='audio_gain':
                expression=effect_curve_expression(instance,'gain',fps)
                result.append(f'volume=\'pow(10,({expression})/20)\':eval=frame')
                continue
            if typ=='highpass':result.append(f'highpass=f={f(p["frequency"])}')
            elif typ=='lowpass':result.append(f'lowpass=f={f(p["frequency"])}')
            elif typ=='compressor':result.append(f'acompressor=threshold={f(p["threshold"])}:ratio={f(p["ratio"])}')
            elif typ=='echo':result.append(f'aecho=0.8:0.6:{f(p["delay"])}:{f(p["decay"])}')
            else:
                generated = extended_filter(typ, p, 'audio')
                if generated: result.append(generated)
    return result


def horizontal_animation_expression(clip, fps):
    """Additive X-offset expression for procedural slide animation effects.

    Uses FFmpeg output-timeline `t` and clip-relative frame counts. Effects
    are combined additively and do not overwrite the user's X keyframes.
    """
    validate_clip_effects(clip,'video')
    expressions=[]
    for fx in clip.get('effects',[]):
        if not fx['enabled'] or fx['type'] not in ('slide_in','slide_out'):
            continue
        frames=min(clip['duration'],int(fx['params']['frames']))
        distance=format_num(fx['params']['distance'])
        span=format_num(max(1,frames-1)/fps)
        if fx['type']=='slide_in':
            start=format_num(clip['start']/fps)
            expressions.append(f'(-{distance}*(1-min(1,max(0,(t-{start})/{span}))))')
        else:
            start=format_num((clip['start']+clip['duration']-frames)/fps)
            expressions.append(f'({distance}*min(1,max(0,(t-{start})/{span})))')
    return '+'.join(expressions) if expressions else '0'
