"""FFprobe metadata. All operations run through subprocess argument arrays."""
import json
import shutil
import subprocess

class MediaError(RuntimeError): pass

def ffprobe(path):
    if not shutil.which('ffprobe'):raise MediaError('ffprobe not installed / not in PATH')
    cp=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type,width,height,duration',
                       '-of','json',str(path)],capture_output=True,text=True,timeout=30)
    if cp.returncode:raise MediaError((cp.stderr or 'Could not inspect media')[:2000])
    data=json.loads(cp.stdout)
    streams=data.get('streams',[])
    durations=[float(s.get('duration') or 0) for s in streams]
    duration=float(data.get('format',{}).get('duration') or max(durations or [0]))
    if duration<=0:
        # Stills have no intrinsic timeline duration; start with an adjustable 5 s clip.
        from pathlib import Path
        if Path(path).suffix.lower() in ('.png','.jpg','.jpeg','.webp') and any(st.get('codec_type')=='video' for st in streams):
            duration=5.0
        else:
            raise MediaError('Cannot determine duration (live streams not supported)')
    video=next((s for s in streams if s.get('codec_type')=='video'),{})
    audio=next((s for s in streams if s.get('codec_type')=='audio'),{})
    return {'duration':duration,'video':bool(video),'audio':bool(audio),
            'width':int(video.get('width',0)), 'height':int(video.get('height',0))}
