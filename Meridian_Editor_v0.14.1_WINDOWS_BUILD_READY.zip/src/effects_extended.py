"""Meridian-owned video and audio effect definitions.

These are original parameter mappings built over FFmpeg's open filters. Their
names describe the Meridian operation, not guaranteed Adobe parameter parity.
Only executable filters appear in the UI catalog; the Premiere audit is separate.
"""
from __future__ import annotations


def param(label, minimum, maximum, default, step=0.1):
    return dict(label=label, min=minimum, max=maximum, default=default, step=step)


def effect(identifier, name, category, kind, description, **parameters):
    return dict(type=identifier, name=name, category=category, kind=kind,
                description=description, params=parameters)


EXTRA_EFFECTS = (
    effect('brightness_contrast', 'Brightness & Contrast', 'Color Correction', 'video',
           'Adjust brightness and tonal contrast.',
           brightness=param('Brightness', -0.5, 0.5, 0, 0.01),
           contrast=param('Contrast', 0.2, 3, 1, 0.05)),
    effect('saturation', 'Saturation', 'Color Correction', 'video',
           'Increase or decrease color intensity.',
           amount=param('Saturation', 0, 3, 1, 0.05)),
    effect('temperature', 'White Balance Temperature', 'Color Correction', 'video',
           'Shift approximate image white balance in kelvin.',
           kelvin=param('Temperature (K)', 1000, 12000, 6500, 100)),
    effect('vibrance', 'Vibrance', 'Color Correction', 'video',
           'Boost less-saturated colors while retaining chroma.',
           intensity=param('Intensity', -2, 2, 0.5, 0.05)),
    effect('color_tint', 'Colorize', 'Color Correction', 'video',
           'Apply a hue tint with adjustable mixing.',
           hue=param('Hue', 0, 360, 30, 1),
           mix=param('Mix', 0, 1, 0.3, 0.05)),
    effect('curves_contrast', 'Contrast Curves Preset', 'Color Correction', 'video',
           'Apply an RGB curve with a medium-contrast profile.'),
    effect('curves_vintage', 'Vintage Curves Preset', 'Color Correction', 'video',
           'Apply a fixed vintage color-curve profile.'),
    effect('horizontal_blur', 'Horizontal Blur', 'Blur & Sharpen', 'video',
           'Blur along the horizontal axis.',
           radius=param('Radius', 1, 40, 5, 1)),
    effect('vertical_blur', 'Vertical Blur', 'Blur & Sharpen', 'video',
           'Blur along the vertical axis.',
           radius=param('Radius', 1, 40, 5, 1)),
    effect('mosaic', 'Mosaic / Pixelate', 'Stylize', 'video',
           'Replace areas with averaged rectangular pixels.',
           block=param('Pixel Size', 2, 128, 16, 1)),
    effect('find_edges', 'Find Edges', 'Stylize', 'video',
           'Highlight contrasting edges in the image.'),
    effect('video_noise', 'Film Noise', 'Noise & Grain', 'video',
           'Add controlled temporal image noise.',
           amount=param('Noise', 0, 100, 20, 1)),
    effect('flip_horizontal', 'Horizontal Flip', 'Transform', 'video',
           'Reflect the entire image around the vertical axis.'),
    effect('flip_vertical', 'Vertical Flip', 'Transform', 'video',
           'Reflect the entire image around the horizontal axis.'),
    effect('rgb_split', 'RGB Channel Split', 'Stylize', 'video',
           'Offset red and blue channels in opposite directions.',
           pixels=param('Offset (px)', 0, 40, 5, 1)),
    effect('lens_correction', 'Lens Distortion Correction', 'Distort', 'video',
           'Apply radial lens barrel/pincushion correction.',
           distortion=param('Radial distortion', -0.5, 0.5, 0.15, 0.01)),
    effect('chroma_key', 'Green Screen Key', 'Keying', 'video',
           'Remove green background pixels to create transparency.',
           similarity=param('Similarity', 0.01, 1, 0.28, 0.01),
           softness=param('Edge Blend', 0, 1, 0.05, 0.01)),
    effect('luma_key', 'Luma Key', 'Keying', 'video',
           'Key pixels based on their brightness.',
           threshold=param('Threshold', 0, 1, 0.2, 0.01),
           tolerance=param('Tolerance', 0.01, 1, 0.08, 0.01)),
    effect('posterize', 'Posterize', 'Stylize', 'video',
           'Reduce each RGB channel to discrete tone levels.',
           levels=param('Levels per channel', 2, 64, 8, 1)),
    effect('audio_gain', 'Amplify', 'Audio · Amplitude & Dynamics', 'audio',
           'Change the output gain of an audio clip.',
           gain=param('Gain (dB)', -36, 24, 6, 0.5)),
    effect('bass_eq', 'Bass EQ', 'Audio · Filter & EQ', 'audio',
           'Adjust low-frequency shelving gain.',
           gain=param('Bass (dB)', -24, 24, 6, 0.5)),
    effect('treble_eq', 'Treble EQ', 'Audio · Filter & EQ', 'audio',
           'Adjust high-frequency shelving gain.',
           gain=param('Treble (dB)', -24, 24, 4, 0.5)),
    effect('parametric_eq', 'Parametric EQ', 'Audio · Filter & EQ', 'audio',
           'Boost or cut a frequency band with a Q-factor.',
           frequency=param('Frequency (Hz)', 40, 15000, 1500, 10),
           gain=param('Gain (dB)', -24, 24, -6, 0.5),
           q=param('Q', 0.2, 10, 1, 0.1)),
    effect('audio_limiter', 'Hard Limiter', 'Audio · Amplitude & Dynamics', 'audio',
           'Limit peaks using lookahead limiting.',
           ceiling=param('Ceiling (linear)', 0.0625, 1, 0.9, 0.025)),
    effect('audio_gate', 'Noise Gate', 'Audio · Amplitude & Dynamics', 'audio',
           'Attenuate quiet signals below the threshold.',
           threshold=param('Threshold (linear)', 0.01, 1, 0.1, 0.01)),
    effect('audio_deesser', 'DeEsser', 'Audio · Noise Restoration', 'audio',
           'Reduce high-frequency speech sibilance.',
           strength=param('Intensity', 0, 1, 0.6, 0.05)),
    effect('audio_denoise', 'Broadband Noise Reduction', 'Audio · Noise Restoration', 'audio',
           'Reduce broadband audio noise using frequency-domain processing.',
           reduction=param('Noise Reduction (dB)', 1, 30, 12, 1)),
    effect('room_echo', 'Room Reflections', 'Audio · Reverb & Delay', 'audio',
           'Add several short reflections to simulate room ambience.',
           mix=param('Wet Mix', 0.05, 0.7, 0.25, 0.05)),
    effect('audio_tremolo', 'Tremolo', 'Audio · Modulation', 'audio',
           'Modulate volume periodically.',
           rate=param('Rate (Hz)', 0.1, 15, 5, 0.1),
           depth=param('Depth', 0, 1, 0.5, 0.05)),
    effect('audio_chorus', 'Chorus', 'Audio · Modulation', 'audio',
           'Layer subtly modulated short echoes.'),
    effect('audio_flanger', 'Flanger', 'Audio · Modulation', 'audio',
           'Apply a sweeping short-delay comb filter.',
           speed=param('Speed', 0.1, 10, 0.5, 0.1)),
    effect('stereo_balance', 'Stereo Balance', 'Audio · Stereo Image', 'audio',
           'Shift the level balance between left and right output.',
           balance=param('L / R balance', -1, 1, 0.3, 0.05)),
)


def _n(value):
    return format(float(value), '.6f').rstrip('0').rstrip('.') or '0'


def _build_video():
    return {
        'temperature': lambda p: f'colortemperature=temperature={_n(p["kelvin"])}',
        'vibrance': lambda p: f'vibrance=intensity={_n(p["intensity"])}',
        'color_tint': lambda p: f'colorize=hue={_n(p["hue"])}:mix={_n(p["mix"])}',
        'curves_contrast': lambda p: 'curves=preset=medium_contrast',
        'curves_vintage': lambda p: 'curves=preset=vintage',
        'horizontal_blur': lambda p: f'avgblur=sizeX={int(p["radius"])}:sizeY=1',
        'vertical_blur': lambda p: f'avgblur=sizeX=1:sizeY={int(p["radius"])}',
        'mosaic': lambda p: f'pixelize=width={int(p["block"])}:height={int(p["block"])}',
        'find_edges': lambda p: 'edgedetect=mode=colormix',
        'video_noise': lambda p: f'noise=alls={int(p["amount"])}:allf=t+u:all_seed=1337',
        'flip_horizontal': lambda p: 'hflip',
        'flip_vertical': lambda p: 'vflip',
        'rgb_split': lambda p: f'rgbashift=rh={int(p["pixels"])}:bh={-int(p["pixels"])}',
        'lens_correction': lambda p: f'lenscorrection=k1={_n(p["distortion"])}',
        'chroma_key': lambda p: f'colorkey=color=0x00ff00:similarity={_n(p["similarity"])}:blend={_n(p["softness"])}',
        'luma_key': lambda p: f'lumakey=threshold={_n(p["threshold"])}:tolerance={_n(p["tolerance"])}',
        'posterize': lambda p:
            f'lutrgb=r=trunc(val/ceil(256/{int(p["levels"])}))*ceil(256/{int(p["levels"])}):'
            f'g=trunc(val/ceil(256/{int(p["levels"])}))*ceil(256/{int(p["levels"])}):'
            f'b=trunc(val/ceil(256/{int(p["levels"])}))*ceil(256/{int(p["levels"])}),format=rgba',
    }


def _build_audio():
    return {
        'bass_eq': lambda p: f'bass=g={_n(p["gain"])}',
        'treble_eq': lambda p: f'treble=g={_n(p["gain"])}',
        'parametric_eq': lambda p: f'equalizer=f={_n(p["frequency"])}:t=q:w={_n(p["q"])}:g={_n(p["gain"])}',
        'audio_limiter': lambda p: f'alimiter=limit={_n(p["ceiling"])}:level=false',
        'audio_gate': lambda p: f'agate=threshold={_n(p["threshold"])}:ratio=8',
        'audio_deesser': lambda p: f'deesser=i={_n(p["strength"])}',
        'audio_denoise': lambda p: f'afftdn=nr={_n(p["reduction"])}',
        'room_echo': lambda p: f'aecho=0.8:0.8:45|90|140:{_n(p["mix"])}|{_n(p["mix"]*0.7)}|{_n(p["mix"]*0.4)}',
        'audio_tremolo': lambda p: f'tremolo=f={_n(p["rate"])}:d={_n(p["depth"])}',
        'audio_chorus': lambda p: 'chorus=0.5:0.7:40:0.4:0.25:2',
        'audio_flanger': lambda p: f'flanger=speed={_n(p["speed"])}',
        'stereo_balance': lambda p: f'aformat=channel_layouts=stereo,stereotools=balance_out={_n(p["balance"])}',
    }

_VIDEO_FILTERS = _build_video()
_AUDIO_FILTERS = _build_audio()
# These three are handled by parameter-aware, frame-evaluated filters in effects.py.
FRAME_ANIMATED_TYPES={'brightness_contrast','saturation','audio_gain'}
assert set(_VIDEO_FILTERS) | set(_AUDIO_FILTERS) | FRAME_ANIMATED_TYPES == {e['type'] for e in EXTRA_EFFECTS}


def extended_filter(effect_type, params, kind):
    """Return a trusted FFmpeg filter expression or None for old registry effects."""
    registry = _VIDEO_FILTERS if kind == 'video' else _AUDIO_FILTERS
    builder = registry.get(effect_type)
    return builder(params) if builder else None
