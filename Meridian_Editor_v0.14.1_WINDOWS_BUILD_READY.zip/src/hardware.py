"""Optional MP4 hardware *encoding* detection; not GPU layer composition.

Encoder presence in `ffmpeg -encoders` alone is insufficient: drivers/devices
must be able to encode a real test frame before we expose this option.
"""
from __future__ import annotations

from functools import lru_cache
import subprocess
import sys


def candidates(platform=None):
    platform = platform or sys.platform
    if platform == 'win32':
        return ('h264_amf', 'h264_nvenc', 'h264_qsv')
    if platform == 'darwin':
        return ('h264_videotoolbox',)
    return ('h264_nvenc', 'h264_qsv')


def probe_encoder(name, run=subprocess.run):
    """Try one actual H.264 frame (offscreen) rather than trusting capability flags."""
    if name not in ('h264_amf','h264_nvenc','h264_qsv','h264_videotoolbox'):
        return False
    try:
        # Probe the SAME RGBA pipe input used by native_export, including
        # FFmpeg's hardware pixel-format negotiation. Listing encoders or
        # testing a ready-made YUV frame alone would yield false positives.
        result = run(['ffmpeg','-hide_banner','-loglevel','error','-nostdin',
                      '-f','rawvideo','-pixel_format','rgba','-video_size','128x72',
                      '-framerate','30','-i','pipe:0',
                      '-frames:v','1','-c:v',name,'-b:v','2M',
                      '-pix_fmt','yuv420p','-f','null','-'],
                     input=bytes(128*72*4),capture_output=True,timeout=8,check=False)
        return result.returncode == 0
    except (OSError,subprocess.TimeoutExpired):
        return False


@lru_cache(maxsize=1)
def available_h264_encoder():
    for name in candidates():
        if probe_encoder(name): return name
    return None
