"""Independent Meridian implementations of commonly used compositing effects.

Names describe familiar results, not copied Adobe processing algorithms.
Each registration has a concrete, single-input libavfilter implementation.
"""
from __future__ import annotations

def parameter(label,lo,hi,default,step=.1):
    return dict(label=label,min=lo,max=hi,default=default,step=step)
def fx(identifier,name,category,description,**params):
    return dict(type=identifier,name=name,category=category,kind='video',description=description,params=params)

AE_EFFECTS=(
    fx('ae_exposure','Exposure','AE · Color Correction','Adjust scene brightness in stops.',
       stops=parameter('Exposure (stops)',-4,4,0,.1)),
    fx('ae_threshold','Threshold','AE · Stylize','Posterize the luminance image into two tonal levels.',
       threshold=parameter('Cutoff (0–255)',0,255,128,1)),
    fx('ae_sepia','Sepia Tone','AE · Color Correction','Apply a warm sepia color matrix.',
       strength=parameter('Amount',0,1,1,.05)),
    fx('ae_rgb_gain','RGB Channel Gain','AE · Channel','Independently change red, green and blue channel gains.',
       red=parameter('Red',0,3,1,.05), green=parameter('Green',0,3,1,.05), blue=parameter('Blue',0,3,1,.05)),
    fx('ae_motion_blur_h','Directional Blur · Horizontal','AE · Blur & Sharpen','Blur horizontal detail spatially (not motion-vector blur).',
       radius=parameter('Blur length',1,50,10,1)),
    fx('ae_motion_blur_v','Directional Blur · Vertical','AE · Blur & Sharpen','Blur vertical detail spatially (not motion-vector blur).',
       radius=parameter('Blur length',1,50,10,1)),
    fx('ae_box_blur','Box Blur','AE · Blur & Sharpen','Apply a symmetric box blur.',
       radius=parameter('Radius',1,35,5,1)),
    fx('ae_smart_blur','Smart Blur','AE · Blur & Sharpen','Reduce texture while attempting to preserve edges.',
       radius=parameter('Radius',.1,5,1.2,.1), strength=parameter('Strength',-.5,1,0,.05)),
    fx('ae_emboss','Emboss','AE · Stylize','Emboss apparent edges in the footage.',
       strength=parameter('Amount',0,3,1,.1)),
    fx('ae_edge_strength','Edge Detection','AE · Stylize','Isolate edges at an adjustable strength.',
       strength=parameter('Sensitivity',0,1,.25,.05)),
    fx('ae_bulge','Bulge / Pinch','AE · Distort','Distort lens radius toward or away from the center.',
       amount=parameter('Amount',-.6,.6,.2,.01)),
    fx('ae_chroma_shift','RGB Color Separation','AE · Channel','Offset red and blue channels in opposite directions.',
       horizontal=parameter('Horizontal (px)',-40,40,5,1),vertical=parameter('Vertical (px)',-40,40,0,1)),
    fx('ae_film_grain','Fine Film Grain','AE · Noise & Grain','Add stable deterministic film-style image grain.',
       intensity=parameter('Grain',0,80,12,1)),
    fx('ae_shadow_highlight','Shadow / Highlight · Approximate','AE · Color Correction','Approximate tonal lift using gamma and contrast; not local tone mapping.',
       shadows=parameter('Shadows',-1,1,0,.05), highlights=parameter('Highlights',-1,1,0,.05)),
    fx('ae_tint','Monochrome Tint','AE · Color Correction','Map black and white output to a grayscale mix.',
       mix=parameter('Amount',0,1,1,.05)),
    fx('ae_median','Median Noise Filter','AE · Blur & Sharpen','Reduce salt-and-pepper noise with median filtering.',
       radius=parameter('Radius',1,5,2,1)),
)

def _n(number):return format(float(number),'.6f').rstrip('0').rstrip('.') or '0'

def filter_for(kind,p):
    n=_n
    if kind=='ae_exposure':
        gain=n(2**p['stops'])
        return f"lutrgb=r='val*{gain}':g='val*{gain}':b='val*{gain}'"
    if kind=='ae_threshold':
        threshold=n(p['threshold'])
        return f'format=gray,lut=y=if(gte(val\\,{threshold})\\,255\\,0),format=rgba'
    if kind=='ae_sepia':
        amount=p['strength'];rr=1-.607*amount;rg=.769*amount;rb=.189*amount
        gr=.349*amount;gg=1-.314*amount;gb=.168*amount
        br=.272*amount;bg=.534*amount;bb=1-.869*amount
        return (f'colorchannelmixer=rr={n(rr)}:rg={n(rg)}:rb={n(rb)}:'
                f'gr={n(gr)}:gg={n(gg)}:gb={n(gb)}:br={n(br)}:bg={n(bg)}:bb={n(bb)}')
    if kind=='ae_rgb_gain':return f'colorchannelmixer=rr={n(p["red"])}:gg={n(p["green"])}:bb={n(p["blue"])}'
    if kind=='ae_motion_blur_h':return f'avgblur=sizeX={int(p["radius"])}:sizeY=1'
    if kind=='ae_motion_blur_v':return f'avgblur=sizeX=1:sizeY={int(p["radius"])}'
    if kind=='ae_box_blur':return f'boxblur=luma_radius={int(p["radius"])}:luma_power=2'
    if kind=='ae_smart_blur':return f'smartblur=lr={n(p["radius"])}:ls={n(p["strength"])}'
    if kind=='ae_emboss':return f'convolution=0m="-2 -1 0 -1 1 1 0 1 2":0rdiv=1:0bias={n(.5*p["strength"])}'
    if kind=='ae_edge_strength':return f'edgedetect=low={n(.02+p["strength"]*.3)}:high={n(.12+p["strength"]*.5)}:mode=colormix'
    if kind=='ae_bulge':return f'lenscorrection=k1={n(p["amount"])}'
    if kind=='ae_chroma_shift':return f'rgbashift=rh={int(p["horizontal"])}:bh={-int(p["horizontal"])}:rv={int(p["vertical"])}:bv={-int(p["vertical"])}'
    if kind=='ae_film_grain':return f'noise=alls={int(p["intensity"])}:allf=t+u:all_seed=14014'
    if kind=='ae_shadow_highlight':return f'eq=gamma={n(1+p["shadows"]*.5)}:contrast={n(1+p["highlights"]*.5)}'
    if kind=='ae_tint':return f'hue=s={n(1-p["mix"])}'
    if kind=='ae_median':return f'median=radius={int(p["radius"])}:planes=7'
    raise ValueError('No processor for '+str(kind))

# Multi-input effects are assembled as named branches in the video graph.
# They deliberately avoid silently substituting unrelated single-input filters.
COMPOSITE_EFFECTS = (
    fx('ae_glow','Glow / Bloom','AE · Stylize',
       'Screen a softened highlight copy over the source image.',
       radius=parameter('Softness (px)',1,30,9,1),
       intensity=parameter('Glow intensity',0,1,0.65,.05)),
    fx('ae_drop_shadow','Drop Shadow','AE · Perspective',
       'Offset a softened black copy beneath transparent artwork.',
       offset_x=parameter('Offset X (px)',-150,150,16,1),
       offset_y=parameter('Offset Y (px)',-150,150,16,1),
       radius=parameter('Softness (px)',0,30,5,1),
       opacity=parameter('Opacity',0,1,0.6,.05)),
)
COMPOSITE_TYPES = frozenset(x['type'] for x in COMPOSITE_EFFECTS)

def append_composite_graph(spec, source, prefix, output, filters):
    """Append linked FFmpeg streams; return resulting label.

    Arguments are already validated by the effect registry. This does not
    execute arbitrary FFmpeg snippets from external presets.
    """
    typ=spec['type'];p=spec['params'];n=_n
    if typ=='ae_glow':
        base=prefix+'base';rays=prefix+'bright';blur=prefix+'blur'
        filters.append(f'[{source}]split=2[{base}][{rays}]')
        filters.append(f'[{rays}]format=rgba,lutrgb=r=val*val/255:g=val*val/255:b=val*val/255,'
                       f'gblur=sigma={n(p["radius"])}:planes=7,format=rgba[{blur}]')
        filters.append(f'[{base}][{blur}]blend=all_mode=screen:all_opacity={n(p["intensity"])}:shortest=1,format=rgba[{output}]')
    elif typ=='ae_drop_shadow':
        backdrop=prefix+'base';top=prefix+'top';shade_source=prefix+'shadow';shade=prefix+'blur';mixed=prefix+'mixed'
        filters.append(f'[{source}]split=3[{backdrop}][{top}][{shade_source}]')
        filters.append(f'[{shade_source}]format=rgba,lutrgb=r=0:g=0:b=0,'
                       f'gblur=sigma={n(max(.1,p["radius"]))}:planes=8,'
                       f'colorchannelmixer=aa={n(p["opacity"])},format=rgba[{shade}]')
        filters.append(f'[{backdrop}][{shade}]overlay=x={int(p["offset_x"])}:y={int(p["offset_y"])}:'
                       f'format=auto:shortest=1[{mixed}]')
        filters.append(f'[{mixed}][{top}]overlay=x=0:y=0:format=auto:shortest=1,format=rgba[{output}]')
    else:
        raise ValueError('Unknown composite effect: '+str(typ))
    return output
