"""Loopback-only desktop prototype server. No third-party Python packages."""
from __future__ import annotations
import copy
import json
import mimetypes
import os
import re
import secrets
import subprocess
import sys
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from .model import fresh, validate, load, save, media_item, nest_clips, split, duplicate_clip, ripple_delete, add_transition, prune_transitions
from .media import ffprobe
from .editorial import apply_edit, relink
from .source_monitor import three_point_edit
from .render import render, render_frame, RenderError
from .native_render import native_available, native_export, native_frame
from .frame_cache import FrameSessionRegistry
from .hardware import available_h264_encoder
from .effects import catalog
from .quick_packs import catalog as quick_catalog, font_catalog, apply_preset
from .titles import create_title
from .font_library import import_archive as import_dafont_archive, font_path as managed_font_path
from .captions import recognize, map_segments_to_clip, subtitles_to_text

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent.parent))
WEB=ROOT/'web'
if (ROOT/'bin').is_dir(): os.environ['PATH']=str(ROOT/'bin')+os.pathsep+os.environ.get('PATH','')
CACHE=Path.home()/'.meridian-editor'
CACHE.mkdir(parents=True,exist_ok=True)
AUTOSAVE=CACHE/'recovery.meridian'
WORKSPACE_FILE=CACHE/'workspace.json'
SHORTCUTS_FILE=CACHE/'shortcuts.json'
FONT_LIBRARY=CACHE/'fonts' 

def clean_workspace(layout):
    if not isinstance(layout,dict):raise ValueError('Invalid workspace')
    order=layout.get('order')
    if not isinstance(order,list) or set(order)!={'library','viewer','inspector'} or len(order)!=3:
        raise ValueError('Invalid workspace panel order')
    for key in ('left','right','timeline'):
        if type(layout.get(key)) not in (int,float):raise ValueError('Invalid workspace sizing')
    if not (12<=layout['left']<=40 and 12<=layout['right']<=40 and 200<=layout['timeline']<=2000):
        raise ValueError('Workspace sizes out of range')
    return {k:layout[k] for k in ('order','left','right','timeline')}

SHORTCUT_ACTIONS={'sourceIn','sourceOut','sourcePlay','sourceNext','sourcePrevious','programIn','programOut','slide','insert','trim','slip','roll','overwrite','save','undo','redo','split','duplicate','ripple','nest','open','back','play','next','previous','remove','select','razor','snap','edit','effects','keys'}
def clean_shortcuts(data, partial=False):
    if not isinstance(data,dict) or not set(data).issubset(SHORTCUT_ACTIONS) or (not partial and set(data)!=SHORTCUT_ACTIONS):raise ValueError('Invalid shortcut command set')
    seen=set();clean={}
    for key,value in data.items():
        if not isinstance(value,str) or not (1<=len(value)<=35):raise ValueError('Invalid shortcut')
        parts=value.split('+')
        if not parts or any(mod not in ('Ctrl','Alt','Shift') for mod in parts[:-1]) or len(set(parts[:-1]))!=len(parts[:-1]):
            raise ValueError('Invalid key modifiers')
        final=parts[-1]
        if final not in {'Space','Enter','Delete','ArrowLeft','ArrowRight'} and not (len(final)==1 and final.isascii() and final.isalnum() and final==final.upper()):
            raise ValueError('Unsupported shortcut key')
        if value in seen:raise ValueError('Conflicting shortcuts: '+value)
        seen.add(value);clean[key]=value
    return clean


class App:
    def __init__(self):
        try:self.project=load(AUTOSAVE)
        except Exception:self.project=fresh()
        self.lock=threading.RLock()
        self.session=secrets.token_urlsafe(32)
        self.assets={m['id']:m['path'] for m in self.project['media']}
        self.status={'state':'idle'}
        self.caption_status={'state':'idle'}
        self.path=None
        self.frame_cache=FrameSessionRegistry()

    def sync(self,doc):
        validate(doc)
        with self.lock:
            self.project=doc
            self.assets={m['id']:m['path'] for m in doc['media']}
            save(doc,AUTOSAVE)

    def export_async(self,doc,path,preset,burn_captions=False,engine="ffmpeg"):
        validate(doc)
        if not Path(path).is_absolute():raise ValueError('Export path must be absolute')
        if Path(path).suffix.lower()!='.mp4':raise ValueError('Export format must be .mp4')
        if engine not in ('ffmpeg','native','native-hw'):
            raise ValueError('Unknown rendering engine')
        if engine in ('native','native-hw') and any(
                Path(m['path']).suffix.lower() in ('.png','.jpg','.jpeg','.webp') for m in doc['media']):
            raise ValueError('Still graphics and title layers require FFmpeg Stable')
        if engine in ('native','native-hw') and not native_available():
            raise ValueError('Native compositor has not been compiled')
        if engine=='native-hw' and not available_h264_encoder():
            raise ValueError('No tested hardware H.264 encoder is available')
        with self.lock:
            if self.status.get('state')=='working':raise ValueError('An export is already in progress')
            self.status={'state':'working','path':path}
        def job():
            try:
                Path(path).parent.mkdir(parents=True,exist_ok=True)
                if engine in ('native','native-hw'):
                    native_export(doc,path,preset,burn_captions=burn_captions,
                                  hardware_encoder=available_h264_encoder() if engine=='native-hw' else None)
                else:
                    render(doc,path,preset,burn_captions=burn_captions)
                status={'state':'done','path':path}
            except Exception as e:status={'state':'error','message':str(e)}
            with self.lock:self.status=status
        threading.Thread(target=job,daemon=True).start()

    def captions_async(self,doc,clip_id,model,language):
        validate(doc)
        chosen=next((c for c in doc['clips'] if c['id']==clip_id),None)
        if chosen is None:raise ValueError('Select a clip on the timeline first')
        item=next((m for m in doc['media'] if m['id']==chosen['asset']),None)
        if item is None or not item['audio']:raise ValueError('Clip has no audio to transcribe')
        with self.lock:
            if self.caption_status['state']=='working':raise ValueError('Transcription already running')
            self.caption_status={'state':'working','message':'Starting offline transcription…','percent':0}
        def job():
            def progress(message, percent):
                with self.lock:self.caption_status={'state':'working','message':message,'percent':percent}
            try:
                segments=recognize(item['path'],model=model,language=language,progress=progress)
                captions=map_segments_to_clip(segments,chosen,doc['fps'])
                status={'state':'done','captions':captions,'message':f'{len(captions)} subtitles recognized'}
            except Exception as exc:
                status={'state':'error','message':str(exc)}
            with self.lock:self.caption_status=status
        threading.Thread(target=job,daemon=True).start()

DESKTOP_DIALOG_PROVIDER = None

def native_dialog(mode):
    if DESKTOP_DIALOG_PROVIDER is not None:
        return DESKTOP_DIALOG_PROVIDER(mode)
    # Dialog in a separate subprocess to keep Tk out of HTTP worker threads.
    script='''import tkinter as tk\nfrom tkinter import filedialog\nr=tk.Tk();r.withdraw();r.attributes('-topmost',True)\nm=%r\nif m=='media': v=filedialog.askopenfilenames(parent=r,title='Import media')\nelif m=='project-open': v=filedialog.askopenfilename(parent=r,title='Open project',filetypes=[('Meridian Project','*.meridian'),('All files','*.*')])\nelif m=='project-save': v=filedialog.asksaveasfilename(parent=r,title='Save project',defaultextension='.meridian',filetypes=[('Meridian Project','*.meridian')])\nelse: v=filedialog.asksaveasfilename(parent=r,title='Export MP4',defaultextension='.mp4',filetypes=[('MP4 video','*.mp4')])\nprint('\\n'.join(v) if isinstance(v,(tuple,list)) else v)\nr.destroy()'''%mode
    cp=subprocess.run([sys.executable,'-c',script],capture_output=True,text=True,timeout=180)
    if cp.returncode:raise RuntimeError('Native file picker is not available: '+cp.stderr[-350:])
    return [x for x in cp.stdout.splitlines() if x]

def handler_factory(app):
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def log_message(self,fmt,*args):
            print('[Meridian]',fmt%args)
        def send_bytes(self,data,code=200,mime='application/json',extra=None):
            self.send_response(code)
            self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; script-src 'self'")
            for k,v in (extra or {}).items():self.send_header(k,v)
            self.end_headers();self.wfile.write(data)
        def respond(self,data,code=200):self.send_bytes(json.dumps(data,ensure_ascii=False).encode(),code)
        def fail(self,msg,code=400):self.respond({'error':msg},code)
        def host_allowed(self):
            host=self.headers.get('Host','').split(':')[0].lower()
            return host in ('localhost','127.0.0.1')
        def do_GET(self):
            if not self.host_allowed():self.fail('Invalid host',403);return
            p=urllib.parse.urlparse(self.path).path
            if p.startswith('/api/native-frame/'):
                ticket=p.rsplit('/',1)[-1]
                query=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                try:
                    if len(query.get('frame',[])) != 1: raise ValueError('Frame is required')
                    raw=query['frame'][0]
                    if not raw.isdecimal(): raise ValueError('Invalid frame')
                    pixels, hit=app.frame_cache.get(ticket,int(raw))
                    self.send_bytes(pixels,mime='image/jpeg',extra={'X-Meridian-Cache':'HIT' if hit else 'MISS'})
                except KeyError:self.fail('Preview session expired',404)
                except (ValueError,RenderError) as error:self.fail(str(error),400)
                return
            if p.startswith('/api/installed-font/'):
                parts=p.removeprefix('/api/installed-font/').split('/')
                try:
                    if len(parts)!=2:raise ValueError('Invalid font path')
                    family, variant=(urllib.parse.unquote(part) for part in parts)
                    item=Path(managed_font_path(family,variant,FONT_LIBRARY))
                    self.send_bytes(item.read_bytes(),mime='font/otf' if item.suffix.lower()=='.otf' else 'font/ttf')
                except ValueError as e:self.fail(str(e),404)
                return
            if p=='/api/shortcuts':
                try:self.respond({'shortcuts':clean_shortcuts(json.loads(SHORTCUTS_FILE.read_text(encoding='utf-8')),partial=True)})
                except (OSError,ValueError,TypeError):self.respond({'shortcuts':None})
                return
            if p=='/api/workspace':
                try:self.respond(clean_workspace(json.loads(WORKSPACE_FILE.read_text(encoding='utf-8'))))
                except (OSError,ValueError,TypeError,KeyError):self.respond({'available':False})
                return
            if p=='/api/session':
                self.respond({'token':app.session,'project':app.project,'project_path':app.path,'missing_media':[m['id'] for m in app.project['media'] if not Path(m['path']).is_file()],'ffmpeg':bool(__import__('shutil').which('ffmpeg')),'native':native_available(),'hw_encoder':available_h264_encoder(),'effects':catalog(),'quick_presets':quick_catalog(),'fonts':font_catalog(FONT_LIBRARY)})
                return
            if p=='/api/caption-status':
                with app.lock:self.respond(app.caption_status.copy())
                return
            if p=='/api/export-status':
                with app.lock:self.respond(app.status.copy())
                return
            if p.startswith('/api/media/'):
                asset_id=p.rsplit('/',1)[-1]
                media_path=app.assets.get(asset_id)
                if not media_path or not Path(media_path).is_file():self.fail('Media not found',404);return
                file=Path(media_path);size=file.stat().st_size
                match=re.fullmatch(r'bytes=(\d*)-(\d*)',self.headers.get('Range',''))
                start=0;end=size-1
                if match:
                    a,b=match.groups()
                    if a:start=int(a);end=min(size-1,int(b)) if b else size-1
                    elif b:start=max(0,size-int(b))
                    if start> end or start>=size:
                        self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.send_header('Content-Length','0');self.end_headers();return
                count=end-start+1
                self.send_response(206 if match else 200)
                self.send_header('Content-Type',mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
                self.send_header('Accept-Ranges','bytes');self.send_header('Content-Length',str(count))
                if match:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
                self.send_header('Cache-Control','private, max-age=300')
                self.end_headers()
                try:
                    with file.open('rb') as f:
                        f.seek(start)
                        while count:
                            chunk=f.read(min(1024*1024,count))
                            if not chunk:break
                            self.wfile.write(chunk);count-=len(chunk)
                except (BrokenPipeError,ConnectionResetError):pass
                return
            target=(WEB/'index.html') if p=='/' else (WEB/p.lstrip('/'))
            if not target.resolve().is_relative_to(WEB.resolve()) or not target.is_file():
                self.fail('Not found',404);return
            self.send_bytes(target.read_bytes(),mime=mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
        def do_POST(self):
            if not self.host_allowed():self.fail('Invalid host',403);return
            if self.headers.get('X-Meridian-Token')!=app.session:self.fail('Unauthorized',403);return
            length=int(self.headers.get('Content-Length',0))
            if length>10*1024*1024:self.fail('Request too large',413);return
            try:
                body=json.loads(self.rfile.read(length).decode('utf-8')) if length else {}
                p=urllib.parse.urlparse(self.path).path
                if p=='/api/shortcuts':
                    shortcuts=clean_shortcuts(body['shortcuts']);SHORTCUTS_FILE.write_text(json.dumps(shortcuts),encoding='utf-8');self.respond({'ok':True,'shortcuts':shortcuts})
                elif p=='/api/new-project':self.respond({'project':fresh()})
                elif p=='/api/timeline-edit':
                    modified=copy.deepcopy(body['project'])
                    op=body['action']
                    clip_id=body['clip_id']
                    container_id=body.get('container_id')
                    if op=='split':
                        added=split(modified,clip_id,body['frame'],container_id)
                        selected_id=added['id']
                    elif op=='duplicate':
                        added=duplicate_clip(modified,clip_id,container_id)
                        selected_id=added['id']
                    elif op=='ripple-delete':
                        ripple_delete(modified,clip_id,container_id)
                        selected_id=None
                    else:raise ValueError('Unknown timeline edit operation')
                    self.respond({'project':modified,'selected_id':selected_id})
                elif p=='/api/editorial-edit':
                    payload = {key: body[key] for key in ('clip_id', 'frame', 'delta', 'outgoing', 'incoming', 'asset', 'track', 'start', 'source_in', 'duration', 'track_kind', 'track_id', 'name') if key in body}
                    updated, selected_id = apply_edit(body['project'], body['action'], container_id=body.get('container_id'), **payload)
                    self.respond({'project':updated,'selected_id':selected_id})
                elif p=='/api/source-edit':
                    edited, clip_ids, resolved = three_point_edit(
                        body['project'], body['action'], asset_id=body['asset_id'],
                        video_track=body.get('video_track'), audio_track=body.get('audio_track'),
                        source_in=body.get('source_in'), source_out=body.get('source_out'),
                        program_in=body.get('program_in'), program_out=body.get('program_out'),
                        container_id=body.get('container_id'))
                    self.respond({'project':edited,'clip_ids':clip_ids,'range':resolved})
                elif p=='/api/relink-media':
                    path = Path(body['path']).expanduser().resolve()
                    if not path.is_file():raise ValueError('Replacement media does not exist')
                    updated = relink(body['project'], body['asset_id'], str(path), ffprobe(path))
                    with app.lock:app.assets[body['asset_id']]=str(path)
                    self.respond({'project':updated,'asset_id':body['asset_id']})
                elif p=='/api/import-dafont':
                    imported=import_dafont_archive(body['family_id'],body['archive_base64'],FONT_LIBRARY)
                    self.respond({'imported':imported,'fonts':font_catalog(FONT_LIBRARY)})
                elif p=='/api/create-title':
                    project=validate(body['project'])
                    requested=body.get('duration',4)
                    if type(requested) not in (int,float) or not .1<=requested<=5:
                        raise ValueError('Title duration must be between 0.1 and 5 seconds')
                    fps=project['fps'];duration=max(2,round(requested*fps))
                    selected_font = (managed_font_path(body['font_id'], body['font_variant'], FONT_LIBRARY)
                                     if body.get('font_id') else body.get('font_path', ''))
                    png=create_title(text=body['text'],width=project['width'],height=project['height'],
                                     size=body.get('size',96),color=body.get('color','#FFFFFF'),
                                     font_path=selected_font,directory=CACHE/'generated'/'titles')
                    metadata={'duration':duration/fps,'video':True,'audio':False,
                              'width':project['width'],'height':project['height']}
                    item=media_item(png,metadata,fps)
                    with app.lock:app.assets[item['id']]=png
                    self.respond({'media':item})
                elif p=='/api/apply-preset':
                    updated=apply_preset(body['project'],body['clip_id'],body['preset_id'],body.get('container_id'))
                    self.respond({'project':updated})
                elif p=='/api/add-transition':
                    modified=copy.deepcopy(body['project'])
                    transition=add_transition(modified,body['outgoing'],body['incoming'],
                                              body.get('type','cross_dissolve'),body.get('duration'),body.get('container_id'))
                    self.respond({'project':modified,'transition':transition})
                elif p=='/api/native-preview-start':
                    if not native_available(): raise ValueError('Native compositor unavailable')
                    project=validate(body['project'])
                    if body.get('container_id'):
                        from .model import editing_container
                        seq=editing_container(project,body['container_id'])
                        project=copy.deepcopy(project)
                        for key in ('clips','tracks','captions','transitions'):
                            project[key]=copy.deepcopy(seq.get(key,[]))
                    ticket=app.frame_cache.start(project)
                    self.respond({'url':'/api/native-frame/'+ticket,'max_width':640})
                elif p=='/api/native-preview-stop':
                    app.frame_cache.stop();self.respond({'ok':True})
                elif p=='/api/preview-frame':
                    project=validate(body['project'])
                    if body.get('container_id'):
                        from .model import editing_container
                        seq=editing_container(project,body['container_id'])
                        project=copy.deepcopy(project)
                        project['clips']=copy.deepcopy(seq['clips'])
                        project['tracks']=copy.deepcopy(seq['tracks'])
                        project['captions']=copy.deepcopy(seq.get('captions',[]))
                        project['transitions']=copy.deepcopy(seq.get('transitions',[]))
                    frame=body['frame']
                    engine=body.get('engine','ffmpeg')
                    if engine=='native':
                        if body.get('captions',True) and project.get('captions'):
                            raise ValueError('Native subtitle burn-in is pending; use FFmpeg for captioned frames')
                        png=native_frame(project,frame)
                    elif engine=='ffmpeg':
                        png=render_frame(project,frame,body.get('captions',True))
                    else:
                        raise ValueError('Unknown rendering engine')
                    self.send_bytes(png,mime='image/png')
                elif p=='/api/nest':
                    nested_doc=copy.deepcopy(body['project'])
                    seq,instances=nest_clips(nested_doc,body['clip_ids'],body.get('name','Nested composition'),body.get('container_id'))
                    self.respond({'project':nested_doc,'sequence_id':seq['id'],'clip_ids':[c['id'] for c in instances]})
                elif p=='/api/workspace':
                    layout=clean_workspace(body['layout']);WORKSPACE_FILE.write_text(json.dumps(layout),encoding='utf-8');self.respond({'ok':True})
                elif p=='/api/sync':
                    app.sync(body['project']);self.respond({'ok':True})
                elif p=='/api/pick':self.respond({'paths':native_dialog(body['mode'])})
                elif p=='/api/import':
                    found=[];errors=[]
                    for path in body['paths'][:150]:
                        try:
                            f=Path(path).expanduser().resolve()
                            if not f.is_file():raise ValueError('File not found')
                            with app.lock:fps=app.project['fps']
                            m=media_item(f,ffprobe(f),fps=fps)
                            found.append(m)
                            with app.lock: app.assets[m["id"]]=m["path"]
                        except Exception as e:errors.append({'path':path,'error':str(e)})
                    self.respond({'media':found,'errors':errors})
                elif p=='/api/open':
                    doc=load(body['path']);app.sync(doc)
                    app.path=str(Path(body['path']).resolve())
                    self.respond({'project':doc,'path':app.path,'missing_media':[m['id'] for m in doc['media'] if not Path(m['path']).is_file()]})
                elif p=='/api/save':
                    app.sync(body['project']);save(app.project,body['path']);app.path=str(Path(body['path']).resolve())
                    self.respond({'ok':True,'path':app.path})
                elif p=='/api/transcribe':
                    app.captions_async(body['project'],body['clip_id'],body.get('model','turbo'),body.get('language'))
                    self.respond({'ok':True})
                elif p=='/api/export-subtitles':
                    doc=validate(body['project']);file=Path(body['path']).expanduser().resolve()
                    if file.suffix.lower() not in ('.srt','.vtt'):
                        raise ValueError('Only SRT and VTT subtitle formats are supported')
                    if not doc.get('captions'):
                        raise ValueError('There are no subtitles to export')
                    file.parent.mkdir(parents=True,exist_ok=True)
                    file.write_text(subtitles_to_text(doc['captions'],doc['fps'],file.suffix[1:].lower()),encoding='utf-8')
                    self.respond({'ok':True,'path':str(file)})
                elif p=='/api/export':
                    app.export_async(body['project'],body['path'],body.get('preset','high'),body.get('burn_captions',False),body.get('engine','ffmpeg'))
                    self.respond({'ok':True})
                else:self.fail('Unknown route',404)
            except Exception as e:self.fail(str(e),400)
    return Handler

def make_server(port=0):
    app=App()
    return ThreadingHTTPServer(('127.0.0.1',port),handler_factory(app))

def launch(port=0,browser=True):
    server=make_server(port)
    url=f'http://127.0.0.1:{server.server_address[1]}/'
    print('Meridian Editor at',url,flush=True)
    if browser:threading.Timer(1,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':launch()
