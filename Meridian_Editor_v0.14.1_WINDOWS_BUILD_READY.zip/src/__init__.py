"""Meridian video editing research prototype."""
