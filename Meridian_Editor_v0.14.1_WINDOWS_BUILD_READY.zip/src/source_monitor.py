"""Source/Program three-point edits with optional video/audio source patching.

Source ranges use integer frames, with an exclusive out point. Work is
transactional: neither invalid metadata nor a failed second track edit can
mutate the caller's document.
"""
from __future__ import annotations

from .editorial import apply_edit
from .model import create_clip, editing_container, validate


def source_frame_count(media, fps):
    """Usable source-frame count, compatible with create_clip's frame policy."""
    return max(1, round(float(media['duration_seconds']) * fps))


def three_point_edit(project, operation, *, asset_id, video_track=None, audio_track=None,
                     source_in=None, source_out=None, program_in=None, program_out=None,
                     container_id=None):
    """Return (new_doc, selected_ids, resolved_range) without modifying input.

    Source and timeline Out are exclusive. A three-point edit may specify a
    source range plus timeline In, or a single source boundary plus a timeline
    In/Out pair. Four contradictory points are rejected rather than resampled.
    Audio and video patches are applied atomically on distinct track kinds.
    """
    validate(project)
    if operation not in ('insert', 'overwrite'):
        raise ValueError('Unknown source edit operation')
    media = next((m for m in project['media'] if m['id'] == asset_id), None)
    if media is None:
        raise ValueError('Source media not found')
    if not video_track and not audio_track:
        raise ValueError('Enable at least one source patch')
    if operation == 'insert' and container_id is not None:
        raise ValueError('Ripple insertion in nested compositions is not available')
    timeline = editing_container(project, container_id)
    mapping = {t['id']: t for t in timeline['tracks']}
    destinations = []
    for kind, track_id in (('video', video_track), ('audio', audio_track)):
        if track_id is None:
            continue
        track = mapping.get(track_id)
        if track is None or track['kind'] != kind or track['locked']:
            raise ValueError(f'Invalid or locked {kind} destination track')
        if not media[kind]:
            raise ValueError(f'Source has no {kind} stream')
        destinations.append(track_id)
    if len(set(destinations)) != len(destinations):
        raise ValueError('Source patches must target distinct tracks')
    for name, value in (('source_in', source_in), ('source_out', source_out),
                        ('program_in', program_in), ('program_out', program_out)):
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError(f'{name} must be a nonnegative integer frame')
    total = source_frame_count(media, project['fps'])
    if source_in is not None and source_in >= total:
        raise ValueError('Source In is outside media')
    if source_out is not None and not (1 <= source_out <= total):
        raise ValueError('Source Out is outside media')
    if program_in is None:
        program_in = timeline['playhead'] if type(timeline.get('playhead')) is int else 0
    if program_out is not None and program_out <= program_in:
        raise ValueError('Timeline Out must be after timeline In')
    if source_in is not None and source_out is not None and source_out <= source_in:
        raise ValueError('Source Out must be after Source In')

    # Solve for the third point without changing playback speed.
    if program_out is not None:
        duration = program_out - program_in
        if source_in is not None and source_out is not None:
            if duration != source_out - source_in:
                raise ValueError('Source and program durations disagree; remove one Out mark')
        elif source_in is not None:
            source_out = source_in + duration
        elif source_out is not None:
            source_in = source_out - duration
        else:
            source_in = 0
            source_out = duration
    else:
        source_in = 0 if source_in is None else source_in
        source_out = total if source_out is None else source_out
        duration = source_out - source_in
    if source_in is None or source_out is None or source_in < 0 or duration < 1 or source_out > total:
        raise ValueError('Edit exceeds available source frames')

    kwargs = dict(asset=asset_id, start=program_in, source_in=source_in, duration=duration)
    primary = destinations[0]
    updated, clip_id = apply_edit(project, operation, container_id=container_id, track=primary, **kwargs)
    ids = [clip_id]
    if len(destinations) == 2:
        second = destinations[1]
        if operation == 'overwrite':
            updated, second_id = apply_edit(updated, operation, container_id=container_id,
                                            track=second, **kwargs)
        else:
            # Insert already rippled every unlocked track and captions exactly
            # once. Add the second patched stream without a second ripple.
            target = editing_container(updated, container_id)
            second_clip = create_clip(media, second, program_in, source_in, duration, updated['fps'])
            if second_clip['duration'] != duration:
                raise ValueError('Patched audio/video has insufficient source handles')
            target['clips'].append(second_clip)
            validate(updated)
            second_id = second_clip['id']
        ids.append(second_id)
    return updated, ids, dict(source_in=source_in, source_out=source_out,
                              program_in=program_in, program_out=program_in + duration,
                              duration=duration)
