"""Curated DaFont fonts for commercial video use, with local, offline import.

This module never scrapes DaFont or downloads assets in the background.
The DaFont '100% Free' tag alone is not a grant of redistribution rights.
Each family below has a direct author/license statement from its DaFont page.
Font files remain owned by their creators; users provide the original ZIP.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import io
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

# Explicitly sourced, hand-reviewed family list. Update licenses manually.
# family id, display name, genre, designer, verified license, filename variants
_FAMILIES = [
    ('creato-display', 'Creato Display', 'Headlines & Modern', 'Lafontype', 'SIL OFL 1.1',
     'CreatoDisplay-Thin.otf,CreatoDisplay-Light.otf,CreatoDisplay-Regular.otf,CreatoDisplay-Medium.otf,CreatoDisplay-Bold.otf,CreatoDisplay-ExtraBold.otf,CreatoDisplay-Black.otf,CreatoDisplay-ThinItalic.otf,CreatoDisplay-LightItalic.otf,CreatoDisplay-RegularItalic.otf,CreatoDisplay-MediumItalic.otf,CreatoDisplay-BoldItalic.otf,CreatoDisplay-ExtraBoldItalic.otf,CreatoDisplay-BlackItalic.otf'),
    ('juliett', 'Juliett', 'Clean & Modern', 'GGBotNet', 'SIL OFL 1.1',
     'Juliett-Regular.ttf,Juliett-Bold.ttf,Juliett-Italic.ttf,Juliett-BoldItalic.ttf'),
    ('elevatia', 'Elevatia', 'Clean & Modern', 'GGBotNet', 'SIL OFL 1.1',
     'Elevatia-Regular.ttf,Elevatia-Italic.ttf'),
    ('thernaly', 'Thernaly', 'Clean & Modern', 'GGBotNet', 'SIL OFL 1.1',
     'Thernaly-Regular.ttf,Thernaly-Italic.ttf'),
    ('wiltype', 'Wiltype', 'Clean & Modern', 'GGBotNet', 'SIL OFL 1.1', 'Wiltype.ttf'),
    ('friendly-sans', 'Friendly Sans', 'Handwriting', 'GGBotNet', 'SIL OFL 1.1',
     'FriendlySans-Regular.ttf,FriendlySans-Italic.ttf'),
    ('signwood', 'Signwood', 'Vintage & Retro', 'GGBotNet', 'SIL OFL 1.1',
     'Signwood-Regular.ttf,Signwood-Italic.ttf'),
    ('pinzelan', 'Pinzelan', 'Handwriting', 'GGBotNet', 'SIL OFL 1.1',
     'Pinzelan-Regular.ttf,Pinzelan-Italic.ttf'),
    ('eightgon', 'Eightgon', 'Tech & Futuristic', 'GGBotNet', 'SIL OFL 1.1',
     'Eightgon-Regular.ttf,Eightgon-Italic.ttf'),
    ('datdot', 'Datdot', 'Tech & Futuristic', 'GGBotNet', 'SIL OFL 1.1',
     'DatDot-Light.ttf,DatDot-Regular.ttf,DatDot-Bold.ttf'),
    ('pixelbasel', 'Pixelbasel', 'Pixel & Gaming', 'GGBotNet', 'SIL OFL 1.1', 'Pixelbasel.ttf'),
    ('help-me', 'Help Me', 'Horror & Display', 'GGBotNet', 'SIL OFL 1.1', 'HelpMe.ttf'),
    ('public-pixel', 'Public Pixel', 'Pixel & Gaming', 'GGBotNet', 'CC0 1.0', 'PublicPixel.ttf'),
    ('home-video', 'Home Video', 'Pixel & Gaming', 'GGBotNet', 'CC0 1.0',
     'HomeVideo-Regular.ttf,HomeVideo-Bold.ttf'),
    ('unitblock', 'Unitblock', 'Headlines & Modern', 'GGBotNet', 'CC0 1.0', 'Unitblock.ttf'),
    ('hexcore', 'Hexcore', 'Tech & Futuristic', 'GGBotNet', 'CC0 1.0', 'Hexcore.ttf'),
    ('saved-by-zero', 'Saved by Zero', 'Tech & Futuristic', 'Typodermic Fonts', 'CC0 1.0',
     'Saved by Zero Rg.otf'),
]
FAMILIES = {
    identifier: {
        'id': identifier, 'name': name, 'category': category,
        'author': author, 'license': license_name,
        'source': f'https://www.dafont.com/{identifier}.font',
        'commercial_use': True,
        'bundled': False, 'provider': 'DaFont',
        'expected_files': tuple(part.strip() for part in files.split(',')),
    }
    for identifier, name, category, author, license_name, files in _FAMILIES
}
MAX_ARCHIVE_BYTES = 7 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 22 * 1024 * 1024
MAX_FONT_BYTES = 5 * 1024 * 1024


def _selected_variant(family_id: str, variant: str, library: Path) -> Path:
    family = FAMILIES.get(family_id)
    if family is None:
        raise ValueError('Fonte não reconhecida no catálogo DaFont')
    if variant not in family['expected_files']:
        raise ValueError('Variante de fonte não reconhecida')
    dest = (Path(library) / family_id / variant).resolve()
    if not dest.is_relative_to(Path(library).resolve()) or not dest.is_file():
        raise ValueError('Baixe e importe o ZIP original da fonte antes de usá-la')
    return dest


def font_path(family_id: str, variant: str, library: Path) -> str:
    return str(_selected_variant(family_id, variant, library))


def catalog(library: Path) -> list[dict]:
    result = []
    for data in FAMILIES.values():
        record = {k: (list(v) if k == 'expected_files' else v) for k, v in data.items()}
        record['installed_files'] = [name for name in data['expected_files']
                                     if (Path(library) / data['id'] / name).is_file()]
        record['installed'] = bool(record['installed_files'])
        result.append(record)
    return result


def _valid_font(raw: bytes) -> bool:
    # FreeType/Pillow validates that the bytes are an actual loadable face.
    try:
        from PIL import ImageFont
        ImageFont.truetype(io.BytesIO(raw), 16)
    except (ImportError, OSError, ValueError):
        return False
    return True


def import_archive(family_id: str, archive_b64: str, library: Path) -> dict:
    """Import the downloaded ZIP, accepting only documented family file names.

    No ZipFile.extract() is used, preventing traversal and symlink extraction.
    This does not cryptographically attest authorship; use original DaFont ZIPs.
    """
    family = FAMILIES.get(family_id)
    if not family:
        raise ValueError('Fonte não encontrada no catálogo comercial aprovado')
    if not isinstance(archive_b64, str) or len(archive_b64) > MAX_ARCHIVE_BYTES * 4 // 3 + 16:
        raise ValueError('ZIP muito grande (limite de 7 MB)')
    try:
        data = base64.b64decode(archive_b64, validate=True)
    except (binascii.Error, ValueError) as e:
        raise ValueError('Arquivo codificado inválido') from e
    if len(data) > MAX_ARCHIVE_BYTES:
        raise ValueError('ZIP muito grande (limite de 7 MB)')
    selected: dict[str, bytes] = {}
    extras: dict[str, bytes] = {}
    expected = {name.casefold(): name for name in family['expected_files']}
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            infos = archive.infolist()
            if len(infos) > 200 or sum(f.file_size for f in infos) > MAX_UNCOMPRESSED_BYTES:
                raise ValueError('ZIP contém arquivos demais ou excede o limite descompactado')
            for item in infos:
                if item.is_dir():
                    continue
                # reject UNIX symbolic links, arbitrary nested names are not extracted
                if (item.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Atalhos simbólicos não são aceitos no ZIP')
                name = item.filename.replace('\\', '/').split('/')[-1]
                key = name.casefold()
                if key in expected:
                    canonical = expected[key]
                    if canonical in selected:
                        raise ValueError('ZIP possui variantes de fonte duplicadas')
                    if item.file_size > MAX_FONT_BYTES:
                        raise ValueError('Uma das fontes excede 5 MB')
                    raw = archive.read(item)
                    if not _valid_font(raw):
                        raise ValueError(f'Arquivo de fonte inválido: {canonical}')
                    selected[canonical] = raw
                elif name.lower() in {'license.txt', 'license.md', 'ofl.txt', 'readme.txt', 'readme.md', 'copyright.txt'} and item.file_size <= 200_000:
                    extras[name.lower()] = archive.read(item)
    except zipfile.BadZipFile as e:
        raise ValueError('Selecione o arquivo ZIP original baixado do DaFont') from e
    if not selected:
        raise ValueError(f'O ZIP não contém as variantes esperadas de {family["name"]}; confira o download no DaFont')

    root = Path(library)
    root.mkdir(parents=True, exist_ok=True)
    # Prepare fully before replacing any saved variant. No writes outside app library.
    staging = Path(tempfile.mkdtemp(prefix='.import-', dir=root))
    try:
        for name, raw in selected.items():
            (staging / name).write_bytes(raw)
        for name, raw in extras.items():
            (staging / name).write_bytes(raw)
        (staging / 'source.json').write_text(json.dumps({
            'family': family_id, 'author': family['author'], 'license': family['license'],
            'source': family['source'], 'archive_sha256': hashlib.sha256(data).hexdigest(),
            'variants': list(selected), 'downloaded_by_user': True
        }, ensure_ascii=False, indent=2), encoding='utf-8')
        destination = root / family_id
        if destination.exists():
            # Keep existing variants and documentation that this ZIP did not include.
            for existing in destination.iterdir():
                if existing.is_file() and existing.name not in selected and existing.name not in extras and existing.name != 'source.json':
                    shutil.copy2(existing, staging / existing.name)
            backup = root / ('.previous-' + family_id)
            if backup.exists():
                shutil.rmtree(backup)
            destination.rename(backup)
            try:
                staging.rename(destination)
            except Exception:
                backup.rename(destination)
                raise
            shutil.rmtree(backup)
        else:
            staging.rename(destination)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return {'id': family_id, 'name': family['name'], 'installed_files': sorted(selected),
            'license': family['license'], 'source': family['source']}
