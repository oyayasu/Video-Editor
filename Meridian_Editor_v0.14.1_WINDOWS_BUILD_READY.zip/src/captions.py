"""Offline subtitle support for Meridian's technical preview.

The engine is optional: faster-whisper is not downloaded or initialized until
someone explicitly requests speech recognition. No paid service is called.
"""
from __future__ import annotations

import math
from pathlib import Path

ALLOWED_MODELS = {'small', 'medium', 'large-v3', 'turbo'}


def map_segments_to_clip(segments, clip, fps):
    """Map source-media time to integer-frame timeline captions.

    Respect source-in / clip duration; do not generate captions beyond the
    region of the source used by the selected clip.
    """
    left, right = clip['source_in'], clip['source_in'] + clip['duration']
    result = []
    for segment in segments:
        text = ' '.join(str(segment.get('text', '')).strip().split())
        if not text:
            continue
        start = float(segment['start'])
        end = float(segment['end'])
        if not all(math.isfinite(x) and x >= 0 for x in (start, end)) or end <= start:
            continue
        local_start = max(left, round(start * fps))
        local_end = min(right, round(end * fps))
        if local_start >= local_end:
            continue
        result.append({'start': clip['start'] + local_start - left,
                       'duration': local_end-local_start, 'text': text})
    return result


def milliseconds(frames, fps):
    return max(0, int(round(frames * 1000 / fps)))


def clock_ms(ms, separator=','):
    hrs, remainder = divmod(ms, 3600000)
    mins, remainder = divmod(remainder, 60000)
    secs, millis = divmod(remainder, 1000)
    return f'{hrs:02d}:{mins:02d}:{secs:02d}{separator}{millis:03d}'


def subtitles_to_text(captions, fps, fmt='srt'):
    if fmt not in ('srt','vtt'):
        raise ValueError('Unsupported subtitle format')
    result = ['WEBVTT', ''] if fmt == 'vtt' else []
    for i, c in enumerate(sorted(captions, key=lambda x:(x['start'], x.get('id',''))), start=1):
        a = milliseconds(c['start'], fps)
        b = milliseconds(c['start']+c['duration'], fps)
        if b <= a:
            b = a + 1
        if fmt == 'srt':
            result.append(str(i))
        sep = ',' if fmt == 'srt' else '.'
        result.append(f'{clock_ms(a,sep)} --> {clock_ms(b,sep)}')
        result.append(str(c['text']).strip())
        result.append('')
    return '\n'.join(result).rstrip()+'\n'


def recognize(path, model='turbo', language=None, progress=None):
    """Run local Whisper recognition; may download model weights on first use.

    This integration initially runs on CPU unless a compatible CTranslate2
    CUDA installation is present. CUDA does NOT imply AMD/Vulkan support.
    """
    if model not in ALLOWED_MODELS:
        raise ValueError('Unsupported recognition model')
    if language and (not isinstance(language,str) or len(language)>10):
        raise ValueError('Invalid language')
    if not Path(path).is_file():
        raise FileNotFoundError('Source media not found')
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError('Offline transcription requires faster-whisper. Install: python -m pip install faster-whisper') from exc
    if progress:
        progress('Loading local transcription model (initial download may be required)…',0)
    # compute_type=int8 minimizes RAM pressure on the fallback CPU path.
    # The turbo alias is resolved explicitly to its upstream model identifier.
    model_id = 'large-v3-turbo' if model == 'turbo' else model
    recognizer = WhisperModel(model_id,device='cpu',compute_type='int8')
    segments, info = recognizer.transcribe(str(path),language=language or None,beam_size=5,vad_filter=True,word_timestamps=True)
    length = max(float(getattr(info,'duration',0) or 0),.01)
    result=[]
    for seg in segments:
        result.append({'start':float(seg.start),'end':float(seg.end),'text':str(seg.text).strip()})
        if progress:
            progress('Recognizing speech locally…',min(99,round(100*float(seg.end)/length)))
    return result
