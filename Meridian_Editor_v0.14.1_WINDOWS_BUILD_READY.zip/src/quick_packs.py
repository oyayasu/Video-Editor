"""Meridian-authored, commercial-use preset recipes.

A preset is a versioned recipe of supported native clip properties and effects.
It contains no third-party asset, font, executable shader or copied template.
Clips are changed transactionally by apply_preset; unknown keys fail closed.
"""
from __future__ import annotations

import copy
from .effects import BY_TYPE
from .model import validate, editing_container

PRESETS = []

def add(pid, name, category, kind, description, *, motion=None, effects=None):
    PRESETS.append(dict(id=pid, name=name, category=category, kind=kind,
                        description=description, motion=motion or {}, effects=effects or []))

# Animated frame positions feed the same timeline model as user-authored keys.
# x/y keyframes and built-in alpha fades are supported by the stable FFmpeg path.
_DIRECTIONS = {'left':(-1,0),'right':(1,0),'top':(0,-1),'bottom':(0,1)}
for label,(dx,dy) in _DIRECTIONS.items():
    for placement in ('in','out'):
        for style,factor,frames,fade in (
            ('Smooth',.30,18,True),('Fast',.22,9,True),('Long',.55,27,True),
            ('Clean',.30,18,False),('Overshoot',.30,21,True)):
            add(f'motion-{placement}-{label}-{style.lower()}',
                f'{style} slide {placement} · {label.title()}',
                'Entrance Animations' if placement=='in' else 'Exit Animations',
                'video', 'Animated position over clip frames, with optional alpha fade.',
                motion=dict(direction=label,placement=placement,style=style.lower(),
                            factor=factor,frames=frames,fade=fade))
for pid,name,kind,details in (
    ('fade-in-soft','Soft Fade In','in',15),('fade-out-soft','Soft Fade Out','out',15),
    ('fade-in-fast','Quick Fade In','in',7),('fade-out-fast','Quick Fade Out','out',7),
    ('fade-in-long','Cinematic Fade In','in',30),('fade-out-long','Cinematic Fade Out','out',30),
):
    add(pid,name,'Entrance Animations' if kind=='in' else 'Exit Animations','video',
        'Smooth alpha-only opacity animation.',motion={'placement':kind,'frames':details,'fade':True})
for pid,name,patterns in (
    ('warm-cinema','Warm Cinema',[('temperature',{'kelvin':6200}),('vibrance',{'intensity':.25}),('vignette',{'strength':.30})]),
    ('cold-drama','Cold Drama',[('temperature',{'kelvin':4200}),('brightness_contrast',{'brightness':-.06,'contrast':1.17})]),
    ('bright-airy','Bright & Airy',[('brightness_contrast',{'brightness':.12,'contrast':.94}),('saturation',{'amount':1.08})]),
    ('bold-color','Bold Color',[('vibrance',{'intensity':.65}),('brightness_contrast',{'brightness':.015,'contrast':1.16})]),
    ('matte-film','Matte Film',[('brightness_contrast',{'brightness':.045,'contrast':.86}),('vignette',{'strength':.35})]),
    ('mono-classic','Monochrome Classic',[('monochrome',{}),('brightness_contrast',{'brightness':-.01,'contrast':1.2})]),
    ('mono-soft','Monochrome Soft',[('monochrome',{}),('brightness_contrast',{'brightness':.05,'contrast':.88})]),
    ('vintage-warm','Warm Vintage',[('curves_vintage',{}),('vignette',{'strength':.35})]),
    ('vintage-grain','Film Grain',[('curves_vintage',{}),('video_noise',{'amount':10})]),
    ('retro-print','Retro Print',[('posterize',{'levels':8}),('saturation',{'amount':.75})]),
    ('noir-grain','Noir Grain',[('monochrome',{}),('brightness_contrast',{'brightness':-.045,'contrast':1.33}),('video_noise',{'amount':8})]),
    ('soft-dream','Soft Dream',[('gaussian_blur',{'radius':1.1}),('brightness_contrast',{'brightness':.06,'contrast':.9})]),
    ('crisp-detail','Crisp Detail',[('sharpen',{'amount':1.25}),('vibrance',{'intensity':.15})]),
    ('clean-documentary','Documentary Natural',[('denoise',{'strength':2.5}),('sharpen',{'amount':.45})]),
    ('electric-blue','Electric Blue',[('color_tint',{'hue':210,'mix':.24}),('vibrance',{'intensity':.48})]),
    ('sunset','Golden Sunset',[('temperature',{'kelvin':6900}),('saturation',{'amount':1.20})]),
    ('midnight','Midnight',[('temperature',{'kelvin':3900}),('brightness_contrast',{'brightness':-.13,'contrast':1.12})]),
    ('pastel','Pastel',[('saturation',{'amount':.68}),('brightness_contrast',{'brightness':.09,'contrast':.91})]),
    ('high-contrast','High Contrast',[('brightness_contrast',{'brightness':-.018,'contrast':1.42})]),
    ('washed-retro','Washed Retro',[('curves_vintage',{}),('saturation',{'amount':.62})]),
    ('soft-focus','Soft Focus',[('gaussian_blur',{'radius':1.7}),('vignette',{'strength':.2})]),
    ('digital-glitch','Digital Glitch',[('rgb_split',{'pixels':4}),('video_noise',{'amount':15})]),
    ('edge-art','Edge Art',[('find_edges',{}),('invert',{})]),
    ('lowfi-pixel','Pixel Art',[('mosaic',{'block':12}),('posterize',{'levels':6})]),
):
    add(pid,name,'Color Looks & Styles','video',
        'One-click stack of native, individually adjustable Meridian effects.',effects=patterns)
for pid,name,patterns in (
    ('voice-clear','Clear Voice',[('highpass',{'frequency':90}),('audio_deesser',{'strength':.35}),('compressor',{'threshold':.14,'ratio':2.5})]),
    ('voice-podcast','Podcast Voice',[('highpass',{'frequency':75}),('bass_eq',{'gain':1.5}),('compressor',{'threshold':.15,'ratio':3.0}),('audio_limiter',{'ceiling':.9})]),
    ('voice-radio','Radio Narrator',[('highpass',{'frequency':105}),('lowpass',{'frequency':7500}),('compressor',{'threshold':.12,'ratio':5})]),
    ('voice-telephone','Telephone Voice',[('highpass',{'frequency':330}),('lowpass',{'frequency':3400})]),
    ('voice-air','Airy Vocal',[('highpass',{'frequency':80}),('treble_eq',{'gain':2})]),
    ('voice-warm','Warm Vocal',[('highpass',{'frequency':60}),('bass_eq',{'gain':2.5}),('compressor',{'threshold':.2,'ratio':2})]),
    ('noise-cleanup','Noise Cleanup',[('audio_denoise',{'reduction':9}),('audio_gate',{'threshold':.045})]),
    ('music-tight','Music Tight',[('compressor',{'threshold':.25,'ratio':2.4}),('audio_limiter',{'ceiling':.88})]),
    ('music-bass','Bass Boost',[('bass_eq',{'gain':4}),('audio_limiter',{'ceiling':.88})]),
    ('music-bright','Bright Mix',[('treble_eq',{'gain':2.4}),('audio_limiter',{'ceiling':.88})]),
    ('audio-dream','Dream Echo',[('echo',{'delay':240,'decay':.27}),('audio_chorus',{})]),
    ('audio-space','Room Depth',[('room_echo',{'mix':.28}),('highpass',{'frequency':60})]),
):
    add(pid,name,'Audio Chains','audio',
        'Non-destructive ordered native audio effect chain.',effects=patterns)

BY_ID={p['id']:p for p in PRESETS}

# Keep the existing 37 OFL Google families for backwards compatibility;
# add a distinct curated DaFont tab without dropping earlier discoveries.
from pathlib import Path
from .font_library import catalog as dafont_catalog

_FONT_GROUPS={
 'Clean & Modern':['Inter','DM Sans','Roboto','Montserrat','Poppins','Lato','Work Sans','Rubik','Raleway','Outfit','Manrope'],
 'Condensed & Headlines':['Oswald','Anton','Bebas Neue','Barlow Condensed','Archivo','Teko','Fjalla One'],
 'Editorial & Serif':['Playfair Display','Libre Baskerville','Lora','Merriweather','Cormorant Garamond','EB Garamond'],
 'Handwritten & Display':['Caveat','Pacifico','Dancing Script','Permanent Marker'],
 'Mono & Tech':['Roboto Mono','Space Mono','Source Code Pro','Fira Code'],
 'Multilingual':['Noto Sans','Noto Serif','Noto Sans JP','Noto Sans SC','Noto Sans Arabic'],
}
def google_font_catalog():
    return [dict(id='google-'+name.lower().replace(' ','-'), name=name, category=category,license='SIL OFL 1.1',provider='Google Fonts',installed=False,installed_files=[],
                 source='https://github.com/google/fonts/tree/main/ofl/'+name.lower().replace(' ',''),
                 commercial_use=True, bundled=False)
            for category,names in _FONT_GROUPS.items() for name in names]


def font_catalog(library: Path | None = None):
    storage=library if library is not None else (Path.home()/'.meridian-editor'/'fonts')
    return dafont_catalog(storage)+google_font_catalog()

def catalog():
    return [{k:v for k,v in p.items() if k not in ('motion','effects')} for p in PRESETS]


def _instance(effect_name, overrides):
    from .model import identifier
    spec=BY_TYPE[effect_name]
    defaults={key:settings['default'] for key,settings in spec['params'].items()}
    defaults.update(overrides)
    return dict(id=identifier(),type=effect_name,enabled=True,params=defaults,keyframes={})


def apply_preset(doc, clip_id, preset_id, container_id=None):
    """Apply preset to a clip and return a *new validated document* (atomic)."""
    preset=BY_ID.get(preset_id)
    if preset is None:raise ValueError('Unknown preset')
    result=copy.deepcopy(doc)
    validate(result)
    timeline=editing_container(result,container_id)
    clip=next((c for c in timeline['clips'] if c['id']==clip_id),None)
    if not clip:raise ValueError('Clip not found')
    kind=next(t['kind'] for t in timeline['tracks'] if t['id']==clip['track'])
    if kind!=preset['kind']:raise ValueError('Preset incompatible with clip track')
    if next(t['locked'] for t in timeline['tracks'] if t['id']==clip['track']):
        raise ValueError('Cannot apply presets on locked tracks')
    clip.setdefault('keyframes',{});clip.setdefault('effects',[])
    more=[_instance(typ,values) for typ,values in preset['effects']]
    motion=preset['motion']
    if motion:
        duration=clip['duration']
        if duration<2:raise ValueError('Animation preset requires at least two frames')
        span=min(duration-1,motion.get('frames',18)-1)
        phase=motion['placement']
        ease='ease'
        if motion.get('direction'):
            direction=motion['direction'];dx,dy=_DIRECTIONS[direction]
            distance=round((result['width'] if dx else result['height'])*motion.get('factor',.3),2)
            target='x' if dx else 'y';base=float(clip['properties'].get(target,0))
            start_frame=0 if phase=='in' else duration-1-span
            start_value=base+distance*(dx or dy) if phase=='in' else base
            end_value=base if phase=='in' else base+distance*(dx or dy)
            points=[(start_frame,start_value),(start_frame+span,end_value)]
            if motion.get('style')=='overshoot' and span>=5:
                near=start_frame+int(span*.76)
                extra=base-distance*(dx or dy)*.08 if phase=='in' else base-distance*(dx or dy)*.08
                points=[(start_frame,start_value),(near,extra),(start_frame+span,end_value)]
            # An application intentionally replaces keys ONLY in its own movement axis.
            clip['keyframes'][target]=[dict(frame=frame,value=value,interpolation=ease) for frame,value in points]
        if motion.get('fade'):
            more.append(_instance('fade_in' if phase=='in' else 'fade_out',{'frames':min(duration,span+1)}))
    if len(clip['effects'])+len(more)>64:raise ValueError('Maximum of 64 effects per clip')
    clip['effects'].extend(more)
    validate(result)
    return result
