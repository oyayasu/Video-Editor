"""Headless, dependency-free editorial document model. Integer-frame timeline."""
from __future__ import annotations
import copy
import json
import math
import os
import uuid
from pathlib import Path
from .effects import validate_clip_effects
from .masks import validate_masks

SCHEMA = 1
PROPERTIES = ('x', 'y', 'scale', 'rotation', 'opacity', 'volume', 'brightness', 'contrast', 'saturation', 'blur')
DEFAULTS = dict(x=0.0, y=0.0, scale=1.0, rotation=0.0, opacity=1.0,
                volume=1.0, brightness=0.0, contrast=1.0, saturation=1.0, blur=0.0)

def identifier():
    return uuid.uuid4().hex[:12]

def fresh():
    return {'schema':SCHEMA, 'name':'Untitled', 'fps':30, 'width':1920,'height':1080,
            'media':[], 'tracks':[{'id':'V2','kind':'video','name':'V2','muted':False,'locked':False},
                                 {'id':'V1','kind':'video','name':'V1','muted':False,'locked':False},
                                 {'id':'A1','kind':'audio','name':'A1','muted':False,'locked':False},
                                 {'id':'A2','kind':'audio','name':'A2','muted':False,'locked':False}],
            'clips':[], 'transitions':[], 'sequences':[], 'captions':[], 'markers':[], 'playhead':0, 'source_ranges':{}}

def media_item(path, probe, fps=30):
    return {'id': identifier(), 'path': os.path.abspath(path), 'name':Path(path).name,
            'duration_frames':max(1,int(round(probe['duration']*fps))),
            'duration_seconds':float(probe['duration']),
            'video':bool(probe['video']), 'audio':bool(probe['audio']),
            'width':int(probe.get('width',0)), 'height':int(probe.get('height',0))}

def create_clip(media, track, start, source_in=0, duration=None, fps=30):
    maxframes=max(1,round(float(media['duration_seconds'])*fps))
    available=maxframes-int(source_in)
    if available<1: raise ValueError('Source in point beyond media duration')
    count=min(available, int(duration) if duration is not None else available)
    if count<1: raise ValueError('Clip duration must be positive')
    return {'id': identifier(), 'asset':media['id'], 'track':track,
            'start':int(start),'source_in':int(source_in),'duration':count,
            'properties':copy.deepcopy(DEFAULTS),'keyframes':{},'effects':[],'masks':[],'enabled':True}

def value_at(clip, property_name, local_frame):
    default=float(clip.get('properties',{}).get(property_name,DEFAULTS[property_name]))
    keys=sorted(clip.get('keyframes',{}).get(property_name,[]),key=lambda k:k['frame'])
    if not keys: return default
    if local_frame<=keys[0]['frame']:return float(keys[0]['value'])
    if local_frame>=keys[-1]['frame']:return float(keys[-1]['value'])
    for a,b in zip(keys,keys[1:]):
        if a['frame']<=local_frame<=b['frame']:
            if a.get('interpolation')=='hold': return float(a['value'])
            p=(local_frame-a['frame'])/(b['frame']-a['frame'])
            if a.get('interpolation')=='ease':p=p*p*(3-2*p)
            return float(a['value'])+(float(b['value'])-float(a['value']))*p
    return default

def validate(doc):
    if not isinstance(doc,dict) or doc.get('schema')!=SCHEMA: raise ValueError('Unsupported project schema')
    if not isinstance(doc.get('name'),str):raise ValueError('Invalid project title')
    if doc.get('fps') not in (24,25,30,50,60):raise ValueError('Unsupported frame rate; supported: 24,25,30,50,60')
    if doc.get('width') not in (1280,1920,2560,3840) or doc.get('height') not in (720,1080,1440,2160):raise ValueError('Unsupported canvas dimensions')
    media={x['id']:x for x in doc['media']}
    tracks={x['id']:x for x in doc['tracks']}
    if len(media)!=len(doc['media']) or len(tracks)!=len(doc['tracks']):raise ValueError('Duplicate IDs')
    if len(doc['clips'])>5000:raise ValueError('Project too large')
    for asset in doc['media']:
        if not isinstance(asset['path'],str) or not os.path.isabs(asset['path']):raise ValueError('Invalid media path')
        if float(asset['duration_seconds'])<=0:raise ValueError('Invalid media duration')
    ranges=doc.get('source_ranges', {})
    if not isinstance(ranges,dict) or len(ranges)>len(media):
        raise ValueError('Invalid Source Monitor marks')
    for media_id, markers in ranges.items():
        if media_id not in media or not isinstance(markers,dict) or set(markers)!={'in','out'}:
            raise ValueError('Source marks refer to missing media')
        begin,end=markers['in'],markers['out']
        limit=max(1,round(float(media[media_id]['duration_seconds'])*doc['fps']))
        if (begin is not None and (type(begin) is not int or not 0<=begin<limit)) or (end is not None and (type(end) is not int or not 1<=end<=limit)):
            raise ValueError('Source mark outside media')
        if begin is not None and end is not None and begin>=end:
            raise ValueError('Source In must precede Source Out')
    sequences=doc.get('sequences', [])
    if not isinstance(sequences,list) or len(sequences)>1000:
        raise ValueError('Invalid nested sequence collection')
    seq_by_id={}
    for seq in sequences:
        if not isinstance(seq,dict) or not isinstance(seq.get('id'),str) or not seq['id'] or seq['id'] in seq_by_id:
            raise ValueError('Invalid or duplicate sequence ID')
        if not isinstance(seq.get('name'),str) or len(seq['name'])>200:
            raise ValueError('Invalid sequence name')
        if not isinstance(seq.get('clips'),list) or not isinstance(seq.get('tracks'),list):
            raise ValueError('Invalid nested sequence tracks/clips')
        if type(seq.get('duration')) is not int or seq['duration']<1:
            raise ValueError('Invalid nested sequence duration')
        seq_by_id[seq['id']]=seq
    def check_clips(items, local_tracks):
        if len(items)>5000:raise ValueError('Sequence has too many clips')
        local_track_index={t['id']:t for t in local_tracks}
        if len(local_track_index)!=len(local_tracks) or any(t['kind'] not in ('audio','video') for t in local_tracks):
            raise ValueError('Invalid nested track definitions')
        ids=set()
        for clip in items:
            if clip['id'] in ids:raise ValueError('Duplicate clip ID')
            ids.add(clip['id'])
            if clip['track'] not in local_track_index:raise ValueError('Clip refers to a missing track')
            nested=clip.get('sequence_id')
            if nested is not None:
                if nested not in seq_by_id:raise ValueError('Clip refers to missing nested sequence')
            elif clip.get('asset') not in media:
                raise ValueError('Clip refers to a missing media asset')
            if any(type(clip.get(k)) is not int for k in ('start','source_in','duration')):
                raise ValueError('Timeline positions must be integer frames')
            if min(clip['start'],clip['source_in'])<0 or clip['duration']<=0:
                raise ValueError('Invalid clip time')
            if nested is None and clip['source_in']+clip['duration']>math.ceil(float(media[clip['asset']]['duration_seconds'])*doc['fps'])+1:
                raise ValueError('Clip exceeds source length')
            validate_clip_effects(clip,local_track_index[clip['track']]['kind'])
            validate_masks(clip,local_track_index[clip['track']]['kind'])
            for key,val in clip.get('properties',{}).items():
                if key not in DEFAULTS or not math.isfinite(float(val)):raise ValueError('Invalid property')
            for key,curve in clip.get('keyframes',{}).items():
                if key not in DEFAULTS or not isinstance(curve,list):raise ValueError('Invalid keyframe property')
                seen=set()
                for k in curve:
                    f=k['frame']
                    if type(f) is not int or f<0 or f>=clip['duration'] or f in seen:
                        raise ValueError('Invalid or duplicate keyframe')
                    if not math.isfinite(float(k['value'])):raise ValueError('Non-finite keyframe')
                    if k.get('interpolation','linear') not in ('linear','hold','ease'):
                        raise ValueError('Unsupported interpolation')
                    seen.add(f)
    check_clips(doc['clips'],doc['tracks'])
    for seq in sequences:check_clips(seq['clips'],seq['tracks'])
    check_transitions(doc)
    for seq in sequences: check_transitions(seq)

    visiting=set()
    visited=set()
    def visit(seq_id):
        if seq_id in visiting:raise ValueError('Nested sequence cycle detected')
        if seq_id in visited:return
        visiting.add(seq_id)
        for c in seq_by_id[seq_id]['clips']:
            if c.get('sequence_id'):visit(c['sequence_id'])
        visiting.remove(seq_id);visited.add(seq_id)
    for seq_id in seq_by_id:visit(seq_id)
    captions = doc.get('captions', [])
    if not isinstance(captions,list) or len(captions)>20000:
        raise ValueError('Invalid subtitles collection')
    known=set()
    for c in captions:
        if not isinstance(c,dict) or not isinstance(c.get('id'),str) or c['id'] in known:
            raise ValueError('Invalid or duplicate subtitle ID')
        known.add(c['id'])
        if any(type(c.get(key)) is not int for key in ('start','duration')) or c['start']<0 or c['duration']<1:
            raise ValueError('Invalid subtitle time')
        if not isinstance(c.get('text'),str) or len(c['text'])>2000:
            raise ValueError('Invalid subtitle text')
    return doc

TRANSITION_KINDS = (
    'cross_dissolve', 'wipe_left', 'wipe_right', 'wipe_up', 'wipe_down',
    'soft_wipe_left', 'soft_wipe_right', 'soft_wipe_up', 'soft_wipe_down',
    'diagonal_tl', 'diagonal_br', 'circle_reveal', 'audio_crossfade'
)

def check_transitions(timeline):
    """A transition is a time-bounded relationship between two overlapping clips.

    Projects from v0.5 omit transitions and remain valid. Only transitions
    between distinct video clips on the same track are accepted. This prevents
    silent no-op effects and leaves audio crossfades for a later engine.
    """
    entries=timeline.get('transitions',[])
    if not isinstance(entries,list) or len(entries)>2000:
        raise ValueError('Invalid transition collection')
    clips={c['id']:c for c in timeline['clips']}
    tracks={t['id']:t for t in timeline['tracks']}
    seen_ids=set();seen_pairs=set();windows_by_track={}
    for item in entries:
        if not isinstance(item,dict) or not isinstance(item.get('id'),str) or not item['id'] or item['id'] in seen_ids:
            raise ValueError('Invalid or duplicate transition ID')
        seen_ids.add(item['id'])
        outgoing=clips.get(item.get('outgoing'))
        incoming=clips.get(item.get('incoming'))
        if not outgoing or not incoming or outgoing is incoming:
            raise ValueError('Transition references missing clips')
        if outgoing['track']!=incoming['track']:
            raise ValueError('Transitions require two clips on the same track')
        if item.get('type') not in TRANSITION_KINDS:
            raise ValueError('Unknown transition type')
        kind=tracks[outgoing['track']]['kind']
        if (kind=='audio') != (item['type']=='audio_crossfade'):
            raise ValueError('Audio and video transitions are incompatible with this track')
        if not outgoing.get('enabled',True) or not incoming.get('enabled',True):
            raise ValueError('Transitions require enabled clips')
        if type(item.get('start')) is not int or type(item.get('duration')) is not int or item['duration']<2:
            raise ValueError('Invalid transition timing')
        if not (outgoing['start']<incoming['start'] and
                incoming['start']==item['start'] and
                item['start']+item['duration']<=min(outgoing['start']+outgoing['duration'],incoming['start']+incoming['duration'])):
            raise ValueError('Transition must fit inside the overlap of its two clips')
        pair=(outgoing['id'],incoming['id'])
        if pair in seen_pairs: raise ValueError('Duplicate transition pair')
        seen_pairs.add(pair)
        start,end=item['start'],item['start']+item['duration']
        for a,b in windows_by_track.get(outgoing['track'],[]):
            if start<b and end>a:
                raise ValueError('Overlapping transitions on the same track are unsupported')
        windows_by_track.setdefault(outgoing['track'],[]).append((start,end))
    return entries

def add_transition(doc, outgoing_id, incoming_id, transition_type='cross_dissolve', duration=None, container_id=None):
    """Attach a two-source transition without altering media or hidden handles."""
    validate(doc)
    timeline=editing_container(doc,container_id)
    clips={c['id']:c for c in timeline['clips']}
    a,b=clips.get(outgoing_id),clips.get(incoming_id)
    if not a or not b: raise ValueError('Select two existing clips')
    if a['start']>b['start']:a,b=b,a
    start=b['start']; max_end=min(a['start']+a['duration'],b['start']+b['duration'])
    overlap=max_end-start
    if overlap<2:raise ValueError('Overlap two clips on one track by at least 2 frames first')
    length=overlap if duration is None else duration
    if type(length) is not int or not 2<=length<=overlap:
        raise ValueError('Transition duration exceeds clip overlap')
    item={'id':identifier(),'type':transition_type,'outgoing':a['id'],'incoming':b['id'],
          'start':start,'duration':length}
    timeline.setdefault('transitions',[]).append(item)
    try:validate(doc)
    except Exception:
        timeline['transitions'].remove(item)
        raise
    return item


def prune_transitions(timeline):
    """Remove stale transitions when the editor explicitly deletes a clip."""
    alive={c['id'] for c in timeline['clips']}
    timeline['transitions']=[t for t in timeline.get('transitions',[])
                              if t['outgoing'] in alive and t['incoming'] in alive]


def save(doc,path):
    validate(doc)
    path=Path(path).expanduser()
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(doc,indent=2,ensure_ascii=False),encoding='utf-8')
    os.replace(tmp,path)

def load(path):
    return validate(json.loads(Path(path).read_text(encoding='utf-8')))

def duration_frames(doc):
    return max((c['start']+c['duration'] for c in doc['clips'] if c.get('enabled',True)),default=0)

def editing_container(doc, container_id=None):
    """Resolve main or nested timeline, rejecting stale composition identifiers."""
    if container_id is None:
        return doc
    seq=next((item for item in doc.get('sequences',[]) if item['id']==container_id),None)
    if seq is None:raise ValueError('Editing composition does not exist')
    return seq


def split(doc,clip_id,at,container_id=None):
    """Split media or nested-clip instances at an absolute timeline frame."""
    validate(doc)
    timeline=editing_container(doc,container_id)
    c=next((x for x in timeline['clips'] if x['id']==clip_id),None)
    if c is None:raise ValueError('Clip not found')
    if next(t for t in timeline['tracks'] if t['id']==c['track'])['locked']:
        raise ValueError('Cannot split a locked clip')
    if type(at) is not int:raise ValueError('Split frame must be integer')
    local=at-c['start']
    if not 0<local<c['duration']:raise ValueError('Split outside clip')
    other=copy.deepcopy(c)
    other['id']=identifier()
    other['start']=at
    other['source_in']+=local
    other['duration']-=local
    c['duration']=local
    for property_name,keys in c.get('keyframes',{}).items():
        original=copy.deepcopy(keys)
        left=[k for k in original if k['frame']<local]
        right=[dict(k,frame=k['frame']-local) for k in original if k['frame']>=local]
        # Reproduce the value at the new clip boundary in both halves.
        boundary=value_at(dict(c,keyframes={property_name:original}),property_name,local)
        if not any(k['frame']==0 for k in right):right.insert(0,dict(frame=0,value=boundary,interpolation='linear'))
        # Preserve interpolation into the split: the next source keyframe
        # may live beyond the left clip's boundary.
        if left and left[-1]['frame']<local-1:
            left.append(dict(frame=local-1,
                             value=value_at(dict(c,keyframes={property_name:original}),property_name,local-1),
                             interpolation='linear'))
        c['keyframes'][property_name]=left
        other['keyframes'][property_name]=right
    # Splitting either endpoint invalidates a transition tied to that clip.
    timeline['transitions']=[t for t in timeline.get('transitions',[])
                              if clip_id not in (t['outgoing'],t['incoming'])]
    for effect_index,fx in enumerate(c.get('effects', [])):
        original_fx_keys=copy.deepcopy(fx.get('keyframes', {}))
        for param, keys in original_fx_keys.items():
            left=[k for k in keys if k['frame']<local]
            right=[dict(k,frame=k['frame']-local) for k in keys if k['frame']>=local]
            from .effects import effect_value_at
            boundary=effect_value_at(fx,param,local)
            if not any(k['frame']==0 for k in right):
                right.insert(0,{'frame':0,'value':boundary,'interpolation':'linear'})
            if left and max(k['frame'] for k in left)<local-1:
                left.append({'frame':local-1,'value':effect_value_at(fx,param,local-1),'interpolation':'linear'})
            c['effects'][effect_index].setdefault('keyframes',{})[param]=left
            other['effects'][effect_index].setdefault('keyframes',{})[param]=right
    timeline['clips'].append(other)
    validate(doc)
    return other


def duplicate_clip(doc, clip_id, container_id=None):
    """Duplicate a clip immediately after its end, retaining effects/keyframes."""
    validate(doc)
    timeline=editing_container(doc,container_id)
    source=next((clip for clip in timeline['clips'] if clip['id']==clip_id),None)
    if source is None:raise ValueError('Clip not found')
    if next(t for t in timeline['tracks'] if t['id']==source['track'])['locked']:
        raise ValueError('Cannot duplicate a locked clip')
    duplicate=copy.deepcopy(source)
    duplicate['id']=identifier()
    duplicate['start']=source['start']+source['duration']
    timeline['clips'].append(duplicate)
    validate(doc)
    return duplicate


def ripple_delete(doc, clip_id, container_id=None):
    """Delete one clip and shift later clips on its unlocked track left.

    Does not affect other tracks; refuses ambiguous overlapping edits.
    """
    validate(doc)
    timeline=editing_container(doc,container_id)
    source=next((clip for clip in timeline['clips'] if clip['id']==clip_id),None)
    if source is None:raise ValueError('Clip not found')
    if next(t for t in timeline['tracks'] if t['id']==source['track'])['locked']:
        raise ValueError('Cannot ripple-delete a locked clip')
    end=source['start']+source['duration']
    for other in timeline['clips']:
        if other['id']!=source['id'] and other['track']==source['track'] and other['start']<end and other['start']+other['duration']>source['start']:
            raise ValueError('Cannot ripple-delete an overlapping region')
    timeline['clips']=[c for c in timeline['clips'] if c['id']!=source['id']]
    prune_transitions(timeline)
    # Frame-shifting a clip invalidates transitions tied to its old boundaries.
    moved={c['id'] for c in timeline['clips'] if c['track']==source['track'] and c['start']>=end}
    timeline['transitions']=[t for t in timeline.get('transitions',[])
                              if not moved.intersection((t['incoming'],t['outgoing']))]
    for c in timeline['clips']:
        if c['track']==source['track'] and c['start']>=end:
            c['start']-=source['duration']
    validate(doc)
    return source


def nest_clips(doc,clip_ids,name='Nested composition',container_id=None):
    """Create a real referenced precomposition, reversible by project undo.

    Sequences preserve track structure, offsets and original clip IDs. A nested
    sequence is instantiated once per media kind, so picture and audio stay
    separate and individually routable in the parent timeline.
    """
    validate(doc)
    if container_id:
        parent=next((s for s in doc.get('sequences',[]) if s['id']==container_id),None)
        if parent is None:raise ValueError('Parent sequence not found')
    else: parent=doc
    wanted=set(clip_ids)
    originals=[c for c in parent['clips'] if c['id'] in wanted]
    if not wanted or len(originals)!=len(wanted):raise ValueError('Select existing clips to nest')
    parent_tracks={t['id']:t for t in parent['tracks']}
    if any(parent_tracks[c['track']]['locked'] for c in originals):raise ValueError('Cannot nest locked tracks')
    first=min(c['start'] for c in originals)
    finish=max(c['start']+c['duration'] for c in originals)
    seq_id=identifier()
    seq={'id':seq_id,'name':name.strip()[:200] or 'Nested composition',
         'duration':finish-first,'tracks':copy.deepcopy(parent['tracks']),
         'clips':[dict(copy.deepcopy(c),start=c['start']-first) for c in originals],
         'captions':[],
         'transitions':[dict(copy.deepcopy(t),start=t['start']-first)
                        for t in parent.get('transitions',[])
                        if t['incoming'] in wanted and t['outgoing'] in wanted],
         'playhead':0}
    used_kinds={parent_tracks[c['track']]['kind'] for c in originals}
    inserted=[]
    for kind in ('video','audio'):
        if kind not in used_kinds:continue
        possible=[t['id'] for t in parent['tracks'] if t['kind']==kind and
                  any(c['track']==t['id'] for c in originals)]
        track_id=possible[0]
        inserted.append({'id':identifier(),'sequence_id':seq_id,'track':track_id,
                         'start':first,'source_in':0,'duration':finish-first,
                         'properties':copy.deepcopy(DEFAULTS),'keyframes':{},'effects':[],'masks':[],'enabled':True})
    parent['clips']=[c for c in parent['clips'] if c['id'] not in wanted]+inserted
    prune_transitions(parent)
    doc.setdefault('sequences',[]).append(seq)
    validate(doc)
    return seq,inserted
