"""Optional native CPU compositor (v0.7 experimental).

FFmpeg remains the media decoder/effects processor and encoder; the shared
C++ compositor owns the final RGBA layer composition for both stills and video.
No GPU/real-time guarantees. Legacy FFmpeg export remains available.
"""
from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .effects import filters_for
from .after_effects_fx import COMPOSITE_TYPES
from .model import duration_frames, validate, value_at
from .render import RenderError, materialize_nested, numeric, seconds

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
LIBRARY_NAMES = {
    'win32': ('meridian_compositor.dll',),
    'darwin': ('libmeridian_compositor.dylib',),
}


def library_path():
    names = LIBRARY_NAMES.get(sys.platform, ('libmeridian_compositor.so',))
    for directory in (ROOT / 'native' / 'bin', ROOT / 'native' / 'build', ROOT / 'native' / 'build' / 'Release'):
        for name in names:
            path = directory / name
            if path.is_file():
                return path
    return None


def native_available():
    path = library_path()
    if not path or shutil.which('ffmpeg') is None:
        return False
    try:
        library = ctypes.CDLL(str(path))
        library.meridian_api_version.restype = ctypes.c_int
        return library.meridian_api_version() == 2
    except (OSError, AttributeError):
        return False


class NativeCompositor:
    """Minimal, versioned C ABI bridge. The core never allocates Python buffers."""
    def __init__(self):
        path = library_path()
        if not path:
            raise RenderError('Native compositor not compiled. Run build-native.sh or build-native-windows.bat.')
        self.lib = ctypes.CDLL(str(path))
        ptr = ctypes.POINTER(ctypes.c_uint8)
        self.lib.meridian_clear.argtypes = [ptr, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.lib.meridian_clear.restype = ctypes.c_int
        self.lib.meridian_over.argtypes = [ptr, ctypes.c_int, ctypes.c_int, ptr, ctypes.c_int,
                                           ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                           ctypes.c_float, ctypes.c_int, ctypes.c_float]
        self.lib.meridian_over.restype = ctypes.c_int
        self.lib.meridian_over_affine.argtypes = [ptr, ctypes.c_int, ctypes.c_int, ptr,
                                                  ctypes.c_int, ctypes.c_int, ctypes.c_float,
                                                  ctypes.c_float, ctypes.c_float, ctypes.c_float,
                                                  ctypes.c_float, ctypes.c_int, ctypes.c_float]
        self.lib.meridian_over_affine.restype = ctypes.c_int
        self.lib.meridian_api_version.restype = ctypes.c_int
        if self.lib.meridian_api_version() != 2:
            raise RenderError('Unsupported native compositor ABI version')

    def clear(self, width, height, transparent=False):
        frame = (ctypes.c_uint8 * (width * height * 4))()
        if self.lib.meridian_clear(frame, width, height, int(transparent)):
            raise RenderError('Invalid output image size')
        return frame

    def over(self, destination, width, height, source, sw, sh, x, y, opacity=1.,
             transition=0, progress=1.):
        buffer = (ctypes.c_uint8 * len(source)).from_buffer_copy(source)
        result = self.lib.meridian_over(destination, width, height, buffer, sw, sh,
                                        x, y, float(opacity), transition, float(progress))
        if result:
            raise RenderError('Native compositor rejected a layer')

    def over_affine(self, destination, width, height, source, sw, sh, cx, cy,
                    scale, angle, opacity=1., transition=0, progress=1.):
        buffer = (ctypes.c_uint8 * len(source)).from_buffer_copy(source)
        result = self.lib.meridian_over_affine(destination, width, height, buffer, sw, sh,
                                               float(cx), float(cy), float(scale),
                                               float(angle), float(opacity), transition,
                                               float(progress))
        if result:
            raise RenderError('Native affine compositor rejected a layer')


def _slide_x(clip, relative_frame):
    offset = 0.
    for instance in clip.get('effects', []):
        if not instance['enabled'] or instance['type'] not in ('slide_in', 'slide_out'):
            continue
        count = min(clip['duration'], int(instance['params']['frames']))
        distance = instance['params']['distance']
        if instance['type'] == 'slide_in':
            offset -= distance * (1 - min(1., relative_frame / max(1, count - 1)))
        else:
            start = max(0, clip['duration'] - count)
            offset += distance * min(1., max(0., (relative_frame - start) / max(1, count - 1)))
    return offset


class ClipDecoder:
    """Sequential RGBA decoder. Only active clips are opened during streaming.

    This reference implementation seeks to the source in-point when opened,
    then decodes forward. Random access can require decoding many frames.
    """
    def __init__(self, clip, media, fps, width, height, seek_offset=0):
        self.clip = clip
        self.width = width
        self.height = height
        self.frame_bytes = self.width * self.height * 4
        self.pos = seek_offset - 1
        self.last = None
        p = clip['properties']
        video_fx = filters_for(clip, fps, 'video')
        graph = [f'fps={fps}',
                 f'scale={width}:{height}:force_original_aspect_ratio=decrease',
                 f'pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black@0',
                 'format=rgba',
                 f'eq=brightness={numeric(p["brightness"])}:contrast={numeric(p["contrast"])}:saturation={numeric(p["saturation"])}',
                 'format=rgba']
        if p.get('blur', 0) > 0:
            graph.append(f'gblur=sigma={numeric(max(.1, min(15, p["blur"]))) }')
        graph += video_fx
        graph += ['format=rgba']
        # stderr file avoids filling OS stderr pipes under prolonged decoding.
        self.err = tempfile.TemporaryFile()
        cmd = ['ffmpeg', '-hide_banner', '-nostdin', '-loglevel', 'error',
               '-ss', seconds(clip['source_in'] + seek_offset, fps), '-i', media['path'],
               '-an', '-sn', '-vf', ','.join(graph),
               '-frames:v', str(clip['duration'] - seek_offset), '-f', 'rawvideo', '-pix_fmt', 'rgba', 'pipe:1']
        self.process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=self.err)

    def read(self, index):
        if index < self.pos:
            raise RenderError('Native decoder cannot seek backward')
        while self.pos < index:
            data = self.process.stdout.read(self.frame_bytes)
            if len(data) != self.frame_bytes:
                self.process.wait(timeout=15)
                self.err.seek(0)
                detail = self.err.read().decode(errors='replace')[-1400:]
                raise RenderError('FFmpeg frame decoder failed: ' + detail)
            self.last = data
            self.pos += 1
        return self.last

    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
        if self.process.stdout:
            self.process.stdout.close()
        try:
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()
        self.err.close()


class NativeTimeline:
    def __init__(self, doc):
        validate(doc)
        if any(c.get('masks') for c in doc['clips']):
            raise RenderError('Layer masks require FFmpeg Stable; native CPU mask processing is pending')
        if any(fx['enabled'] and fx['type'] in COMPOSITE_TYPES
               for c in doc['clips'] for fx in c.get('effects', [])):
            raise RenderError('Glow and Drop Shadow require FFmpeg Stable; native CPU composition is pending')
        self.doc = doc
        self.core = NativeCompositor()
        self.assets = {m['id']: m for m in doc['media']}
        self.tracks = {t['id']: t for t in doc['tracks']}
        self.ordered_tracks = [t['id'] for t in reversed(doc['tracks']) if t['kind'] == 'video' and not t['muted']]
        self.clips = [c for tid in self.ordered_tracks for c in sorted(
            (c for c in doc['clips'] if c['track'] == tid and c.get('enabled', True)
             and self.assets[c['asset']]['video']), key=lambda c: (c['start'], c['id']))]
        # Fail loudly instead of silently rendering unknown mask transitions.
        unknown=[t['type'] for t in doc.get('transitions', [])
                 if t['type'] not in ('cross_dissolve','wipe_left','audio_crossfade')]
        if unknown:
            raise ValueError('Extended transitions require FFmpeg Stable: ' + ', '.join(sorted(set(unknown))))
        self.transitions = {t['incoming']: t for t in doc.get('transitions', [])
                            if t['type'] in ('cross_dissolve', 'wipe_left')}
        self.decoders = {}

    def close(self):
        for decoder in self.decoders.values():
            decoder.close()
        self.decoders.clear()

    def __enter__(self): return self
    def __exit__(self, *_): self.close()

    def frame(self, index, transparent=False):
        if type(index) is not int or not 0 <= index < duration_frames(self.doc):
            raise RenderError('Frame outside sequence')
        width, height, fps = self.doc['width'], self.doc['height'], self.doc['fps']
        result = self.core.clear(width, height, transparent)
        active = set()
        for clip in self.clips:
            relative = index - clip['start']
            if not 0 <= relative < clip['duration']:
                continue
            cid = clip['id']
            active.add(cid)
            if cid not in self.decoders:
                self.decoders[cid] = ClipDecoder(clip, self.assets[clip['asset']], fps, width, height, relative)
            decoder = self.decoders[cid]
            rgba = decoder.read(relative)
            x = width / 2 + value_at(clip, 'x', relative) + _slide_x(clip, relative)
            y = height / 2 + value_at(clip, 'y', relative)
            transition, progress = 0, 1.
            incoming = self.transitions.get(cid)
            if incoming and incoming['start'] <= index < incoming['start'] + incoming['duration']:
                transition = 1 if incoming['type'] == 'cross_dissolve' else 2
                progress = (index - incoming['start']) / max(1, incoming['duration'] - 1)
            self.core.over_affine(result, width, height, rgba, decoder.width, decoder.height,
                                  x, y, value_at(clip, 'scale', relative),
                                  value_at(clip, 'rotation', relative),
                                  value_at(clip, 'opacity', relative), transition, progress)
        for old in tuple(self.decoders):
            if old not in active:
                self.decoders.pop(old).close()
        return bytes(result)


def _png_from_rgba(pixels, width, height):
    cp = subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error',
                         '-f', 'rawvideo', '-pixel_format', 'rgba', '-video_size', f'{width}x{height}',
                         '-i', 'pipe:0', '-frames:v', '1', '-c:v', 'png', '-f', 'image2pipe', 'pipe:1'],
                        input=pixels, capture_output=True)
    if cp.returncode:
        raise RenderError('PNG encoding failed: ' + cp.stderr.decode(errors='replace')[-1000:])
    return cp.stdout


def native_frame(doc, frame_index):
    validate(doc)
    with tempfile.TemporaryDirectory(prefix='meridian-native-frame-') as tmp:
        flat = materialize_nested(doc, tmp, 'draft') if doc.get('sequences') else doc
        with NativeTimeline(flat) as timeline:
            pixels = timeline.frame(frame_index)
        return _png_from_rgba(pixels, flat['width'], flat['height'])


def _native_audio(doc, target):
    """Audio-only graph, deliberately reusing validated filter definitions."""
    fps = doc['fps']
    assets = {m['id']: m for m in doc['media']}
    tracks = {t['id']: t for t in doc['tracks']}
    clips = [c for c in doc['clips'] if c.get('enabled', True) and
             tracks[c['track']]['kind'] == 'audio' and not tracks[c['track']]['muted'] and
             assets[c['asset']]['audio']]
    if not clips: return False
    cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y']
    source_index = {}
    for asset in doc['media']:
        if any(c['asset'] == asset['id'] for c in clips):
            source_index[asset['id']] = len(source_index)
            cmd.extend(['-i', asset['path']])
    filters = []
    transitions = {}
    for t in doc.get('transitions', []):
        if t['type'] == 'audio_crossfade':
            transitions.setdefault(t['outgoing'], []).append(('out', t))
            transitions.setdefault(t['incoming'], []).append(('in', t))
    for i, clip in enumerate(clips):
        effect_filters = filters_for(clip, fps, 'audio')
        for direction, t in transitions.get(clip['id'], []):
            effect_filters.append(f'afade=t={direction}:st={seconds(t["start"]-clip["start"],fps)}:'
                                  f'd={seconds(t["duration"],fps)}')
        effects = ','.join(effect_filters)
        if effects: effects += ','
        filters.append(f'[{source_index[clip["asset"]]}:a:0]'
                       f'atrim=start={seconds(clip["source_in"],fps)}:'
                       f'duration={seconds(clip["duration"],fps)},'
                       f'asetpts=PTS-STARTPTS,aresample=48000,'
                       f'volume={numeric(max(0.,min(4.,clip["properties"]["volume"])))},'
                       f'{effects}atrim=duration={seconds(clip["duration"],fps)},'
                       f'asetpts=PTS-STARTPTS,adelay={int(clip["start"]*1000/fps)}:all=1[a{i}]')
    filters.append(''.join(f'[a{i}]' for i in range(len(clips))) +
                   f'amix=inputs={len(clips)}:duration=longest:normalize=0:dropout_transition=0,'
                   f'atrim=duration={seconds(duration_frames(doc),fps)},aresample=48000[outa]')
    cmd.extend(['-filter_complex', ';'.join(filters), '-map', '[outa]', '-vn',
                '-c:a', 'aac', '-b:a', '192k', str(target)])
    cp = subprocess.run(cmd, capture_output=True)
    if cp.returncode:
        raise RenderError('Native export audio failed: ' + cp.stderr.decode(errors='replace')[-2000:])
    return True


def native_export(doc, target, preset='high', burn_captions=False, hardware_encoder=None):
    validate(doc)
    if burn_captions and doc.get('captions'):
        raise RenderError('Native captions burn-in is not yet supported. Select FFmpeg (stable) for captions.')
    if hardware_encoder is not None:
        from .hardware import available_h264_encoder
        if hardware_encoder != available_h264_encoder():
            raise RenderError('Hardware H.264 encoder is not available on this machine')
    if preset not in ('high', 'draft'):
        raise RenderError('Invalid preset')
    with tempfile.TemporaryDirectory(prefix='meridian-native-export-') as tmp:
        flat = materialize_nested(doc, tmp, preset) if doc.get('sequences') else doc
        length = duration_frames(flat)
        if not length: raise RenderError('Empty sequence')
        w, h, fps = flat['width'], flat['height'], flat['fps']
        video = Path(tmp) / 'silent.mp4'
        args = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'rawvideo',
                '-pixel_format', 'rgba', '-video_size', f'{w}x{h}', '-framerate', str(fps),
                '-i', 'pipe:0', '-an']
        if hardware_encoder:
            # Only the H.264 encoder uses hardware. C++ composition stays CPU.
            args += ['-c:v', hardware_encoder, '-b:v', '12M' if preset == 'high' else '6M']
        else:
            args += ['-c:v', 'libx264', '-preset', 'medium' if preset == 'high' else 'veryfast',
                     '-crf', '18' if preset == 'high' else '25']
        args += ['-pix_fmt', 'yuv420p', '-frames:v', str(length), str(video)]
        # Avoid stderr deadlocks and pipe leaks on encoder errors.
        with tempfile.TemporaryFile() as error_log:
            encoder = subprocess.Popen(args, stdin=subprocess.PIPE, stderr=error_log)
            try:
                with NativeTimeline(flat) as timeline:
                    for index in range(length):
                        encoder.stdin.write(timeline.frame(index))
                encoder.stdin.close()
                if encoder.wait(timeout=90) != 0:
                    error_log.seek(0)
                    raise RenderError('Video encoding failed: ' + error_log.read().decode(errors='replace')[-2000:])
            except Exception:
                if encoder.poll() is None: encoder.kill()
                if encoder.stdin and not encoder.stdin.closed: encoder.stdin.close()
                encoder.wait()
                raise
        audio = Path(tmp) / 'audio.m4a'
        if _native_audio(flat, audio):
            cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(video),
                   '-i', str(audio), '-map', '0:v:0', '-map', '1:a:0',
                   '-c', 'copy', '-movflags', '+faststart', str(target)]
            cp = subprocess.run(cmd, capture_output=True)
            if cp.returncode:
                raise RenderError('Audio/video mux failed: ' + cp.stderr.decode(errors='replace')[-1000:])
        else:
            os.replace(video, target)
    return target
