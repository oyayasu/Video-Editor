"""Windows desktop host (Qt WebEngine) for the existing Meridian HTML UI.

All dialogs are serviced on Qt's main GUI thread. The API server is bound to
127.0.0.1 and starts on a randomly assigned port. The desktop closes the
server explicitly when the window closes.
"""
from __future__ import annotations

import queue
import threading
from dataclasses import dataclass, field

from . import server as backend


@dataclass
class DialogRequest:
    mode: str
    completed: threading.Event = field(default_factory=threading.Event)
    value: list[str] = field(default_factory=list)
    error: str | None = None


class DialogDispatcher:
    """Thread-safe request queue; `process_one` must be called on GUI thread."""

    def __init__(self):
        self.pending: queue.Queue[DialogRequest] = queue.Queue()
        self.closed = False

    def request(self, mode: str) -> list[str]:
        if self.closed:
            raise RuntimeError('Desktop window is closing')
        if mode not in ('media', 'project-open', 'project-save', 'export'):
            raise ValueError('Unsupported dialog request')
        item = DialogRequest(mode)
        self.pending.put(item)
        if not item.completed.wait(180):
            raise TimeoutError('File dialog was not answered in time')
        if item.error:
            raise RuntimeError(item.error)
        return item.value

    def process_one(self, picker):
        try:
            item = self.pending.get_nowait()
        except queue.Empty:
            return False
        try:
            if self.closed:
                raise RuntimeError('Desktop window is closing')
            item.value = picker(item.mode)
        except Exception as exc:
            item.error = str(exc)
        finally:
            item.completed.set()
        return True

    def close(self):
        self.closed = True
        while True:
            try:
                item = self.pending.get_nowait()
            except queue.Empty:
                break
            item.error = 'Desktop window was closed'
            item.completed.set()


def run_desktop() -> int:
    # Imported here so backend unit tests never require PySide6.
    from PySide6.QtCore import QTimer, QUrl
    from PySide6.QtGui import QDesktopServices
    from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWebEngineCore import QWebEnginePage

    app = QApplication([])
    app.setApplicationName('Meridian Editor')
    app.setOrganizationName('Meridian')
    dispatcher = DialogDispatcher()

    def show_picker(mode):
        if mode == 'media':
            paths, _ = QFileDialog.getOpenFileNames(
                None, 'Import media', '', 'Media files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.mp3 *.wav *.flac *.aac *.png *.jpg *.jpeg *.webp);;All files (*)')
            return paths
        if mode == 'project-open':
            path, _ = QFileDialog.getOpenFileName(None, 'Open Meridian project', '', 'Meridian Project (*.meridian);;All files (*)')
        elif mode == 'project-save':
            path, _ = QFileDialog.getSaveFileName(None, 'Save Meridian project', '', 'Meridian Project (*.meridian)')
            if path and not path.lower().endswith('.meridian'):
                path += '.meridian'
        else:
            path, _ = QFileDialog.getSaveFileName(None, 'Export video', '', 'MP4 Video (*.mp4)')
            if path and not path.lower().endswith('.mp4'):
                path += '.mp4'
        return [path] if path else []

    backend.DESKTOP_DIALOG_PROVIDER = dispatcher.request
    httpd = backend.make_server()
    thread = threading.Thread(target=httpd.serve_forever, name='meridian-http', daemon=True)
    thread.start()

    local_port = httpd.server_address[1]

    class RestrictedPage(QWebEnginePage):
        """Only this editor's loopback origin may own the main desktop view."""
        def acceptNavigationRequest(self, url, nav_type, is_main_frame):
            if is_main_frame and url.scheme() != 'about':
                local = (url.scheme() == 'http' and
                         url.host().lower() in ('localhost', '127.0.0.1') and
                         url.port() == local_port)
                if not local:
                    if nav_type == QWebEnginePage.NavigationType.NavigationTypeLinkClicked and url.scheme() == 'https':
                        QDesktopServices.openUrl(url)
                    return False
            return super().acceptNavigationRequest(url, nav_type, is_main_frame)

    window = QMainWindow()
    window.setWindowTitle('Meridian Editor — Preview')
    window.resize(1500, 920)
    window.setMinimumSize(900, 600)
    view = QWebEngineView(window)
    page = RestrictedPage(view)
    def external_window(request):
        link = request.requestedUrl()
        if link.scheme() == 'https':
            QDesktopServices.openUrl(link)
    page.newWindowRequested.connect(external_window)
    view.setPage(page)
    window.setCentralWidget(view)
    url = f'http://127.0.0.1:{httpd.server_address[1]}/'
    view.setUrl(QUrl(url))
    timer = QTimer()
    timer.setInterval(40)
    timer.timeout.connect(lambda: dispatcher.process_one(show_picker))
    timer.start()
    window.show()

    try:
        return app.exec()
    finally:
        timer.stop()
        dispatcher.close()
        backend.DESKTOP_DIALOG_PROVIDER = None
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=3)
