"""Deterministic, subprocess-safe FFmpeg export adapter (temporary until MLT engine)."""
from __future__ import annotations
import copy
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from .captions import subtitles_to_text
from .model import validate, duration_frames
from .effects import filters_for, horizontal_animation_expression
from .masks import mask_filter
from .after_effects_fx import COMPOSITE_TYPES, append_composite_graph

class RenderError(RuntimeError): pass

def seconds(frames, fps):return format(frames/fps,'.8f').rstrip('0').rstrip('.') or '0'
def numeric(v):return format(float(v),'.6f').rstrip('0').rstrip('.') or '0'

def curve_expression(clip, key, fps):
    """FFmpeg overlay x/y expression, t is seconds on output timeline."""
    k=sorted(clip.get('keyframes',{}).get(key,[]),key=lambda a:a['frame'])
    if not k:return numeric(clip['properties'][key])
    def when(frame):return numeric((clip['start']+frame)/fps)
    expr=numeric(k[-1]['value'])
    for a,b in reversed(list(zip(k,k[1:]))):
        start=when(a['frame']);end=when(b['frame'])
        if a.get('interpolation')=='hold':interp=numeric(a['value'])
        else:
            p=f'((t-{start})/({end}-{start}))'
            if a.get('interpolation')=='ease':p=f'({p}*{p}*(3-2*{p}))'
            interp=f'({numeric(a["value"])}+({numeric(b["value"])}-{numeric(a["value"] )})*{p})'
        expr=f'if(lt(t,{end}),{interp},{expr})'
    return f'if(lt(t,{when(k[0]["frame"])}),{numeric(k[0]["value"])},{expr})'

def make_command(doc, target, preset='high', subtitle_path=None, transparent=False, frame_index=None):
    validate(doc)
    if not shutil.which('ffmpeg'):raise RenderError('FFmpeg not installed / not in PATH')
    length=duration_frames(doc)
    if length==0:raise RenderError('Timeline is empty')
    fps=doc['fps']; width=doc['width'];height=doc['height']
    if frame_index is not None and (type(frame_index) is not int or not 0<=frame_index<length):
        raise RenderError('Preview frame is outside the sequence')
    incoming={t['incoming']:t for t in doc.get('transitions',[]) if t['type'] != 'audio_crossfade'}
    audio_transitions={}
    for transition in doc.get('transitions',[]):
        if transition['type']=='audio_crossfade':
            audio_transitions.setdefault(transition['outgoing'],[]).append(('out',transition))
            audio_transitions.setdefault(transition['incoming'],[]).append(('in',transition))

    assets={m['id']:m for m in doc['media']}
    tracks={t['id']:t for t in doc['tracks']}
    ordered=[t['id'] for t in reversed(doc['tracks']) if t['kind']=='video']
    clips=[c for c in doc['clips'] if c.get('enabled',True) and not tracks[c['track']]['muted']]
    # Inputs are shared per asset; avoids loading a file many times.
    used={c['asset'] for c in clips};sources={}
    cmd=['ffmpeg','-hide_banner','-y']
    for asset in doc['media']:
        if asset['id'] in used:
            if not os.path.isfile(asset['path']):raise RenderError('Source file missing: '+asset['path'])
            sources[asset['id']]=len(sources)
            # FFmpeg can loop still images into frame-accurate title layers.
            if Path(asset['path']).suffix.lower() in ('.png','.jpg','.jpeg','.webp'):
                cmd.extend(['-loop','1','-framerate',str(fps)])
            cmd.extend(['-i',asset['path']])
    duration=seconds(length,fps)
    filters=[f'color=c={"black@0" if transparent else "black"}:s={width}x{height}:r={fps}:d={duration},format={"rgba" if transparent else "yuv420p"}[canvas]']
    current='canvas';n=0
    for tid in ordered:
        for c in sorted((c for c in clips if c['track']==tid),key=lambda x:(x['start'],x['id'])):
            asset=assets[c['asset']]
            if not asset['video']:continue
            idx=sources[c['asset']];tag=f'layer{n}'
            p=c['properties'];scale=max(.01,min(float(p['scale']),10))
            w=max(2,int(width*scale)//2*2);h=max(2,int(height*scale)//2*2)
            initial=f'clip{n}source'
            # Transform-source normalization precedes the ordered effect stack.
            prep=(f'[{idx}:v:0]trim=start={seconds(c["source_in"],fps)}:duration={seconds(c["duration"],fps)},'
                  f'setpts=PTS-STARTPTS,fps={fps},scale={width}:{height}:force_original_aspect_ratio=decrease,'
                  f'pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black@0,format=rgba,'
                  f'scale={w}:{h},eq=brightness={numeric(p["brightness"])}:contrast={numeric(p["contrast"])}:'
                  f'saturation={numeric(p["saturation"])},format=rgba'
                  + (f',gblur=sigma={numeric(max(0.1,min(15,p.get("blur",0))))}' if p.get('blur',0)>0 else '')
                  + f'[{initial}]')
            filters.append(prep)
            # Apply *all* effects in stack order; branching effects have named
            # streams while regular effects are single-input linear filters.
            source=initial
            for j,instance in enumerate(c.get('effects',[])):
                if not instance['enabled'] or instance['type'] in ('slide_in','slide_out'):
                    continue
                stage=f'clip{n}fx{j}'
                if instance['type'] in COMPOSITE_TYPES:
                    source=append_composite_graph(instance,source,f'clip{n}g{j}',stage,filters)
                else:
                    one_effect={**c,'effects':[instance]}
                    chain=filters_for(one_effect,fps,'video')
                    if chain:
                        filters.append(f'[{source}]{",".join(chain)},format=rgba[{stage}]')
                        source=stage
            prep=f'[{source}]'
            if mask_filter(c):prep+=mask_filter(c)+','
            prep+=(f'rotate=a={numeric(p["rotation"])}*PI/180:c=none:ow=iw:oh=ih,format=rgba,'
                   f'colorchannelmixer=aa={numeric(max(0,min(1,p["opacity"])))},')
            transition=incoming.get(c['id'])
            if transition:
                relative=transition['start']-c['start']
                length_frames=transition['duration']
                if transition['type']=='cross_dissolve':
                    prep+=f'fade=t=in:st={seconds(relative,fps)}:n={max(1,length_frames-1)}:alpha=1,'
                else:
                    # Geometric alpha reveal. A transition belongs to the incoming clip,
                    # while the outgoing clip continues below it through the overlap.
                    end=max(1,length_frames-1)/fps
                    start=relative/fps
                    prog=f'min(1,max(0,(T-{numeric(start)})/{numeric(end)}))'
                    transition_type=transition['type']
                    geometry={
                        'wipe_left':'X/W', 'wipe_right':'1-X/W',
                        'wipe_up':'Y/H', 'wipe_down':'1-Y/H',
                        'soft_wipe_left':'X/W', 'soft_wipe_right':'1-X/W',
                        'soft_wipe_up':'Y/H', 'soft_wipe_down':'1-Y/H',
                        'diagonal_tl':'(X/W+Y/H)/2',
                        'diagonal_br':'(2-X/W-Y/H)/2',
                        'circle_reveal':'sqrt(pow((X/W-.5)*2,2)+pow((Y/H-.5)*2,2))/1.41421356',
                    }
                    axis=geometry[transition_type]
                    if transition_type.startswith('soft_'):
                        mask=f'255*min(1,max(0,({prog}-{axis})*12+.5))'
                    else:
                        mask=f'if(lte({axis},{prog}),255,0)'
                    prep+=f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='{mask}',format=rgba,"
            prep+=f'setpts=PTS+{seconds(c["start"],fps)}/TB[{tag}]'
            filters.append(prep)
            x=curve_expression(c,'x',fps);y=curve_expression(c,'y',fps)
            x=f'(W-w)/2+({x})+({horizontal_animation_expression(c,fps)})';y=f'(H-h)/2+({y})'
            nxt=f'base{n}'
            filters.append(f'[{current}][{tag}]overlay=x=\'{x}\':y=\'{y}\':eval=frame:'
                           f'format=auto:eof_action=pass:repeatlast=0:shortest=0:'
                           f'enable=\'between(t,{seconds(c["start"],fps)},{seconds(c["start"]+c["duration"]-1,fps)})\'[{nxt}]')
            current=nxt;n+=1
    if subtitle_path and doc.get('captions'):
        # FFmpeg filters parse path separators and colons specially. This is
        # validated on Linux; Windows paths require further native testing.
        source=os.fspath(subtitle_path).replace('\\','/').replace(':',r'\:').replace("'",r"\'")
        filters.append(f"[{current}]subtitles=filename='{source}':charenc=UTF-8[subtitled]")
        current='subtitled'
    if frame_index is not None:
        filters.append(f'[{current}]select=eq(n\\,{frame_index}),setpts=PTS-STARTPTS,format=rgb24[outv]')
    else:
        filters.append(f'[{current}]format={"yuva444p10le" if transparent else "yuv420p"}[outv]')
    audio=[]
    for i,c in enumerate(clips if frame_index is None else []):
        asset=assets[c['asset']]
        if tracks[c['track']]['kind']!='audio' or not asset['audio']:continue
        idx=sources[c['asset']];tag=f'aud{i}'
        vol=max(0,min(4,float(c['properties']['volume'])))
        audio_fx=filters_for(c,fps,'audio')
        for direction,transition in audio_transitions.get(c['id'],[]):
            at=seconds(transition['start']-c['start'],fps)
            fade_duration=seconds(transition['duration'],fps)
            audio_fx.append(f'afade=t={direction}:st={at}:d={fade_duration}')
        filters.append(f'[{idx}:a:0]atrim=start={seconds(c["source_in"],fps)}:duration={seconds(c["duration"],fps)},'
                       f'asetpts=PTS-STARTPTS,aresample=48000,volume={numeric(vol)},'
                       + (','.join(audio_fx)+',' if audio_fx else '')
                       + f'atrim=duration={seconds(c["duration"],fps)},asetpts=PTS-STARTPTS,'
                       f'adelay={int(c["start"]*1000/fps)}:all=1[{tag}]')
        audio.append(tag)
    if audio:
        filters.append(''.join(f'[{a}]' for a in audio)+
                       f'amix=inputs={len(audio)}:duration=longest:dropout_transition=0:normalize=0,'
                       f'atrim=duration={duration},aresample=48000[outa]')
    cmd.extend(['-filter_complex',';'.join(filters),'-map','[outv]'])
    if audio:cmd.extend(['-map','[outa]','-c:a','aac','-b:a','192k'])
    else:cmd.append('-an')
    if frame_index is not None:
        cmd.extend(['-an','-c:v','png','-frames:v','1','-update','1',os.fspath(target)])
    elif transparent:
        # Preserve precomposition alpha for overlaying on tracks below.
        cmd.extend(['-c:v','prores_ks','-profile:v','4','-pix_fmt','yuva444p10le','-r',str(fps),
                    '-frames:v',str(length),os.fspath(target)])
    else:
        cmd.extend(['-c:v','libx264','-preset',('medium' if preset=='high' else 'veryfast'),
                    '-crf',('18' if preset=='high' else '25'),'-pix_fmt','yuv420p','-r',str(fps),
                    '-frames:v',str(length),'-movflags','+faststart',os.fspath(target)])
    return cmd

def materialize_nested(doc,temp_dir,preset='high'):
    """Recursively render child sequences to temporary media before parent export.

    No intermediate is added to the user's source folder; child edits are
    re-evaluated on every export. The UI is not yet a fully shared render engine.
    """
    validate(doc)
    sequences={s['id']:s for s in doc.get('sequences',[])}
    cache={}
    def build_doc(clips,tracks,captions=None,transitions=None):
        result=copy.deepcopy(doc)
        result['clips']=copy.deepcopy(clips)
        result['tracks']=copy.deepcopy(tracks)
        result['captions']=copy.deepcopy(captions or [])
        result['transitions']=copy.deepcopy(transitions or [])
        result['sequences']=[]
        for c in result['clips']:
            sid=c.pop('sequence_id',None)
            if sid is None:continue
            m=render_sequence(sid)
            c['asset']=m['id']
            if not any(x['id']==m['id'] for x in result['media']):result['media'].append(m)
        validate(result)
        return result
    def render_sequence(sid):
        if sid in cache:return cache[sid]
        sequence=sequences[sid]
        child=build_doc(sequence['clips'],sequence['tracks'],sequence.get('captions'),sequence.get('transitions'))
        path=Path(temp_dir)/('nested-'+sid+'.mov')
        cp=subprocess.run(make_command(child,path,preset,transparent=True),capture_output=True,text=True)
        if cp.returncode:raise RenderError('Nested composition '+sequence['name']+' failed: '+cp.stderr[-2500:])
        audio_track_ids={t['id'] for t in child['tracks'] if t['kind']=='audio' and not t['muted']}
        audio_present=any(c['track'] in audio_track_ids and c.get('enabled',True)
                          and next((m['audio'] for m in child['media'] if m['id']==c['asset']),False)
                          for c in child['clips'])
        result={'id':'nested_'+sid,'path':str(path),'name':sequence['name'],
                'duration_seconds':duration_frames(child)/doc['fps'],
                'duration_frames':duration_frames(child),'video':True,
                'audio':audio_present,'width':doc['width'],'height':doc['height']}
        cache[sid]=result
        return result
    return build_doc(doc['clips'],doc['tracks'],doc.get('captions'),doc.get('transitions'))

def render(doc,path,preset='high',burn_captions=False):
    with tempfile.TemporaryDirectory(prefix='meridian-export-') as tmp:
        flat=materialize_nested(doc,tmp,preset) if doc.get('sequences') else doc
        subtitle_file=None
        if burn_captions and flat.get('captions'):
            subtitle_file=Path(tmp)/'subtitle.srt'
            subtitle_file.write_text(subtitles_to_text(flat['captions'],flat['fps']),encoding='utf-8')
        cmd=make_command(flat,path,preset,subtitle_path=subtitle_file)
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if cp.returncode:
            raise RenderError('FFmpeg failed (burned captions require an FFmpeg build with libass):\n'+cp.stderr[-6000:])
    return path


def render_frame(doc, frame_index, burn_captions=False):
    """Render a still through the SAME FFmpeg video graph as MP4 export.

    Designed for paused/scrubbed accuracy checks, not 30/60fps playback.
    Returns PNG bytes; temporary nested intermediate media are cleaned up.
    """
    validate(doc)
    with tempfile.TemporaryDirectory(prefix='meridian-frame-') as tmp:
        flattened=materialize_nested(doc,tmp,'draft') if doc.get('sequences') else doc
        subtitle_file=None
        if burn_captions and flattened.get('captions'):
            subtitle_file=Path(tmp)/'subtitle.srt'
            subtitle_file.write_text(subtitles_to_text(flattened['captions'],flattened['fps']),encoding='utf-8')
        result=Path(tmp)/'still.png'
        cmd=make_command(flattened,result,'draft',subtitle_file,frame_index=frame_index)
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if cp.returncode or not result.is_file():
            raise RenderError('Exact-frame rendering failed: '+cp.stderr[-3500:])
        return result.read_bytes()
