"""Layer-level geometric mattes for Effects.

Clip-local normalized coordinates keep masks portable across resolutions.
The alpha is multiplied against the incoming alpha, preserving keys, fades
and other effects.  No arbitrary user expressions reach libavfilter.
"""
from __future__ import annotations
import math
import uuid

SHAPES = ('rectangle', 'ellipse')
MODES = ('add', 'subtract', 'intersect')

def new_mask(shape='ellipse'):
    if shape not in SHAPES:
        raise ValueError('Unknown mask shape')
    return dict(id=uuid.uuid4().hex[:12], shape=shape, mode='add', enabled=True,
                invert=False, x=0.5, y=0.5, width=0.5, height=0.5,
                feather=0.02, opacity=1.0)

def validate_masks(clip, kind):
    masks = clip.get('masks', [])
    if not isinstance(masks, list) or len(masks)>16:
        raise ValueError('Invalid masks (maximum 16)')
    if masks and kind != 'video':
        raise ValueError('Masks require a video layer')
    known=set()
    required={'id','shape','mode','enabled','invert','x','y','width','height','feather','opacity'}
    for mask in masks:
        if not isinstance(mask,dict) or set(mask)!=required:
            raise ValueError('Invalid mask fields')
        if not isinstance(mask['id'],str) or not 1<=len(mask['id'])<=64 or mask['id'] in known:
            raise ValueError('Invalid or duplicated mask ID')
        known.add(mask['id'])
        if mask['shape'] not in SHAPES or mask['mode'] not in MODES:
            raise ValueError('Unknown mask shape or mode')
        if type(mask['enabled']) is not bool or type(mask['invert']) is not bool:
            raise ValueError('Invalid mask flags')
        for name in ('x','y','width','height','feather','opacity'):
            number=mask[name]
            if type(number) not in (int,float) or not math.isfinite(number):
                raise ValueError('Invalid mask number: '+name)
        if not 0<=mask['x']<=1 or not 0<=mask['y']<=1 or not 0<mask['width']<=1 or not 0<mask['height']<=1:
            raise ValueError('Mask geometry out of range')
        if not 0<=mask['feather']<=0.25 or not 0<=mask['opacity']<=1:
            raise ValueError('Mask feather/opacity out of range')

def _n(value):
    return format(float(value),'.8f').rstrip('0').rstrip('.') or '0'

def mask_filter(clip):
    """Return FFmpeg RGBA geq filter or None; shape order affects matte result.

    Combined alpha uses a *single* alpha calculation, so an existing
    chroma-key or fade channel is never discarded. Feather is approximate
    Euclidean distance for ellipses, signed box distance for rectangles.
    """
    masks=[m for m in clip.get('masks',[]) if m['enabled']]
    if not masks:return None
    mask_expr=None
    for i,m in enumerate(masks):
        cx=f'W*{_n(m["x"])}';cy=f'H*{_n(m["y"])}'
        rx=f'W*{_n(m["width"]/2)}';ry=f'H*{_n(m["height"]/2)}'
        if m['shape']=='rectangle':
            signed=f'max(abs(X-{cx})-{rx},abs(Y-{cy})-{ry})'
        else:
            signed=f'(sqrt(pow((X-{cx})/({rx}),2)+pow((Y-{cy})/({ry}),2))-1)*min({rx},{ry})'
        if m['feather']:
            softness=f'min(W,H)*{_n(m["feather"])}'
            matte=f'min(1,max(0,0.5-({signed})/({softness})))'
        else:
            matte=f'if(lte({signed},0),1,0)'
        if m['invert']:matte=f'(1-({matte}))'
        matte=f'({_n(m["opacity"])}*({matte}))'
        if mask_expr is None:
            # A lone subtract mask removes a region from the full clip.
            mask_expr=f'(1-({matte}))' if m['mode']=='subtract' else matte
        elif m['mode']=='add':mask_expr=f'max(({mask_expr}),({matte}))'
        elif m['mode']=='intersect':mask_expr=f'min(({mask_expr}),({matte}))'
        else:mask_expr=f'(({mask_expr})*(1-({matte})))'
    return "geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*("+mask_expr+")',format=rgba"
