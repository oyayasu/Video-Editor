"""Bounded frame-addressed native preview cache.

The CPU compositor is the same used by native MP4 export.  Frames are requested
by timeline index rather than delivered by a free-running MJPEG stream, letting
the audio transport clock decide which frame to display.  This is not a GPU
renderer, nor does it guarantee real-time throughput.
"""
from __future__ import annotations

import copy
import io
from collections import OrderedDict
import secrets
import subprocess
import tempfile
import threading
import time
from contextlib import ExitStack

try:
    from PIL import Image
except ImportError:
    Image = None  # Optional acceleration; FFmpeg fallback requires no extra Python package.

from .model import duration_frames, validate
from .native_render import NativeTimeline
from .render import RenderError, materialize_nested

MAX_CACHE_BYTES = 24 * 1024 * 1024
PREVIEW_WIDTH = 640
MAX_IDLE_SECONDS = 120
MAX_SEEK_DECODE_FRAMES = 12


def jpeg_frame(rgba: bytes, width: int, height: int, preview_width: int = PREVIEW_WIDTH) -> bytes:
    """Encode one native RGBA frame, retaining aspect ratio and bounding memory."""
    if not 160 <= preview_width <= 1280 or width <= 0 or height <= 0:
        raise ValueError('Invalid preview dimensions')
    if Image is not None:
        # This path removes the overhead of spawning one FFmpeg encoder per
        # frame. Only the JPEG transport changes, never compositor pixels.
        output_height = max(2, round(height * preview_width / width / 2) * 2)
        frame = Image.frombytes('RGBA', (width, height), rgba)
        frame = frame.convert('RGB').resize((preview_width, output_height), Image.Resampling.BICUBIC)
        with io.BytesIO() as buffer:
            frame.save(buffer, format='JPEG', quality=78, optimize=False)
            return buffer.getvalue()
    result = subprocess.run(
        ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-f', 'rawvideo', '-pixel_format', 'rgba', '-video_size', f'{width}x{height}',
         '-i', 'pipe:0', '-frames:v', '1', '-vf', f'scale={preview_width}:-2:flags=bicubic',
         '-c:v', 'mjpeg', '-q:v', '7', '-f', 'image2pipe', 'pipe:1'],
        input=rgba, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False)
    if result.returncode or not result.stdout.startswith(b'\xff\xd8') or not result.stdout.endswith(b'\xff\xd9'):
        raise RenderError('Native frame JPEG encoding failed: ' + result.stderr.decode(errors='replace')[-600:])
    return result.stdout


class NativeFrameCache:
    """Single-reader native decoder and a byte-limited LRU of encoded frames."""
    def __init__(self, project, *, max_bytes=MAX_CACHE_BYTES, width=PREVIEW_WIDTH):
        validate(project)
        if not 1024 <= max_bytes <= 256 * 1024 * 1024:
            raise ValueError('Invalid cache size')
        if not 160 <= width <= 1280:
            raise ValueError('Invalid preview width')
        self.project = copy.deepcopy(project)
        self.limit = max_bytes
        self.preview_width = width
        self._cached = OrderedDict()
        self._size = 0
        self._stack = None
        self._timeline = None
        self._last = -1
        self._lock = threading.RLock()
        self.closed = False
        self.hits = 0
        self.misses = 0

    def _open(self):
        self._reset()
        self._stack = ExitStack()
        try:
            tmp = self._stack.enter_context(tempfile.TemporaryDirectory(prefix='meridian-cache-'))
            doc = materialize_nested(self.project, tmp, 'draft') if self.project.get('sequences') else self.project
            self._timeline = self._stack.enter_context(NativeTimeline(doc))
            self._doc = doc
        except BaseException:
            self._reset()
            raise

    def _reset(self):
        if self._stack is not None:
            self._stack.close()
            self._stack = None
        self._timeline = None
        self._last = -1

    def get(self, frame: int):
        if type(frame) is not int or not 0 <= frame < duration_frames(self.project):
            raise ValueError('Frame outside preview timeline')
        with self._lock:
            if self.closed:
                raise ValueError('Preview session has ended')
            if frame in self._cached:
                self.hits += 1
                self._cached.move_to_end(frame)
                return self._cached[frame], True
            self.misses += 1
            # Random seeking directly to a later source time avoids decoding
            # large offscreen runs through ClipDecoder.read().
            if self._timeline is None or frame < self._last or frame - self._last > MAX_SEEK_DECODE_FRAMES:
                self._open()
            try:
                pixels = self._timeline.frame(frame)
                encoded = jpeg_frame(pixels, self._doc['width'], self._doc['height'], self.preview_width)
            except Exception:
                # Do not retain a decoder after a truncated source or broken pipe.
                # Existing cache hits remain usable while the next miss retries cleanly.
                self._reset()
                raise
            self._last = frame
            if len(encoded) <= self.limit:
                while self._cached and self._size + len(encoded) > self.limit:
                    _, evicted = self._cached.popitem(last=False)
                    self._size -= len(evicted)
                self._cached[frame] = encoded
                self._size += len(encoded)
            return encoded, False

    @property
    def cached_bytes(self):
        return self._size

    def __enter__(self): return self

    def __exit__(self, *_): self.close()

    def close(self):
        with self._lock:
            if self.closed:
                return
            self.closed = True
            self._reset()
            self._cached.clear()
            self._size = 0


class FrameSessionRegistry:
    """One session per server, with unpredictable single-project preview ticket."""
    def __init__(self, factory=NativeFrameCache, monotonic=time.monotonic):
        self._lock = threading.Lock()
        self._factory = factory
        self._clock = monotonic
        self._session = None

    def start(self, project):
        validate(project)
        # Construct outside registry lock, but don't decode until first use.
        candidate = self._factory(project)
        with self._lock:
            previous = self._session
            self._session = (secrets.token_urlsafe(32), self._clock(), candidate)
        if previous:
            previous[2].close()
        return self._session[0]

    def get(self, token, frame):
        with self._lock:
            session = self._session
            if not session or session[0] != token:
                raise KeyError('Preview session not found')
            if self._clock() - session[1] > MAX_IDLE_SECONDS:
                self._session = None
                stale = session[2]
            else:
                self._session = (session[0], self._clock(), session[2])
                stale = None
        if stale:
            stale.close()
            raise KeyError('Preview session expired')
        return session[2].get(frame)

    def stop(self):
        with self._lock:
            previous, self._session = self._session, None
        if previous:
            previous[2].close()
