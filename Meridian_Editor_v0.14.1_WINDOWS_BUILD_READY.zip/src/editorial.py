"""Frame-exact, transactional edit operations for Meridian timelines.

Edits return a *new* validated project. On failure no caller-owned data is
modified. All source bounds and locked-track checks live here, not in UI code.
"""
from __future__ import annotations

import copy
import math
from pathlib import Path

from .model import create_clip, editing_container, identifier, prune_transitions, validate, value_at
from .effects import effect_value_at


def _integer(value, label):
    if type(value) is not int:
        raise ValueError(f'{label} must be an integer frame')
    return value


def _source_limit(doc, clip):
    if clip.get('sequence_id'):
        seq = next((s for s in doc.get('sequences', []) if s['id'] == clip['sequence_id']), None)
        if seq is None:
            raise ValueError('Nested source missing')
        return seq['duration']
    media = next((m for m in doc['media'] if m['id'] == clip['asset']), None)
    if media is None:
        raise ValueError('Source missing')
    return math.ceil(float(media['duration_seconds']) * doc['fps']) + 1


def _track(timeline, clip):
    track = next((t for t in timeline['tracks'] if t['id'] == clip['track']), None)
    if track is None or track['locked']:
        raise ValueError('Cannot edit a locked or missing track')
    return track


def _selected(timeline, clip_id):
    c = next((c for c in timeline['clips'] if c['id'] == clip_id), None)
    if c is None:
        raise ValueError('Clip does not exist')
    _track(timeline, c)
    return c


def _crop_keys(original_keys, original, sampler, offset, duration):
    """Rebase curves to the new source window, sampling edited boundaries.

    The existing renderer only supports linear, hold, and smoothstep interpolation;
    easing across a cropped boundary is therefore resampled at that boundary.
    """
    result = {}
    for parameter, keys in original_keys.items():
        if not keys:
            result[parameter] = []
            continue
        rebased = [dict(k, frame=k['frame']-offset) for k in keys
                   if 0 <= k['frame']-offset < duration]
        if offset != 0 and not any(k['frame'] == 0 for k in rebased):
            rebased.insert(0, {'frame': 0, 'value': sampler(original, parameter, offset),
                               'interpolation': 'hold' if offset < 0 else 'linear'})
        # A curve continuing past the new out-point must reach its original
        # sampled value at the last retained frame, not freeze early.
        if duration > 1 and any(k['frame'] >= offset + duration for k in keys):
            last = duration - 1
            if not any(k['frame'] == last for k in rebased):
                rebased.append({'frame': last,
                                'value': sampler(original, parameter, offset + last),
                                'interpolation': 'linear'})
        result[parameter] = sorted(rebased, key=lambda k: k['frame'])
    return result


def _window(doc, clip, start, source_in, duration):
    """Change clip boundaries and retain keyframe times relative to source."""
    if min(start, source_in) < 0 or duration < 1 or source_in + duration > _source_limit(doc, clip):
        raise ValueError('Edit exceeds the available source handles or timeline')
    previous = copy.deepcopy(clip)
    offset = source_in - previous['source_in']
    clip['start'], clip['source_in'], clip['duration'] = start, source_in, duration
    clip['keyframes'] = _crop_keys(previous.get('keyframes', {}), previous, value_at, offset, duration)
    for old_fx, fx in zip(previous.get('effects', []), clip.get('effects', [])):
        fx['keyframes'] = _crop_keys(old_fx.get('keyframes', {}), old_fx, effect_value_at, offset, duration)


def _invalidate(timeline, *ids):
    touched = set(ids)
    timeline['transitions'] = [t for t in timeline.get('transitions', [])
                               if t['incoming'] not in touched and t['outgoing'] not in touched]


def apply_edit(project, action, *, container_id=None, **kwargs):
    """Return (edited_project, selected_id), or raise with no partial mutation."""
    validate(project)
    doc = copy.deepcopy(project)
    timeline = editing_container(doc, container_id)
    selected_id = kwargs.get('clip_id')

    if action == 'add-track':
        kind=kwargs['track_kind']
        if kind not in ('video','audio'):
            raise ValueError('Unknown track type')
        prefix='V' if kind=='video' else 'A'
        used={t['id'] for t in timeline['tracks']}
        count=1
        while prefix+str(count) in used:count+=1
        new_id=prefix+str(count)
        track={'id':new_id,'kind':kind,'name':new_id,'muted':False,'locked':False}
        if kind=='video':
            index=next((i for i,t in enumerate(timeline['tracks']) if t['kind']=='audio'),len(timeline['tracks']))
            timeline['tracks'].insert(index,track)
        else:timeline['tracks'].append(track)
        selected_id=None

    elif action == 'rename-track':
        track=next((t for t in timeline['tracks'] if t['id']==kwargs['track_id']),None)
        if track is None:raise ValueError('Track does not exist')
        name=kwargs.get('name')
        if not isinstance(name,str) or not name.strip() or len(name.strip())>60:
            raise ValueError('Track name must contain 1–60 characters')
        track['name']=name.strip()
        selected_id=None

    elif action == 'remove-track':
        track=next((t for t in timeline['tracks'] if t['id']==kwargs['track_id']),None)
        if track is None:raise ValueError('Track does not exist')
        if track['locked'] or any(c['track']==track['id'] for c in timeline['clips']):
            raise ValueError('Unlock and empty a track before removing it')
        timeline['tracks'].remove(track)
        selected_id=None

    elif action == 'slip':
        c = _selected(timeline, kwargs['clip_id'])
        delta = _integer(kwargs['delta'], 'Slip offset')
        candidate = c['source_in'] + delta
        if candidate < 0 or candidate + c['duration'] > _source_limit(doc, c):
            raise ValueError('Slip exceeds available source handles')
        # The effect animation stays at the same timeline positions for a slip.
        c['source_in'] = candidate

    elif action in ('trim-left', 'trim-right'):
        c = _selected(timeline, kwargs['clip_id'])
        boundary = _integer(kwargs['frame'], 'Edit boundary')
        if action == 'trim-left':
            delta = boundary - c['start']
            _window(doc, c, boundary, c['source_in'] + delta, c['duration'] - delta)
        else:
            _window(doc, c, c['start'], c['source_in'], boundary - c['start'])
        _invalidate(timeline, c['id'])

    elif action == 'roll':
        outgoing = _selected(timeline, kwargs['outgoing'])
        incoming = _selected(timeline, kwargs['incoming'])
        if outgoing is incoming or outgoing['track'] != incoming['track']:
            raise ValueError('Roll requires adjacent clips on one track')
        shared = outgoing['start'] + outgoing['duration']
        if shared != incoming['start']:
            raise ValueError('Roll requires a shared cut with no overlap or gap')
        new_cut = _integer(kwargs['frame'], 'Rolling edit boundary')
        delta = new_cut - shared
        _window(doc, outgoing, outgoing['start'], outgoing['source_in'], outgoing['duration'] + delta)
        _window(doc, incoming, new_cut, incoming['source_in'] + delta, incoming['duration'] - delta)
        _invalidate(timeline, outgoing['id'], incoming['id'])
        selected_id = incoming['id']

    elif action == 'slide':
        c = _selected(timeline, kwargs['clip_id'])
        delta = _integer(kwargs['delta'], 'Slide offset')
        previous = [x for x in timeline['clips'] if x['track']==c['track'] and x['id']!=c['id']
                    and x['start']+x['duration']==c['start']]
        following = [x for x in timeline['clips'] if x['track']==c['track'] and x['id']!=c['id']
                     and x['start']==c['start']+c['duration']]
        if len(previous)!=1 or len(following)!=1:
            raise ValueError('Slide requires exactly one touching clip on each side')
        before, after = previous[0], following[0]
        _window(doc, before, before['start'], before['source_in'], before['duration'] + delta)
        _window(doc, after, after['start'] + delta, after['source_in'] + delta, after['duration'] - delta)
        c['start'] += delta
        _invalidate(timeline, before['id'], c['id'], after['id'])

    elif action == 'insert':
        if container_id is not None:
            raise ValueError('Ripple insert inside a nested composition is not supported yet')
        target_id = kwargs['track']
        selected_track = next((t for t in timeline['tracks'] if t['id']==target_id), None)
        if selected_track is None or selected_track['locked']:
            raise ValueError('Cannot insert onto a locked or missing track')
        source = next((m for m in doc['media'] if m['id']==kwargs['asset']), None)
        if source is None or not source[selected_track['kind']]:
            raise ValueError('Source media is incompatible with destination track')
        start = _integer(kwargs['start'], 'Timeline in')
        source_in = _integer(kwargs['source_in'], 'Source in')
        length = _integer(kwargs['duration'], 'Insert duration')
        if start < 0 or source_in < 0 or length < 1:
            raise ValueError('Invalid insert range')
        inserted = create_clip(source, target_id, start, source_in, length, doc['fps'])
        if inserted['duration'] != length:
            raise ValueError('Insert exceeds source media handles')
        locked = {t['id'] for t in timeline['tracks'] if t['locked']}
        if any(c['track'] in locked and c['start']+c['duration']>start for c in timeline['clips']):
            raise ValueError('Locked track contains media at or after the insert point')
        split_clips = []
        crossing = set()
        shifted = set()
        for c in list(timeline['clips']):
            old_end = c['start']+c['duration']
            if c['start'] < start < old_end:
                original = copy.deepcopy(c)
                _window(doc, c, c['start'], c['source_in'], start-c['start'])
                other = copy.deepcopy(original)
                other['id']=identifier()
                _window(doc, other, start+length, original['source_in']+start-original['start'], old_end-start)
                split_clips.append(other)
                crossing.add(c['id'])
            elif c['start']>=start:
                c['start']+=length
                shifted.add(c['id'])
        timeline['clips'].extend(split_clips)
        # Preserve transition relationships when both endpoints move intact.
        timeline['transitions']=[t for t in timeline.get('transitions',[])
                                 if t['incoming'] not in crossing and t['outgoing'] not in crossing]
        for transition in timeline.get('transitions',[]):
            if transition['incoming'] in shifted and transition['outgoing'] in shifted:
                transition['start']+=length
            elif transition['incoming'] in shifted or transition['outgoing'] in shifted:
                raise ValueError('Insert crosses an existing two-source transition')
        for caption in list(timeline.get('captions', [])):
            cap_end=caption['start']+caption['duration']
            if caption['start']>=start:
                caption['start']+=length
            elif cap_end>start:
                # Pause the continuing subtitle until after the inserted time.
                extra=copy.deepcopy(caption)
                extra['id']=identifier()
                extra['start']=start+length
                extra['duration']=cap_end-start
                caption['duration']=start-caption['start']
                timeline['captions'].append(extra)
        for marker in timeline.get('markers', []):
            if isinstance(marker,dict) and type(marker.get('frame')) is int and marker['frame']>=start:
                marker['frame']+=length
        timeline['clips'].append(inserted)
        selected_id=inserted['id']

    elif action == 'overwrite':
        track_id = kwargs['track']
        target_track = next((t for t in timeline['tracks'] if t['id'] == track_id), None)
        if target_track is None or target_track['locked']:
            raise ValueError('Cannot overwrite a locked or missing track')
        asset = next((m for m in doc['media'] if m['id'] == kwargs['asset']), None)
        if asset is None or not asset[target_track['kind']]:
            raise ValueError('Source media is incompatible with destination track')
        start = _integer(kwargs['start'], 'Insertion time')
        source_in = _integer(kwargs['source_in'], 'Source in')
        duration = _integer(kwargs['duration'], 'Duration')
        if start < 0 or source_in < 0 or duration < 1:
            raise ValueError('Invalid three-point edit range')
        # Create clip first; create_clip truncates by default, so reject partial ranges.
        new_clip = create_clip(asset, track_id, start, source_in, duration, doc['fps'])
        if new_clip['duration'] != duration:
            raise ValueError('Three-point edit exceeds source media')
        end = start + duration
        if container_id is not None and end > timeline['duration']:
            raise ValueError('Overwrite extends beyond nested composition duration')
        extra = []
        for c in list(timeline['clips']):
            if c['track'] != track_id or c['start'] >= end or c['start']+c['duration'] <= start:
                continue
            original = copy.deepcopy(c)
            old_end = c['start'] + c['duration']
            if c['start'] < start:
                _window(doc, c, c['start'], c['source_in'], start-c['start'])
            else:
                timeline['clips'].remove(c)
            if old_end > end:
                right = copy.deepcopy(original)
                right['id'] = identifier()
                _window(doc, right, end, original['source_in'] + end-original['start'], old_end-end)
                extra.append(right)
            _invalidate(timeline, original['id'])
        timeline['clips'].extend(extra + [new_clip])
        prune_transitions(timeline)
        selected_id = new_clip['id']

    else:
        raise ValueError(f'Unsupported Edit operation: {action}')

    validate(doc)
    return doc, selected_id


def relink(project, asset_id, new_path, probe):
    """Validate a replacement before updating an offline asset's path.

    Video/audio stream-kind mismatches are rejected to protect existing tracks.
    The new file must still cover every used source time range.
    """
    validate(project)
    path = Path(new_path).expanduser().resolve(strict=True)
    if not path.is_file():
        raise ValueError('Media replacement must be a file')
    doc = copy.deepcopy(project)
    media = next((m for m in doc['media'] if m['id'] == asset_id), None)
    if media is None:
        raise ValueError('Media asset not found')
    if bool(probe['video']) != media['video'] or bool(probe['audio']) != media['audio']:
        raise ValueError('Replacement media has incompatible video/audio streams')
    max_frame = math.ceil(float(probe['duration'])*doc['fps']) + 1
    for timeline in [doc, *doc.get('sequences', [])]:
        for clip in timeline['clips']:
            if clip.get('asset') == asset_id and clip['source_in']+clip['duration'] > max_frame:
                raise ValueError('Replacement media is shorter than an existing timeline use')
    media.update(path=str(path), name=path.name,
                 duration_seconds=float(probe['duration']),
                 duration_frames=max(1,round(float(probe['duration'])*doc['fps'])),
                 width=int(probe.get('width',0)), height=int(probe.get('height',0)))
    validate(doc)
    return doc
