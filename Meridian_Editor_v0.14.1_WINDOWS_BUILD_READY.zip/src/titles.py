"""Locally rendered alpha title plates, usable on video tracks.

No bundled third-party font files. A caller may pass a locally installed
OFL font as an absolute .ttf/.otf path; Pillow's built-in typeface is the
fallback. Generation is offline; files persist under the user's data folder.
"""
from __future__ import annotations
import re
import uuid
from pathlib import Path


def create_title(*, text: str, width: int, height: int, size: int = 96,
                 color: str = '#FFFFFF', font_path: str = '', directory: Path):
    if not isinstance(text,str) or not text.strip() or len(text)>350:
        raise ValueError('Title must contain 1–350 characters')
    if len(text.splitlines())>6:raise ValueError('Title cannot exceed six lines')
    if type(width) is not int or type(height) is not int or not 1280<=width<=3840 or not 720<=height<=2160:
        raise ValueError('Invalid title dimensions')
    if type(size) is not int or not 18<=size<=260:raise ValueError('Font size must be 18–260')
    if not isinstance(color,str) or not re.fullmatch(r'#[A-Fa-f0-9]{6}',color):raise ValueError('Invalid title color')
    if not isinstance(font_path,str):raise ValueError('Invalid font path')
    try:
        from PIL import Image,ImageDraw,ImageFont
    except ImportError as err:
        raise RuntimeError('Title generation requires Pillow; the compiled app will bundle it') from err
    if font_path:
        f=Path(font_path).expanduser().resolve()
        if not f.is_file() or f.suffix.lower() not in ('.ttf','.otf','.ttc'):
            raise ValueError('Choose an installed .ttf or .otf font file')
        font=ImageFont.truetype(str(f),size)
    else:
        font=ImageFont.load_default(size=size)
    # Create a truly transparent raster layer, not a black title card.
    img=Image.new('RGBA',(width,height),(0,0,0,0));draw=ImageDraw.Draw(img)
    gap=max(3,size//7)
    bbox=draw.multiline_textbbox((0,0),text,font=font,spacing=gap,align='center',stroke_width=max(1,size//55))
    content_width=bbox[2]-bbox[0];content_height=bbox[3]-bbox[1]
    if content_width>width*.92 or content_height>height*.90:
        raise ValueError('Title is too large for the canvas; reduce font size or shorten text')
    x=(width-content_width)/2-bbox[0];y=(height-content_height)/2-bbox[1]
    draw.multiline_text((x+max(2,size//38),y+max(2,size//38)),text,font=font,
                       fill=(0,0,0,100),spacing=gap,align='center')
    draw.multiline_text((x,y),text,font=font,fill=color,spacing=gap,align='center',
                        stroke_width=max(1,size//55),stroke_fill='#10151A')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    dest=directory/('title-'+uuid.uuid4().hex+'.png');img.save(dest)
    return str(dest)
