#include "compositor.h"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>

namespace {
constexpr int kMaxSide = 16384;

bool valid_size(int width, int height) {
    return width > 0 && height > 0 && width <= kMaxSide && height <= kMaxSide &&
           static_cast<std::size_t>(width) * static_cast<std::size_t>(height) <=
               std::numeric_limits<std::size_t>::max() / 4;
}

std::uint8_t round_byte(float value) {
    return static_cast<std::uint8_t>(std::lround(std::clamp(value, 0.0F, 255.0F)));
}
}  // namespace

extern "C" int meridian_api_version() { return 2; }

extern "C" int meridian_clear(std::uint8_t *destination, int width, int height,
                               int transparent) {
    if (!destination || !valid_size(width, height)) return -1;
    const std::size_t total = static_cast<std::size_t>(width) * height * 4;
    std::fill(destination, destination + total, 0);
    if (!transparent) {
        for (std::size_t i = 3; i < total; i += 4) destination[i] = 255;
    }
    return 0;
}

extern "C" int meridian_over(std::uint8_t *destination, int width, int height,
                              const std::uint8_t *source, int source_width,
                              int source_height, int offset_x, int offset_y,
                              float opacity, int transition, float progress) {
    if (!destination || !source || !valid_size(width, height) ||
        !valid_size(source_width, source_height) || !std::isfinite(opacity) ||
        !std::isfinite(progress) || opacity < 0.0F || opacity > 1.0F ||
        progress < 0.0F || progress > 1.0F || transition < 0 || transition > 2)
        return -1;
    if (opacity == 0.0F || (transition != 0 && progress == 0.0F)) return 0;

    // 64-bit positions prevent overflow when an effect places an image far away.
    const std::int64_t x0 = std::max<std::int64_t>(0, offset_x);
    const std::int64_t y0 = std::max<std::int64_t>(0, offset_y);
    const std::int64_t x1 = std::min<std::int64_t>(width,
                                                  std::int64_t(offset_x) + source_width);
    const std::int64_t y1 = std::min<std::int64_t>(height,
                                                  std::int64_t(offset_y) + source_height);
    if (x0 >= x1 || y0 >= y1) return 0;

    const float transition_opacity = transition == 1 ? progress : 1.0F;
    for (std::int64_t y = y0; y < y1; ++y) {
        for (std::int64_t x = x0; x < x1; ++x) {
            if (transition == 2 && (float(x) + 0.5F) / float(width) > progress) continue;
            auto *dst = destination + (std::size_t(y) * width + std::size_t(x)) * 4;
            const auto *src = source + (std::size_t(y - offset_y) * source_width +
                                        std::size_t(x - offset_x)) * 4;
            const float sa = (float(src[3]) / 255.0F) * opacity * transition_opacity;
            if (sa <= 0.0F) continue;
            const float da = float(dst[3]) / 255.0F;
            const float remain = da * (1.0F - sa);
            const float outa = sa + remain;
            for (int channel = 0; channel < 3; ++channel) {
                // Source-over in straight-alpha (non-premultiplied) space.
                dst[channel] = round_byte((float(src[channel]) * sa +
                                           float(dst[channel]) * remain) / outa);
            }
            dst[3] = round_byte(outa * 255.0F);
        }
    }
    return 0;
}


extern "C" int meridian_over_affine(std::uint8_t *destination, int width, int height,
                                     const std::uint8_t *source, int source_width,
                                     int source_height, float center_x, float center_y,
                                     float scale, float angle_degrees, float opacity,
                                     int transition, float progress) {
    if (!destination || !source || !valid_size(width, height) ||
        !valid_size(source_width, source_height) || !std::isfinite(center_x) ||
        !std::isfinite(center_y) || !std::isfinite(scale) ||
        !std::isfinite(angle_degrees) || !std::isfinite(opacity) ||
        !std::isfinite(progress) || scale < 0.01F || scale > 10.0F ||
        opacity < 0.0F || opacity > 1.0F || progress < 0.0F || progress > 1.0F ||
        transition < 0 || transition > 2) return -1;
    if (opacity == 0.0F || (transition != 0 && progress == 0.0F)) return 0;

    // Fast path for the overwhelmingly common unrotated, 1:1, pixel-aligned layer.
    // Avoids four bilinear samples per destination pixel when unnecessary.
    const double origin_x = double(center_x) - source_width * 0.5;
    const double origin_y = double(center_y) - source_height * 0.5;
    if (scale == 1.0F && angle_degrees == 0.0F &&
        origin_x == std::floor(origin_x) && origin_y == std::floor(origin_y) &&
        origin_x >= std::numeric_limits<int>::min() && origin_x <= std::numeric_limits<int>::max() &&
        origin_y >= std::numeric_limits<int>::min() && origin_y <= std::numeric_limits<int>::max()) {
        return meridian_over(destination, width, height, source, source_width, source_height,
                             static_cast<int>(origin_x), static_cast<int>(origin_y),
                             opacity, transition, progress);
    }

    const double angle = double(angle_degrees) * (3.14159265358979323846 / 180.0);
    const double cs = std::cos(angle), sn = std::sin(angle);
    const double inv_scale = 1.0 / scale;
    const double half_w = source_width * scale * 0.5;
    const double half_h = source_height * scale * 0.5;
    const double bound_x = std::abs(cs) * half_w + std::abs(sn) * half_h + 1.0;
    const double bound_y = std::abs(sn) * half_w + std::abs(cs) * half_h + 1.0;
    const int x0 = std::max(0, static_cast<int>(std::clamp(std::floor(double(center_x) - bound_x), 0.0, double(width))));
    const int x1 = std::min(width, static_cast<int>(std::clamp(std::ceil(double(center_x) + bound_x), 0.0, double(width))));
    const int y0 = std::max(0, static_cast<int>(std::clamp(std::floor(double(center_y) - bound_y), 0.0, double(height))));
    const int y1 = std::min(height, static_cast<int>(std::clamp(std::ceil(double(center_y) + bound_y), 0.0, double(height))));
    const double sx0 = source_width * 0.5 - 0.5;
    const double sy0 = source_height * 0.5 - 0.5;
    const float transition_opacity = transition == 1 ? progress : 1.0F;

    for (int y = y0; y < y1; ++y) {
        const double dy = double(y) + 0.5 - center_y;
        for (int x = x0; x < x1; ++x) {
            if (transition == 2 && (float(x) + 0.5F) / float(width) > progress) continue;
            const double dx = double(x) + 0.5 - center_x;
            const double sx = (cs * dx + sn * dy) * inv_scale + sx0;
            const double sy = (-sn * dx + cs * dy) * inv_scale + sy0;
            // Include fractional coverage of the outermost edge.
            if (sx <= -1.0 || sx >= source_width || sy <= -1.0 || sy >= source_height) continue;
            const int ix = static_cast<int>(std::floor(sx));
            const int iy = static_cast<int>(std::floor(sy));
            const double fx = sx - ix, fy = sy - iy;
            double alpha = 0.0, r = 0.0, g = 0.0, b = 0.0;
            for (int oy = 0; oy != 2; ++oy) {
                const int py = iy + oy;
                if (py < 0 || py >= source_height) continue;
                for (int ox = 0; ox != 2; ++ox) {
                    const int px = ix + ox;
                    if (px < 0 || px >= source_width) continue;
                    const double weight = (ox ? fx : (1 - fx)) * (oy ? fy : (1 - fy));
                    const auto *pixel = source + (std::size_t(py) * source_width + px) * 4;
                    const double a = weight * double(pixel[3]) / 255.0;
                    alpha += a;
                    r += pixel[0] * a;
                    g += pixel[1] * a;
                    b += pixel[2] * a;
                }
            }
            const float sa = float(alpha) * opacity * transition_opacity;
            if (sa <= 0.0F) continue;
            const float da = float(destination[(std::size_t(y) * width + x) * 4 + 3]) / 255.0F;
            const float remain = da * (1.0F - sa);
            const float outa = sa + remain;
            auto *dst = destination + (std::size_t(y) * width + x) * 4;
            const float factor = sa / float(alpha);
            dst[0] = round_byte((float(r) * factor + float(dst[0]) * remain) / outa);
            dst[1] = round_byte((float(g) * factor + float(dst[1]) * remain) / outa);
            dst[2] = round_byte((float(b) * factor + float(dst[2]) * remain) / outa);
            dst[3] = round_byte(outa * 255.0F);
        }
    }
    return 0;
}
