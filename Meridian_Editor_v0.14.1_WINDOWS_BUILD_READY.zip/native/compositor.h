#pragma once
#include <cstdint>

#if defined(_WIN32)
#  if defined(MERIDIAN_BUILD)
#    define MERIDIAN_API __declspec(dllexport)
#  else
#    define MERIDIAN_API __declspec(dllimport)
#  endif
#else
#  define MERIDIAN_API __attribute__((visibility("default")))
#endif

// C ABI: no C++ exceptions or allocator ownership crosses the language boundary.
// Pixel format: tightly packed, *straight alpha* 8-bit RGBA, row-major.
extern "C" {
MERIDIAN_API int meridian_clear(std::uint8_t *destination, int width, int height,
                                int transparent);
// transition: 0=none, 1=cross dissolve, 2=left-to-right wipe.
// Progress is inclusive 0..1, evaluated on integer frame time by caller.
MERIDIAN_API int meridian_over(std::uint8_t *destination, int width, int height,
                               const std::uint8_t *source, int source_width,
                               int source_height, int offset_x, int offset_y,
                               float opacity, int transition, float progress);
// Affine render: center in destination pixels; scale/rotation keyframe-ready.
// Bilinear sampling interpolates premultiplied color to avoid dark halos.
MERIDIAN_API int meridian_over_affine(std::uint8_t *destination, int width, int height,
                                      const std::uint8_t *source, int source_width,
                                      int source_height, float center_x, float center_y,
                                      float scale, float angle_degrees, float opacity,
                                      int transition, float progress);
MERIDIAN_API int meridian_api_version();
}
