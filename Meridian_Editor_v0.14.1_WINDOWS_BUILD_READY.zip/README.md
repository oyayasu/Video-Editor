# Meridian Editor v0.14.1 — Windows installation preparation

Windows installer/portable build scripts and a Qt desktop launcher have been
added. **This ZIP is source only; no Windows EXE has been built or tested.**
Read `INSTALACAO_WINDOWS.md` and `docs/WINDOWS_INSTALLER_AUDIT_v0.14.1.md`.
The editing and effects tools remain those of v0.14.0, without claiming
professional stability or changing the `.meridian` format.

---

# Meridian Editor v0.14.0 — Effects workspace expansion

**This release is an incremental, validated Effects implementation, NOT the completed After Effects replacement or a Windows installer.** The main project remains Python/JavaScript + FFmpeg with an experimental C++ CPU renderer. Use **FFmpeg Stable** to export or inspect new masks, Glow and Drop Shadow; the approximate continuous preview cannot display every effect reliably.

New: **18 original video effects** in AE-related categories, now **67 effects** in the library; **geometric layer masks** (rectangle, ellipse, feather, invert, ordered Add/Subtract/Intersect, opacity) editable in Inspector; true branch-based **Glow/Bloom and Drop Shadow**; proper ordered effect processing in FFmpeg rendering; rejection of unsupported native features rather than silently omitting them. Mask data persists in `.meridian` projects while remaining backward compatible. No node interfaces or Adobe proprietary plugins/assets are included.

Documentation: `docs/EFFECTS_REFERENCE_AND_IMPLEMENTATION_v0.14.0.md` and `docs/TEST_REPORT_v0.14.0.md`. Tested on Linux with FFmpeg, including actual MP4 export and Chromium UI. **Roto Brush/AI object segmentation, planar/3D tracking, expressions, 3D compositing, true optical motion blur and native installers remain pending.** Older editing, fonts and Quick Edit features are carried forward.

---

# Meridian Editor v0.13.0 — DaFont fonts for commercial video titles

**This release remains a source-code prototype, not a compiled Windows installer.** The title/font feature requires optional Pillow (`python -m pip install pillow`). Downloaded font binaries are not included in the source archive.

**DaFont integration:** Quick Edit now lists 17 license-reviewed DaFont font families (SIL OFL or CC0), **in addition to** the previous 37 Google Fonts references. Open a DaFont family page, download its original ZIP and click **Import ZIP** inside Meridian. Accepted TTF/OTF variants are stored privately in the app and can be used in **Create Title** without installing fonts into Windows/macOS. After import, their visual previews are loaded locally where supported. No DaFont font is included or auto-downloaded. The DaFont site itself warns that its "100% Free" badge is not a substitute for checking the original license. Read `docs/DAFONT_INTEGRATION_v0.13.0.md` for full details.

**Compatibility:** v0.12 projects, 82 authored presets and 13 transitions are preserved. Titles still render to PNG assets, not editable vector/text objects. Neither the title image nor imported font is automatically packaged inside portable `.meridian` files.

---

# MERIDIAN — editor de vídeo (prévia técnica v0.12.0)

**Um primeiro protótipo funcional, não um substituto profissional do Premiere Pro ou DaVinci Resolve.** O nome é provisório.

Meridian é uma investigação independente e de código aberto sobre como integrar uma timeline tradicional multicamadas, keyframes editáveis e ferramentas de composição na mesma interface. Este arquivo acompanha todo o código-fonte. A interface não utiliza código nem recursos gráficos extraídos da Adobe ou da Blackmagic.

## v0.12.0 — Quick Edit: biblioteca de presets e títulos

A nova aba **Quick Edit** aplica presets autorais em um clique, sem alterar o layout profissional. São **82 receitas editáveis**: 46 animações de entrada/saída (posição e fades), 24 looks de vídeo e 12 cadeias de áudio; mais **13 transições de duas fontes** (12 de vídeo, um crossfade de áudio). Buscar, filtrar por categoria, marcar favoritos e aplicar ao clipe selecionado. Transições exigem dois clipes realmente sobrepostos na mesma faixa. A aplicação de presets é transacional via backend; presets não sobrepõem arquivos da mídia original e os efeitos aparecem no Inspector.

**Fontes:** catálogo de descoberta de **37 famílias SIL OFL** com links à origem, sem binários TTF/OTF empacotados. Elas permitem uso comercial respeitando a licença; não são declaradas domínio público. Para criar uma camada de título, use **Quick Edit → Create Title / Text Layer**; a ferramenta opcional Pillow gera um PNG transparente persistente, e ele pode ser animado com as receitas de movimento. Para escolher a família, informe o caminho de um arquivo `.ttf/.otf` já instalado. **O texto rasterizado não é editável como texto**; trocá-lo exige gerar outro título. O arquivo PNG permanece em `~/.meridian-editor/generated/titles/` e precisa ser incluído ao transportar o projeto a outro computador.

**Licenças:** não existem presets, packs ou fontes proprietárias extraídas do CapCut/Premiere/After Effects, nem cópias de packs de sites. A biblioteca rápida utiliza exclusivamente código e receitas próprias, além dos filtros que o FFmpeg já fornece. Confira `docs/QUICK_EDIT_RESEARCH_AND_LICENSES_v0.12.0.md`.

**Exportação:** use **FFmpeg Stable** para todas as novas máscaras e títulos PNG. O C++ CPU experimental suporta apenas Cross Dissolve/Wipe Left e não deve descartar silenciosamente uma transição que não compreende. A prévia contínua básica ainda é aproximada. Os modelos e efeitos respeitam o formato `.meridian` existente.

**Testes específicos:** 82 receitas validadas, máscaras das 12 transições de vídeo renderizadas como PNG com FFmpeg, títulos RGBA gerados e sobrepostos a vídeo, endpoints HTTP de presets/títulos verificados, navegador Chromium com API simulada sem erros JS. Esses testes não validam desempenho profissional nem instaladores em Windows/macOS. A suíte geral não foi concluída nesta etapa.

**Dependências:** as anteriores (Python 3.10+, FFmpeg/FFprobe); **Pillow é opcional e exigido apenas para gerar novos títulos** (`python -m pip install pillow` se necessário). A versão executável futura deve incluir as dependências por padrão. O ZIP continua sendo **código-fonte**, não um instalador.

## v0.11.0 — Source + Program Monitor independentes (um subsistema complexo)

A nova área Edit tem **dois monitores lado a lado**: Source para inspecionar mídia, navegar por quadros e marcar In/Out; Program para visualizar a sequência e definir pontos de edição. Ambos têm transportes distintos. A origem tem controles separados de patching V/A. Source Insert/Overwrite faz edição transacional pelo backend, incluindo vídeo e áudio no mesmo comando, sem aplicar ripple duas vezes. As marcações de origem são salvas por arquivo no projeto. Edições de três pontos diretas/reversas são suportadas; quatro pontos incompatíveis são rejeitados sem alteração silenciosa de velocidade.

**Fluxo básico:** importe uma mídia → **duplo clique para abrir no Source** (não insere automaticamente) → marque In (`I`) e Out (`O`) → configure V/A → coloque o playhead da sequência → clique Insert ou Overwrite. Para definir também as margens do destino, marque In/Out no monitor Program. `Space` controla o Program; `Shift+Space` controla o Source. Atalhos continuam customizáveis.

**Testes:** 21 novos testes; 63 testes do núcleo editorial e 39 de outros módulos aprovados em execuções separadas. Chromium com API simulada, endpoint HTTP real testado separadamente, exportação MP4 FFmpeg com vídeo/áudio conferida. **Suíte monolítica excedeu timeout**. Leia `docs/SOURCE_PROGRAM_MONITORS_v0.11.0.md`, `docs/CODE_AUDIT_v0.11.0.md` e `docs/TEST_REPORT_v0.11.0.md`.

**Limitações:** o Source usa o decodificador HTML do navegador; não garante seek frame-accurate em todos os codecs. Sem linked-selection persistente entre faixas, sem proxy/multicam, sem clock AV profissional e sem `.exe` independente. O programa continua sendo um protótipo Python+JS+FFmpeg; não declarar a área Edit concluída.

## v0.10.0 — Edição de timeline mais rigorosa (não é a conclusão do Edit)

**Ainda é um protótipo técnico; a área Edit NÃO está 99% pronta.** Esta entrega não contém `.exe` compilado e continua precisando de Python/FFmpeg para execução a partir do código.

**Novidades funcionais:** trim preciso de pontos In/Out; Slip, Slide e Rolling Edit; Insert (ripple nas faixas desbloqueadas e legendas) e Overwrite numéricos de três pontos; adição/renomeação/remoção segura de faixas; detecção de mídia offline e Relink manual; novos atalhos personalizáveis; validação transacional das operações no modelo Python. A interface recebeu os comandos correspondentes. Edits são feitos em frames inteiros. O mouse trim agora usa a operação de modelo na confirmação, em vez de preservar sua própria implementação de keyframes.

**Pesquisa e limites:** ver `docs/EDIT_REFERENCE_AUDIT_v0.10.0.md` e `docs/EDIT_TEST_REPORT_v0.10.0.md`. A v0.10.0 não incluía Source Monitor dedicado, proxy, multicam, speed ramps, sync AV profissional, faixas vinculadas robustas, Qt nativo, export profissional completo, gerenciamento de cor HDR nem todos os efeitos. Alguns diálogos exigem números de quadros, não gestos de trim tradicionais.

**Usar:** como nas versões anteriores (`start-windows.bat`, `start-macos-linux.sh`, compilação C++ opcional com `build-native-windows.bat` ou `build-native.sh`), com Python e FFmpeg disponíveis. Recomenda-se testar apenas com cópias de projetos. Scripts de empacotamento Windows estão presentes, mas **não foram compilados/validados** aqui.

## v0.9.0 — Quadros por demanda, cache, relógio e encoder opcional

A reprodução do monitor agora pode solicitar diretamente um **número de quadro** ao compositor C++ CPU; o servidor mantém um **cache JPEG LRU de 24 MiB** com leitura segura, saltos na timeline e descarte de solicitações obsoletas. O modo antigo MJPEG foi substituído por este protocolo. A interface exibe cache HIT/MISS. Pillow é opcional e acelera a compactação JPEG; FFmpeg continua como alternativa embutida no fluxo.

Um `AudioContext` centraliza a contagem de tempo da timeline e um cliente controla a visualização do último quadro solicitado. A interface admite **H.264 por encoder de hardware**, mas só habilita a opção após um teste de codificação real com quadros RGBA. **Nem o relógio garante sincronismo sample-accurate nem esse encoder equivale a composição GPU.** A renderização das camadas continua C++ CPU e filtros FFmpeg; a prévia WebGL2 também continua disponível. Consulte `docs/PLAYBACK_PIPELINE_v0.9.0.md` para limites, testes e próximos marcos.

## v0.8.0 — GPU no monitor + playback contínuo pelo compositor nativo (experimental)

O monitor agora tem **três modos independentes do motor de exportação**:

1. **Browser · Basic** — prévia HTML convencional da versão anterior (padrão).
2. **WebGL2 · GPU preview** — compõe texturas dos vídeos no monitor via GPU do navegador, com posição, escala, rotação, opacidade, correção básica de cor e máscaras de Cross Dissolve/Wipe Left. O navegador e o driver precisam oferecer WebGL2; caso contrário, a interface retorna ao modo básico. **Não é um exportador GPU, não replica os 49 efeitos e não foi validado em hardware GPU neste ambiente.**
3. **C++ · Stream** — quando o compositor nativo está compilado, reproduz continuamente imagens MJPEG produzidas pelo **mesmo `NativeTimeline.frame()`** usado na exportação experimental. Possui reprodução limitada nominalmente a aproximadamente **15 fps** para conter custo, e pode ficar abaixo disso em máquinas lentas. O áudio continua no monitor HTML e **não possui sincronização amostral garantida**. O stream de vídeo não embute legendas, que continuam como overlay do monitor.

O backend cria uma sessão temporária, de uso único, autenticada no início via token CSRF, transmitida a partir do loopback `127.0.0.1`. O compositor C++ desenha cada quadro, e um processo FFmpeg reutilizável codifica o MJPEG em resolução reduzida para a prévia. Cancelamento de stream elimina processos e decoders. Os clipes, keyframes, presets e exportadores anteriores não foram substituídos. **O arquivo `.meridian` permanece idêntico.**

**Executar**: compile o motor (`build-native-windows.bat` ou `./build-native.sh`), inicie pelo launcher existente e escolha o modo no seletor **Monitor playback mode**. O seletor **Render engine** ainda configura somente a exportação e o comando Render frame. Para comparar a fidelidade, pause, selecione `C++ CPU` como render engine e clique em Render frame.

**Requisitos:** Python 3.10+, FFmpeg/FFprobe, CMake + compilador C++17 para a opção C++ Stream, navegador com WebGL2 para GPU preview. Uma GPU não é necessária para usar Browser/Stream, mas a composição de stream continua feita na CPU. Não há Vulkan/Metal/Direct3D, Qt nativo, player com áudio sincronizado, cache de vídeo profissional, nem aceleração GPU na exportação. A taxa efetiva é limitada pelo hardware. Testar no seu Windows é uma etapa pendente.

Leia `docs/PLAYBACK_PIPELINE_v0.8.0.md` e `docs/CODE_AUDIT_v0.8.0.md` antes de usar em projetos importantes.

---

## Novidades da v0.7.0 — primeiro compositor nativo C++ (CPU, experimental)

A v0.7 acrescenta uma **biblioteca C++17 compilável**, usada para composição
alfa RGBA de camadas, transformações afins com amostragem bilinear (posição,
**escala e rotação animáveis**), keyframes de opacidade, Cross Dissolve e Wipe
Left. O mesmo núcleo gera os pixels dos quadros de conferência e da exportação
MP4. FFmpeg continua responsável por decodificação, efeitos por clipe,
processamento de áudio e codificação de vídeo. Não existem nós visuais.

**Como experimentar:** primeiro compile **`build-native-windows.bat`** (Windows
com CMake e Visual Studio Build Tools C++), ou **`./build-native.sh`**
(macOS/Linux com CMake e compilador C++17). Depois abra o Meridian e, no monitor,
selecione **Render engine → C++ CPU · Experimental**. Use **Render frame** para
conferir um quadro e **Export** para usar o mesmo motor no MP4. É possível
voltar a **FFmpeg · Stable** a qualquer momento. O formato `.meridian` não muda.

**Avisos:** ainda é uma interface HTML/JS com backend Python, não um editor Qt.
A prévia **contínua** é aproximada e não passa pelo C++; somente Render frame
e exportação escolhida como nativa utilizam o novo núcleo. Áudio é mixado pelo
FFmpeg. Legendas embutidas exigem FFmpeg Stable. Nested usa FFmpeg para criar
intermediários antes da composição nativa do pai. Ainda não há GPU, HDR,
composição em luz linear, cache de mídia profissional nem reprodução nativa
em tempo real. **Esta é uma etapa real de migração, não a migração completa.**

O projeto passou pelos testes anteriores e recebeu regressões nativas para
composição, cores, transparência, transformações, vídeo com áudio e endpoints
HTTP. Consulte `docs/NATIVE_COMPOSITOR_v0.7.0.md` e
`docs/CODE_AUDIT_v0.7.0.md` para a arquitetura, verificações, limitações e
próximos marcos. O arquivo ZIP não inclui binários compilados de outra máquina.

---

## Começar no Windows

1. Instale **Python 3.10 ou mais recente** (marque *Add Python to PATH* na instalação).
2. Instale **FFmpeg e FFprobe**, colocando ambos no `PATH` do sistema (ver https://ffmpeg.org/download.html). Verifique no terminal: `ffmpeg -version` e `ffprobe -version`.
3. Extraia o ZIP em uma pasta qualquer.
4. Execute **`start-windows.bat`**. A interface abre em seu navegador local, no endereço `http://127.0.0.1:<porta>`; o processamento permanece em seu computador.
5. Clique **Import** e selecione arquivos. Caso o seletor do sistema não funcione, forneça caminhos absolutos (um por linha).
6. Dê um duplo clique na mídia para abri-la em **Source**. Defina In/Out e V/A; use **Insert** ou **Overwrite** para editá-la na timeline. Ajuste as propriedades no Inspector e use **Export** para gerar MP4/H.264.

No macOS/Linux: `./start-macos-linux.sh` ou `python3 start.py`.

### Empacotar um EXE (Windows)

Existe um script **experimental, não verificado no Windows**, em `packaging/build-windows.ps1`. Ele exige FFmpeg/FFprobe e usa PyInstaller para gerar `dist/Meridian-Preview.exe`. O EXE não tem instalador; o script não faz assinatura digital. Faça o build em Windows e teste antes de compartilhar.

## Novidades da v0.6.0 — renderização compartilhada, transições e animação de efeitos

**Primeira implementação funcional, ainda não um motor profissional em tempo real.** A prévia rápida baseada no navegador continua aproximada. O novo comando **Render frame** usa diretamente o mesmo grafo de filtros FFmpeg utilizado para o MP4, gerando um PNG fiel para conferir um quadro **com o playback pausado**. O FFmpeg decodifica os quadros anteriores ao solicitado, portanto este modo pode ser demorado em projetos longos; composições nested também são pré-renderizadas temporariamente. Foi testada a comparação numérica de quadros PNG/MP4, tolerando perdas de H.264.

**Transições reais entre duas fontes**: Cross Dissolve, Wipe Left e Audio Crossfade. Os dois clipes precisam estar na **mesma faixa**, com uma sobreposição real de pelo menos dois quadros. Selecione ambos com Shift+clique e use **Transition** na timeline, ou procure por *Timeline Transitions* no painel Effects. Informe a duração dentro da sobreposição. Clique na pequena faixa sobre a região de transição para **editar ou remover**. Não existem handles invisíveis ou auto-trim com frames inventados. Transições não podem se sobrepor a outras transições da mesma faixa; movimentações/trims que as invalidem podem removê-las. O crossfade de áudio utiliza um envelope linear de amplitude, não a curva equal-power; o mixador de áudio usa soma sem normalização automática.

**Keyframes em efeitos nativos selecionados:** Brightness & Contrast (Brightness, Contrast), Saturation e Amplify (Gain). Ao selecionar um clipe, mova o playhead e clique no diamante ao lado do parâmetro no Inspector. Cada efeito guarda suas próprias curvas e valores independentemente das propriedades do clipe, com interpolação linear, hold ou smoothstep. A exportação avalia esses valores por quadro/bloco nos filtros FFmpeg. Outros efeitos ainda têm parâmetros estáticos; não são anunciados como animáveis. A UI apresenta um botão de keyframe, mas o gráfico especializado com tangentes Bézier para parâmetros dos efeitos **ainda não está implementado**.

**Integridade:** transições e curvas de efeitos são serializadas no projeto `.meridian`; projects antigos sem `transitions` continuam válidos. O nest preserva transições entre os clipes selecionados. A divisão de clipes foi corrigida para preservar a interpolação entre keyframes que atravessam a linha de corte. A edição da timeline faz limpeza de transições inválidas, mas não substitui um sistema profissional de trim.

**Testes:** **69 testes automatizados aprovados**, incluindo casos de pixels reais para dissolve e wipe, reprodução de efeitos animados, saída de áudio, serialização, HTTP de prévia, transições dentro de nests e regressões da v0.5.0. Interface exercitada em Chromium com API simulada, sem erros de JavaScript; endpoints HTTP testados separadamente. **Não houve teste end-to-end navegador→servidor no Chromium do ambiente**, que bloqueou navegação HTTP local. Leia `docs/RENDER_PIPELINE_v0.6.0.md` e `docs/TEST_REPORT_v0.6.0.md`.

### Como testar rapidamente

1. Importe dois arquivos de vídeo e posicione-os **na mesma faixa** da timeline.
2. Faça uma sobreposição arrastando um dos clipes sobre o final do outro.
3. Selecione ambos (Shift+clique) → **Transition** → **Cross Dissolve** ou **Wipe Left** → defina o número de frames.
4. Pause, coloque o playhead dentro da sobreposição e clique **Render frame** para ver um quadro renderizado pelo mecanismo de exportação.
5. Aplique **Brightness & Contrast**, **Saturation** ou **Amplify**; posicione o playhead dentro do clipe e clique no diamante ao lado de um parâmetro para criar um keyframe.
6. Salve o projeto e exporte MP4 para conferir o resultado. **Faça testes com cópias**, não com o projeto original de um cliente.

### Não implementado nesta versão

Compositor Qt/C++/MLT, playback GPU em tempo real, render-farm, preview/proxy contínuo, transições sem sobreposição automática, estabilização e tracking de nível profissional, expressões do After Effects, curvas Bézier para parâmetros de efeitos, keyframes de todas as propriedades do clipe na exportação, hosts OpenFX/VST e todos os efeitos do Premiere. A v0.6 **não é um produto de produção profissional** e ainda requer Python/FFmpeg.

---

## Novidades da v0.5.0 — auditoria do Premiere 26.0 e expansão dos efeitos

**49 efeitos, animações e fades aplicáveis ao projeto** (32 novos em relação à v0.4.0), com processamento real na exportação FFmpeg. O painel Effects foi mantido com filtros por categoria e pesquisa; a ordem da pilha no Inspector define a ordem do processamento.

Novidades por família:

- **Color Correction:** brilho/contraste, saturação, temperatura de cor, vibrance, tint e dois presets de curvas RGB.
- **Blur & Sharpen:** horizontal blur, vertical blur.
- **Stylize / Noise & Grain:** Mosaic/Pixelate, Find Edges, Posterize e Film Noise.
- **Transform / Distort:** flips horizontal/vertical, RGB Split e correção radial de lente.
- **Keying:** Green Screen Key e Luma Key; preservação de alfa em empilhamento validada em teste específico. Isso **não é paridade com Ultra Key** nem inclui despill completo.
- **Audio:** amplificação, bass/treble/parametric EQ, hard limiter, noise gate, de-esser, FFT noise reduction, room reflections, tremolo, chorus, flanger e balance estéreo.

**Inventário documental separado:** `docs/PREMIERE_26_CATALOG.json` registra 327 referências Adobe (90 efeitos de vídeo ativos, 81 transições ativas e históricos; mais 38 efeitos de áudio selecionados). **Os itens pesquisados não aparecem automaticamente como funcionais na interface.** `docs/PREMIERE_26_AUDIT.md` traz fontes, classificações e lacunas.

Esta versão permanece um protótipo. **Não** implementa todas as funções do Adobe Premiere, não suporta transições de dois clipes, não oferece prévia equivalente ao export para todos os efeitos, não tem motor GPU/Qt/MLT, e os efeitos ainda não possuem keyframes individuais. Use somente para experimentos, validando todo arquivo exportado.

### Testes da v0.5.0

Todos os efeitos de vídeo novos passaram no teste de exportação individual; todos os efeitos de áudio novos passaram na exportação individual; foram testados também o canal alfa em duas operações consecutivas, ordenação da pilha, validação de parâmetros e integridade do inventário oficial. Execute `python -m unittest discover -s tests -v` para repetir a suíte.

## Novidades da v0.4.0 — biblioteca de efeitos, animações e limpeza de código

**17 efeitos e animações nativos **na versão v0.4.0**, agrupados por categoria e realmente processados na exportação**. Na aba Effects, pesquise, escolha uma categoria, clique para adicionar ao clipe selecionado ou arraste até um clipe na timeline. Edite os parâmetros no **Inspector > Effect Stack**. É possível desativar, ativar, copiar/colar, reordenar e remover cada instância, mantendo o processamento não destrutivo e a ordem salva no projeto.

| Categoria | Efeitos |
| --- | --- |
| Color Correction | Gamma, Hue Shift, Black & White, RGB Shadows Balance |
| Blur & Sharpen | Gaussian Blur, Unsharp Mask, Spatial / Temporal Denoise |
| Stylize | Vignette, Invert Colors |
| Audio Effects | High-Pass, Low-Pass, Dynamic Compressor, Echo / Delay |
| Animation | Slide In From Left, Slide Out To Right |
| Transitions | Fade In, Fade Out |

A seção **Transitions** contempla, nesta versão, *fades de borda* (para/de transparência ou silêncio). **Não há Cross Dissolve entre clipes**, nem suporte a transições de movimento complexas. Os parâmetros dos efeitos são estáticos; a animação procedural `Slide` tem tempo e distância configuráveis, mas não keyframes livres próprios. A prévia HTML aproxima apenas parte dos efeitos; a exportação FFmpeg é a referência atual.

**Edição da timeline:** novos botões `Duplicate` (Ctrl+Alt+D) e `Ripple` (Shift+Delete). A exclusão ripple desloca somente os clipes posteriores da **mesma faixa**, sem alterar outras trilhas; a operação é recusada quando há interseções ambíguas. O comando Split agora executa no modelo Python validado, inclusive dentro de composições aninhadas.

**Qualidade:** catálogo e validação centralizados em `src/effects.py`, painel isolado em `web/effects-ui.js`, operações comuns no modelo Python, limpeza de código legado identificado e testes ampliados para **41**. Leia `docs/CODE_AUDIT_v0.4.0.md` antes de declarar um recurso pronto para produção.

**Compatibilidade:** projetos `.meridian` anteriores são aceitos. O pacote ainda exige Python 3.10+ e FFmpeg; **não é o novo aplicativo Qt/C++** e não foi validado como EXE autônomo do Windows. Instalar uma versão experimental preservando o seu projeto é responsabilidade do usuário; faça backup antes de usar material importante.

## Novidades da v0.3.0 — Edit / Effects, nests e atalhos

- **Edit e Effects:** espaços de trabalho separados por presets, com layouts reordenáveis. O Effects abre a biblioteca de efeitos + curvas de animação. **Não existe ainda um motor After Effects completo**: as ferramentas avançadas de composição são roadmap.
- **Nest / precompose:** selecione clipes (Shift+clique permite multiseleção), clique **Nest** ou Ctrl+Alt+N, nomeie, e os clipes são movidos para uma composição editável. A composição pode ser aberta por duplo clique no clipe roxo, **Open Nest** ou Enter; **← Back** volta à timeline pai. Também funciona recursivamente. O projeto guarda as composições como referências, não como vídeo final achatado.
- **Export de nest:** composições de múltiplas faixas são pré-renderizadas temporariamente em ProRes 4444 com alfa preservado e a timeline principal é renderizada em MP4 via FFmpeg. Testes confirmaram vídeo+áudio e dois níveis, mas não comprovam conformidade geral de composição. **A prévia HTML ainda não corresponde fielmente ao export em todos os casos**, em especial efeitos/transforms no wrapper, camadas mais sofisticadas, colorimetria, transparência e organização de todas as faixas.
- **Atalhos personalizáveis:** botão **Shortcuts** ou Ctrl+Alt+K. É possível atribuir combinações a 19 comandos; conflitos são rejeitados. O resultado persiste em `~/.meridian-editor/shortcuts.json`, por instalação, mesmo mudando a porta local. O sistema operacional pode reservar combinações.
- **Auditoria profissional:** `docs/AFTER_EFFECTS_PARITY_AUDIT.md`, inventário detalhado das famílias de efeitos, camadas, máscaras, tipografia, tracking, 3D, cor, áudio, opções de render e critérios de aceitação.
- **Tests:** suíte ampliada para modelagem e exportação de nests, alpha e validação de atalhos. Sem testes de hardware/Windows nativos até o momento.

### Limitações específicas de nests nesta prévia

- Seleção múltipla básica, por Shift ou Ctrl+clique, sem ferramenta de seleção retangular.
- Reorganizar clipes e renderizar pode demandar pré-renderizações demoradas; ainda não há cache inteligente de sequências.
- Mídia em diferentes FPS/tamanhos e efeitos em layers aninhadas ainda não têm semântica profissional completa.
- Transcrição de IA dentro da edição de uma composição aninhada não é suportada; export SRT/VTT usa a timeline principal.
- Arquivos `.meridian` antigos continuam aceitos; a estrutura `sequences` é opcional nos projetos anteriores.

## Novidades da v0.2.0

- **Sem nós** em nenhuma parte da interface, incluindo a visão de futuro. Estrutura visual baseada em timeline, layers, Inspector, keyframes, curvas e pilhas de efeitos.
- **Workspaces personalizados (prévia):** ajuste a largura das três áreas superiores arrastando seus divisores, arraste o puxador ⠿ para trocar os painéis de posição e ajuste a altura da timeline pelo separador horizontal. Presets Editing/Color/Audio/Captions; botão **Save layout** grava a organização em `~/.meridian-editor/workspace.json`, persistindo entre reinicializações e portas diferentes. **Agrupamento real de abas e janelas flutuantes ainda não estão implementados** (previstos na migração Qt).
- **Legendas manuais e automáticas:** painel **Captions**, adição manual, faixa CC, visualização no monitor, ajuste de texto e tempo por quadros. Geração com IA local via adaptador opcional `faster-whisper` (execução assíncrona, sem API paga). Primeiro instale com `install-ai-windows.bat` ou `python -m pip install faster-whisper`; modelos podem exigir download inicial, consumir RAM e executar lentamente na CPU. **A integração ainda não foi verificada com modelos baixados nesta máquina.**
- **Exportar legendas**: SRT, VTT e opção de gravar legendas no vídeo na exportação MP4 (requer FFmpeg com libass). Exportação com legenda foi testada em Linux, não no Windows.
- **Efeitos avançados futuros** estão descritos em `docs/PRODUCT_VISION.md`. A v0.5.0 implementa 49 efeitos/presets/fades baseados em FFmpeg, mas não equivale às implementações profissionais da Adobe ou Blackmagic.

## Funcionalidades implementadas nesta prévia

- Interface escura com visualizador, biblioteca de mídia, painel de efeitos, inspector e timeline multifaixas.
- Importação por seletor nativo/caminho absoluto; inspeção de áudio/vídeo via FFprobe.
- Inserção de clipes de vídeo e áudio, arrastar na timeline, ajustar as bordas, selecionar, cortar, deletar, travar/silenciar trilhas e zoom temporal.
- Controles numéricos de posição, escala, rotação, opacidade, volume, brilho, contraste, saturação e desfoque.
- Keyframes por propriedade; interpolação linear, hold e ease (smoothstep); gráfico com arraste de keyframes.
- Reprodução de prévia pelo navegador (dependente dos codecs aceitos pelo navegador); áudio separado por faixa.
- Exportação MP4/H.264 via FFmpeg com composição de múltiplas faixas de vídeo, áudio mixado, trims, posição X/Y animada, transformações estáticas e efeitos de cor estáticos.
- Salvar/abrir projetos `.meridian`, autosave para recuperação local, Ctrl+Z / Ctrl+Shift+Z, Ctrl+K e outros atalhos.
- Servidor restrito a `127.0.0.1`, proteção de POST com token local e streaming de mídia com suporte a *HTTP Range*.

## Limitações importantes (não ignore)

- **Não existe ainda integração funcional com MLT ou Qt.** A arquitetura de destino é MLT + Qt/C++; esta prévia usa interface HTML/JS e FFmpeg como um adaptador transitório para validar comportamentos.
- A prévia pode não conseguir reproduzir codecs de produção (ProRes, DNxHR, HEVC ou certos perfis) mesmo quando o FFmpeg consegue exportá-los.
- **Apenas os keyframes X/Y são exportados nesta versão.** Keyframes de escala, rotação, opacidade, áudio e cor funcionam na prévia, mas são tratados como valores estáticos na exportação. O gráfico implementa smoothstep, não Bézier livre com tangentes editáveis.
- A prévia não possui caching/proxies, aceleração GPU adequada, multicâmera, mixer profissional, gerenciamento de cor, HDR, render farm, títulos, máscaras vetoriais, rastreamento, estabilizador, composições 3D ou host de plugins OpenFX/VST3. Há **chroma key e luma key básicos** a partir da v0.5.0, mas não ferramentas profissionais completas de extração de matte.
- Dados dos projetos usam caminhos absolutos; mover um projeto entre máquinas requer relink manual (ainda não implementado).
- Não há garantias de frame-exact sync em mídias de frame rate variável e formatos não convencionais. Não usar em trabalhos críticos sem validar visual e auditivamente o resultado.
- As operações de arrastar da timeline são uma prova de conceito e podem precisar de melhor tratamento de ripple, snapping, sobreposição e linked media.
- A arquitetura de segurança é para uso **local, pessoal e confiável**; não exponha a porta na rede nem execute como um serviço público.

## Status de validação

- Validado automaticamente: modelo Python, persistência JSON, legendas e formatação SRT/VTT, configurações de workspace, semântica de split, keyframes e exportação de arquivos MP4 sintéticos com áudio, efeitos e burn-in de legenda em Linux.
- Interface inspecionada com Chromium headless carregando CSS e JavaScript em memória: abertura de menus, inserção simulada de mídia e clipes, renderização da timeline e gráfico; capturas nos diretórios de testes.
- Comunicação HTTP local validada com `urllib`: metadados, Range request parcial (206) e rejeição de token inválido (403).
- **Não validado:** Windows nativo, EXE gerado por PyInstaller, pacotes Linux/macOS, longas timelines, codecs profissionais, hardware acceleration, desempenho sob carga e qualidade de conformidade com arquivos reais complexos.

## Documentação

- `docs/PRODUCT_VISION.md`: requisitos inegociáveis, catálogo de efeitos nativos e critérios de aceitação.
- `docs/PREMIERE_26_AUDIT.md` e `docs/PREMIERE_26_CATALOG.json`: pesquisa atualizada, inventário e lacunas de paridade funcional.
- `docs/RESEARCH.md`: levantamento inicial, referências oficiais com páginas que contêm capturas e gravações, e conclusões.
- `docs/ARCHITECTURE.md`: proposta de arquitetura profissional em Qt/C++/MLT e estratégia de migração deste protótipo.
- `docs/FEATURE_MATRIX.md`: escopo, etapas e gaps para paridade profissional.
- `docs/AFTER_EFFECTS_PARITY_AUDIT.md`: auditoria de funcionalidades Premiere/After Effects/Resolve, categorias de efeitos e critérios de aceitação.
- `docs/TEST_REPORT.md` e `docs/TEST_REPORT_v0.5.0.md`: evidências e limites dos testes, inclusive os 47 testes da entrega atual.
- `tests/meridian-ui.png` e `tests/meridian-ui-media.png`: capturas da interface **que criamos**, não das interfaces Adobe/Blackmagic.

Para executar os testes: `python -m unittest discover -s tests -v` (FFmpeg precisa estar disponível para testes de render).

## Licença e independência

Código Meridian: **GNU GPL v3.0** (arquivo `LICENSE`). Marcas Premiere, After Effects e Resolve pertencem a seus respectivos titulares; não há afiliação com essas empresas. FFmpeg e eventuais bibliotecas futuras têm suas próprias licenças, que precisam ser respeitadas na distribuição. As referências visuais externas não estão incorporadas ao código.

### Importante sobre processamento local de IA

O Meridian não contém uma API de reconhecimento de voz paga. O adaptador `faster-whisper` funciona no processador usando `int8`. **A GPU AMD não é acelerada por este adaptador atual**; será analisado `whisper.cpp` com Vulkan. É possível deixar o motor de IA desinstalado para quem não quer ocupar espaço. `WhisperX`, reconhecimento de falantes e timestamp por palavra não estão implementados nesta versão.

Para distribuições públicas futuras será necessária revisão das licenças de todos os modelos, pesos e dependências efetivamente distribuídos.
