#!/bin/sh
set -eu
cd "$(dirname "$0")"
cmake -S native -B native/build -DCMAKE_BUILD_TYPE=Release
cmake --build native/build --config Release --parallel 2
mkdir -p native/bin
for file in native/build/libmeridian_compositor.so native/build/libmeridian_compositor.dylib; do
  if [ -f "$file" ]; then cp "$file" native/bin/; fi
done
printf '\nNative compositor compiled. Run tests: python3 -m unittest discover -s tests\n'
