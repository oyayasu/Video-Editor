# Revisão técnica v0.9.0

- Substituído `src/native_playback.py` (transporte MJPEG livre) pelo transporte orientado a quadros `src/frame_cache.py`. A camada de cliente correspondente é `web/frame-client.js`.
- Separado `src/hardware.py`: detecção opcional de encoder H.264 com teste real de RGBA bruto, sem confundir presença de encoder no FFmpeg com disponibilidade de driver.
- `web/transport-clock.js`: único transport clock com seek/pausa, substitui a contagem livre por `performance.now()` espalhada pela interface.
- Cache LRU limitado por bytes e lock de acesso ao compositor. Cancelamento, expiração de sessão e descarte de decodificador com falha. Pillow é um acelerador opcional para JPEG com FFmpeg como fallback.
- Invalidada a sessão de preview quando o conteúdo ou a composição editada muda: edição, undo/redo, nest, mudança de composição, operações de timeline, transições, alterações por gesto de keyframe/trim/drag e abertura de projeto.
- Corrigido acesso a propriedades do clipe anterior durante trim de uma sequência aninhada, que antes consultava apenas os clipes da sequência principal.
- Adicionado status de cache HIT/MISS ao monitor. A opção de preview evita afirmar sincronia audiovisual perfeita.
- Nenhum backend GPU nativo, host Qt, cache em disco ou engine de áudio nativo foi adicionado. Os módulos C++ CPU e FFmpeg existentes permanecem ativos.

## Dívida técnica prioritária

- `web/editor.js` ainda é monolítico; separar controlador de projeto, timeline, história/undo, transporte, render e UI em módulos com contrato de eventos.
- `src/native_render.py` cria múltiplos processos FFmpeg para composição multimídia. A próxima geração deve usar bibliotecas decodificadoras persistentes e worker pools.
- Ausência de benchmark industrial de longo prazo, testes de crash/recuperação após falta de energia, cobertura de Windows/macOS e sincronização medida em dispositivo.
- O hardware encoder opcional possui fallback selecionável, mas não substitui um compositor de efeitos acelerado por GPU.
