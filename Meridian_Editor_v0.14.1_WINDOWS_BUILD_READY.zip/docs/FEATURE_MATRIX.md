# Feature matrix — v0.4.0 additions

| Capability | Status | Specific limitation |
| --- | --- | --- |
| Categorized effects library + search | Implemented | Only 17 effects, not all Premiere/Resolve/AE effects |
| Editable clip effect stack | Implemented | Parameters are static (no effect keyframes) |
| Drag effect onto timeline clip | Implemented in browser prototype | Native floating panel docks not implemented |
| Native color/blur/stylize FFmpeg effects | Export verified | Preview approximation, no GPU/HDR processing |
| Audio filters (HP/LP/compressor/echo) | Export verified | Browser preview does not monitor DSP chain |
| Video/audio edge fades | Export verified | No two-clip cross dissolves |
| Procedural slide in/out | Export verified | Simplified 2D animation only |
| Duplicate selected clip | Backend + UI integrated | Does not auto-ripple overlapping clips |
| Track-local ripple delete | Backend + UI integrated | Rejects overlaps; affects one track only |
| Split inside nested composition | Backend + UI integrated | Native GUI testing incomplete |
| Local AI captions | Previously implemented adapter | Real model weights not validated here |
| Full Premiere / After Effects / Resolve parity | Not implemented | Long-term multi-year development target |
| Shared GPU renderer / Qt/C++ migration | Not implemented | FFmpeg + HTML preview technical prototype |

# Matriz de recursos: visão profissional versus protótipo (v0.3)

**Estados:** ✅ implementado em v0.2.0/v0.3.0; ◐ limitado/em desenvolvimento; ☐ não implementado. Esta matriz é um **roadmap**, não um inventário de funções já disponíveis.

## Projeto e mídia

| Função | Estado | Próxima exigência | 
|---|---|---|
| Criar/abrir/salvar projeto | ✅ | Migração de schema e arquivos relativos |
| Recuperação automática de projeto | ✅ | Checkpoints múltiplos e proteção contra corrupção |
| Importação de arquivos por seletor | ✅ | Suporte a pastas, ingest em lote, metadados |
| Stream de vídeo no monitor | ◐ | Decodificação nativa de codecs profissionais |
| Relink de arquivos offline | ☐ | Busca por nome, hash e metadados |
| Media bins/pastas, smart collections | ☐ | Busca avançada e marcadores |
| Proxy/media optimized | ☐ | Worker paralelo, swap, limpeza |
| Thumbnails e waveforms em cache | ☐ | Cache com invalidação confiável |
| Metadados técnicos e LUTs de câmera | ☐ | Metadados ICC/EXIF/XMP e RAW |
| Logs de render e histórico persistente | ☐ | Logs exportáveis e comparáveis |
| Backup portátil/consolidação de mídia | ☐ | Relocação, archive, relink |

## Timeline e edição

| Função | Estado | Próxima exigência |
|---|---|---|
| Camadas de vídeo e áudio | ✅ | Tracks ilimitadas/dinâmicas e grupos |
| Inserção por duplo clique/drag | ✅ | Insert/overwrite modes |
| Mover, cortar e apagar clipes | ✅ | Testes de edge cases e source mapping |
| Trim pelas bordas | ◐ | Ripple/roll/slip/slide modes confiáveis |
| Marcadores e timecode | ◐ | Marcadores de timeline e media |
| Snapping | ◐ | Snap real para boundaries/playhead/markers |
| Undo e redo | ✅ | Comandos granulares transacionais |
| Lock e mute de faixas | ✅ | Solo, sync locks e track targeting |
| Zoom temporal | ✅ | Escalas, scroll/zoom com mouse e minimap |
| Multi-sequence e nested sequences | ◐ | Nest recursivo, editor e export real; faltam semântica de fps diferentes, transparência/preview paritário e caching |
| Compound clips/grupos/parenting | ☐ | Hierarquia de transform e locking |
| Linked audio/video robusto | ◐ | Unlink/relink com edições sincronizadas |
| Multicam editing | ☐ | Sync por TC/áudio e angle switching |
| Transitions e handles | ☐ | Dissolves reais e gerenciamento de overlapping |
| Time remapping/speed curves | ☐ | Frame sampling e áudio retimed |
| Reverse/freeze/optical flow | ☐ | Render frame-exact e fallback |
| Captions/subtitles SRT/ASS | ☐ | Timeline de textos e styling |
| Multi-user/editorial collaboration | ☐ | Merge/conflict handling |

## Animações e composição

| Função | Estado | Próxima exigência |
|---|---|---|
| Inspector numérico por clipe | ✅ | Editor unificado de propriedades de efeitos |
| Animação posição X/Y | ✅ | Testes precisos preview vs export |
| Interpolação linear/hold/ease | ✅ | Ease representa smoothstep, não Bézier livre |
| Keyframes no gráfico | ✅ | Eixos, tangentes customizadas, multiseleção |
| Escala/rotação/opacidade estáticas | ✅ | Compatibilidade color alpha |
| Outros keyframes na prévia | ◐ | Mesma avaliação no renderizador |
| Bezier customizado com handles | ☐ | Tangentes XY, velocity graph |
| Pivot/anchor/parent transform | ☐ | Hierarquia 2D e 3D |
| Motion blur | ☐ | Integração subframe, shutter angle |
| Curvas de animação reutilizáveis | ☐ | Assets de animação e templates |
| Matting e máscaras com spline | ☐ | Feather, invert, tracking, combine |
| Luma/chroma key | ☐ | Keyer de alta qualidade e despill |
| Blending (multiply/screen/add) | ☐ | Ordem e premultiplied alpha |
| Text/shape layers/expressions | ☐ | Typeface, ligatures, 2D vector engine |
| Adjustment layers | ☐ | Escopo espacial e temporal em faixas |
| Editor visual de nós | **NUNCA** | Explicitamente excluído por diretriz do produto |
| Composição 3D/câmera/luzes | ☐ | Biblioteca 3D e GPU |
| Partículas, motion tracking | ☐ | Solver e cache |

## Correção de cor e formatos

| Função | Estado | Próxima exigência |
|---|---|---|
| Brilho/contraste/saturação | ✅ | Transformação em espaço de cor definido |
| Blur gaussiano | ✅ | Paridade parametrizada, GPU |
| Curvas RGB/Y, Hue vs Hue/Sat | ☐ | Grade, LUT, scopes |
| Color wheels/primaries/secondaries | ☐ | Ferramentas de colorista |
| OCIO/ACES, HDR10, Rec.2100 | ☐ | Pipeline de cor 32-bit float |
| Color match/shot match | ☐ | Estatística de cor e gerenciamento de looks |
| Scopes waveform/vectorscope/parade | ☐ | GPU + color pipeline |
| Material RAW/10-bit/12-bit | ☐ | Decoding/debayer conforme licenças |

## Som

| Função | Estado | Próxima exigência |
|---|---|---|
| Múltiplas faixas de áudio | ✅ | Mixagem mais precisa e buses |
| Volume estático por clipe | ✅ | dB, automação, peak meter |
| Playback áudio na prévia | ◐ | Sincronização garantida por clock de áudio |
| Mixer com buses/solo/mute/pan | ☐ | Motor de áudio com latência compensada |
| EQ, compressores, limiter, gate | ☐ | Plugins base + presets |
| Fades, crossfades, automation | ☐ | Curvas de volume renderizadas |
| Sync por forma de onda | ☐ | Fingerprinting |
| VST3/LV2/AU plugin host | ☐ | Versionamento, sandbox |
| Loudness EBU R128/ITU BS.1770 | ☐ | Medição e conformidade |

## Plugins, render e manutenção

| Função | Estado | Próxima exigência |
|---|---|---|
| Export MP4/H.264/ACC | ✅ | Parametrização de bitrate/cores/canais |
| Sequência VFR/CFR e múltiplos FPS | ◐ | RationalTime e PTS/DTS consistente |
| Renderização de todas as propriedades animadas | ☐ | Pipeline compartilhado com preview |
| Suporte OpenFX | ☐ | Host e discovery |
| Host de plugins proprietários Premiere | ☐ | Compatibilidade não garantida, avaliar legalidade/SDK |
| Plugin API próprio | ☐ | ABI/SDK versionados |
| Presets arrastar/aplicar/compartilhar | ☐ | Schema e migration |
| Export ProRes/DNxHR/EXR/image sequences | ☐ | Opções e testes de conformidade |
| Fila de render/background | ◐ | Cancel/pause/resume, prioridade |
| Aceleração hardware GPU | ☐ | Testes macOS/Windows/Linux |
| Intercâmbio OTIO/EDL/AAF/XML | ☐ | Roundtrip confirmado por teste |
| Configurações de atalhos/workspaces | ◐ | 16 atalhos customizáveis, presets incluindo Effects, resize; faltam docking/tabbing/flutuação nativa e perfis importáveis |
| Acessibilidade e HiDPI | ☐ | Testes em múltiplos dispositivos |
| Automated render regression | ◐ | Corpus de codecs e comparação de pixels |
| Distribuição Windows/macOS/Linux | ◐ | Scripts experimentais, builds/release não verificados |

## Critérios de aceitação antes de chamar o editor de "profissional"

1. Um projeto de pelo menos 1 hora, com 4K, áudio em múltiplas faixas, composição e efeitos, deve abrir, reproduzir com proxies e exportar sem erro em hardware definido.
2. Imagem e áudio na preview devem corresponder ao resultado exportado dentro de tolerâncias mensuráveis; testes de render automatizados com referência.
3. Undo/redo, trim e keyframes não podem corromper tempo de origem, mídia vinculada nem projeto serializado.
4. Projetos devem sobreviver a falhas de aplicativo e mídia offline; backups e relink confiáveis.
5. Testes com editores críticos, cobrindo fluxos Premiere/Resolve representativos, devem revelar e documentar gaps antes de declarar equivalência.
6. A versão instalável precisa ser reproduzível e licenciada corretamente, incluindo codecs e plugins.

## Legendas automáticas e workspace — atualização v0.3.0

| Função | Estado | Limitação |
|---|---|---|
| Painéis reorganizáveis | ◐ | Troca entre três posições principais; ainda sem agrupamento em abas ou janelas destacáveis |
| Redimensionamento e altura de timeline | ✅ | Persistência do layout no computador; testar telas pequenas |
| Presets Editing/Color/Audio/Captions | ✅ | Apenas redimensionam áreas; não são suítes de edição distintas |
| Legenda manual por quadro e faixa CC | ✅ | Sem arraste fino para alteração de bordas na timeline |
| Legendas automáticas locais | ◐ | Adaptador assíncrono mais modelo opcional; não testado com pesos reais |
| Ajuste texto/tempo | ✅ | Edição por campos; faltam formas de onda e handles |
| Exportação SRT/VTT | ✅ | Testada na lógica de geração |
| Gravação de legendas no MP4 | ◐ | Render teste Linux passou usando FFmpeg/libass; sem validação Windows |
| Identificação de falantes | ☐ | Pesquisar alinhamento e modelos locais |
| Legendas por palavra / karaoke | ☐ | Falta alinhamento temporal palavra a palavra |
| Modelos GPU AMD/Vulkan | ☐ | Avaliar whisper.cpp/Vulkan e testar em hardware |
| Efeitos de áudio/cor/transições nativos profissionais | ☐ | Design definido em PRODUCT_VISION; ainda não implementado |
| Interface definitiva Qt6/MLT | ☐ | Prévia segue HTML/JS e Python/FFmpeg |

Para escopo detalhado de After Effects, consultar **`docs/AFTER_EFFECTS_PARITY_AUDIT.md`**. Não afirmar paridade integral.

## Atualização da avaliação de efeitos — v0.5.0

O inventário de efeitos do Premiere 26.0 e o status das novas implementações estão em `PREMIERE_26_AUDIT.md` e `PREMIERE_26_CATALOG.json`. A biblioteca real cresceu de 17 para 49 itens, e a suíte alcançou 47 testes. Isso **não altera** os status pendentes do renderizador GPU, da prévia colorimetricamente fiel, das transições entre clipes, do gerenciamento de cor HDR e dos parâmetros de efeitos animáveis. Ver `TEST_REPORT_v0.5.0.md`.
