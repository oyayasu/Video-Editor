# Meridian — Auditoria de abrangência Premiere + After Effects + Resolve

**Pesquisa inicial ampliada: 17/10/2026. Documento vivo.** Este é um inventário de metas e lacunas, **não** uma declaração de compatibilidade ou equivalência com Adobe After Effects, Premiere Pro ou DaVinci Resolve. Para cada função exigimos uso real, resultados renderizados e testes, não apenas UI.

## Fontes primárias (documentação de fornecedores)

- Índice oficial atualizado de funcionalidades do After Effects: https://helpx.adobe.com/after-effects/desktop.html
- Lista oficial dos efeitos de fábrica, com suporte por profundidade de cor, GPU e multiquadro (13/05/2026): https://helpx.adobe.com/after-effects/desktop/apply-effects-and-animation-presets/effects-and-animation-presets/effect-list.html
- After Effects 26.5, novidades de setembro de 2026: https://helpx.adobe.com/after-effects/desktop/what-s-new/whats-new.html
- Pré-composição, aninhamento e pré-render: https://helpx.adobe.com/br/after-effects/desktop/work-with-compositions/precomposing-and-nesting/precomposing-nesting-pre-rendering.html
- Editor de curvas de velocidade: https://helpx.adobe.com/after-effects/desktop/animate-in-after-effects/speed-between-keyframes/speed.html
- Expressões: https://helpx.adobe.com/after-effects/desktop/work-with-expressions/expression-basics/expression-basics.html
- Renderizador 3D avançado: https://helpx.adobe.com/br/after-effects/desktop/work-with-3d-composition/advanced-3d-renderer/advanced-3d-renderer.html
- Nest no Premiere: https://helpx.adobe.com/premiere/desktop/edit-projects/edit-nested-sequences/about-nested-sequences.html
- Personalização de atalhos no Premiere: https://helpx.adobe.com/premiere/desktop/get-started/keyboard-shortcuts/customize-keyboard-shortcuts.html
- Workspaces no Premiere: https://helpx.adobe.com/br/premiere/desktop/get-started/tour-the-workspace/change-create-reset-workspaces.html
- Treinamento oficial do Resolve, incluindo vídeos e projetos de exemplo: https://www.blackmagicdesign.com/br/products/davinciresolve/training/

## Contrato de experiência

- Dois ambientes principais: **Edit** (montagem) e **Effects** (camadas, keyframes, composição, animações), compartilhando projeto e recursos; painéis **Color**, **Audio**, **Captions** podem ser layouts próprios.
- **Nunca exibir editor de nós**, nem mesmo opcional. Ordem de efeitos é uma pilha editável; dependências são resolvidas internamente pelo motor e não apresentadas como grafo de trabalho.
- Docking, undocking, tabs, segundo monitor, layouts, escala HiDPI e atalhos personalizáveis e exportáveis. Presets Premiere-like para facilitar migração, sem copiar assets gráficos proprietários.
- Efeitos próprios controlados por parâmetros, preview idêntico ao export, elementos animáveis, máscaras e presets intercambiáveis. Um motor de renderização separado do editor de montagem será necessário para 3D/VFX completos.
- Software gratuito e de código aberto, processamento local e opção de modelos de legenda IA offline; não significa que cada módulo já exista.

## 1 — Fundamentos de composição e layers

| Recurso | Situação v0.3 | Critérios de compatibilidade funcional |
|---|---|---|
| Sequências múltiplas e pré-composições (nest) | ◐ | Referências reutilizáveis, editor de conteúdo e recursão sem ciclos; duração/trim consistente |
| Pre-compose / nest de seleção multifaixa | ◐ | Preservar offsets e áudio, voltar à origem, instâncias atualizadas e export correto |
| Alpha de composições aninhadas | ◐ | Export intermediário ProRes 4444 alfa; testar halo, colorimetria e masks; preview ainda divergente |
| Composições com fps/tamanho diferentes | — | Converter racionalmente timestamps, ajustar pixels e pixel aspect ratio |
| Ordem de render, preservação de transformações e collapse transformations | — | Semântica consistente, com controle de alpha premultiplicado |
| Layers de vídeo, áudio, imagem, texto, forma, sólido e ajuste | ◐ | Vídeo/áudio iniciais; o restante precisa de implementação |
| Layers 3D, câmeras, luzes, objetos nulos e guias | — | Parenting, espaço local/mundo, render e gerenciamento de hierarquia |
| Blending modes e layer styles | — | Multiply, screen, overlay, add, difference, shadows e emboss sob cor linear |
| Track matte: alpha/luma, invert, referência de qualquer layer | — | Uso transversal sem UI por nós |
| Máscaras Bézier, feather, expansão e múltiplas máscaras | — | União, interseção, subtração, inversão e animação de caminhos |
| Efeitos por camada, grupos, presets e ordem | ◐ | Controles atuais são fixos; precisa biblioteca versionada de efeitos e pilha geral |
| Parenting e pick-whip sem nós | — | Hierarquia de transformações, múltiplos níveis e restrições de dependência |
| Undo, redo, história e edição destrutiva/não destrutiva | ◐ | Persistir ações atômicas de mais recursos, testes de corrupção |

## 2 — Animação e motion design

| Recurso | Situação | Teste exigido |
|---|---|---|
| Keyframes por propriedade; hold/linear/ease | ◐ | Exibir e armazenar curvas; apenas X/Y são exportadas atualmente |
| Bézier temporal e espacial: handles, auto, contínua, roving | — | Resultado igual no gráfico, no monitor e no render por subquadro |
| Editor de curvas de **valor** e **velocidade** | ◐ | Gráfico rudimentar de valor, falta velocidade e tangentes precisas |
| Time stretch, time remapping, reverse, freeze, optical flow | — | Pitch/áudio e amostragem exata, quadros de origem |
| Motion blur/ shutter angle, frame blending | — | Acumulação subframe, cache e testes de ghosting |
| Nulls, parenting, controllers, constraints, rigging | — | Composição procedural reproduzível, sem ciclos |
| Expressões (wiggle, time, valueAtTime, links, random) | — | Runtime sandboxed, cache consistente, APIs documentadas, tratamento de erros |
| Animate text por caractere, palavra e linha | — | Kerning, fontes variáveis, scripts RTL, Unicode, ligaduras |
| Selectors de texto / tracking / ranges / typographic styles | — | Animação de tipografia com layout estável |
| Motion graphics templates e propriedades expostas | — | Presets parametrizados reutilizáveis e exportáveis |
| Shape layers e operações vetoriais | — | Path, ellipse, rectangle, trim paths, repeaters, taper, offset, merge |
| Puppet animation, deformações e pinning | — | Interpolação de malha, rigs, persistência de pins |
| Guias, régua, snapping, referências e alinhamento | — | Alinhamento de objetos, padding e grades responsivas |
| Data-driven animation (CSV, JSON, gráficos) | — | Atualização reativa e fonte segura |

## 3 — Tracking, máscaras e IA de VFX

| Recurso | Situação | Teste exigido |
|---|---|---|
| Point / planar tracking e estabilização | — | Occlusão, motion blur, tracking corners |
| Camera tracking 3D / solve | — | Erro de reprojeção, câmeras/luzes extraídas |
| Face tracking | — | Marcos faciais e consistência temporal |
| Mask tracking | — | Rotação, deformações, inversão, render batch |
| Roto Brush e refinamento de bordas | — | Máscaras temporais por rotoscopia, hair detail |
| Matte de objetos por IA (recurso 2026) | — | Modelo local, cache em disco e correções manuais |
| Object removal / Content-Aware Fill | — | Oclusão, inpainting temporal e controles de qualidade |
| Chroma key / despill / luma key | — | Borda transparente, sampling, spill suppression |

## 4 — Composição 3D

| Recurso | Situação | Teste exigido |
|---|---|---|
| Camadas 2.5D e câmera com DOF | — | Câmera ortográfica/perspectiva, bokeh, motion blur |
| GLTF / GLB / OBJ / FBX import | — | Materiais, normais, animação, escalas |
| Meshes parametrizadas, objetos e extrusão de texto/formas | — | UV, luzes e sombra, antialiasing |
| IBL/HDRI, materiais PBR, sombras, reflexões, ray/path tracing | — | Paridade de imagem em espaço linear/ACES |
| 3D render GPU e compositor 2D/3D | — | Profundidade, passes AOV, Cryptomatte, caches |
| VR/360/180 e estéreo | — | Projeções, metadata e export |

## 5 — Catálogo dos efeitos de fábrica (famílias)

**Este quadro referencia a lista atual da Adobe; não declara equivalência.** Algumas ferramentas marcadas como implementadas no protótipo são simples aproximações, não correspondem necessariamente ao algoritmo e às opções do efeito original.

| Categoria do After Effects | Exemplos de efeitos/funções a cobrir | Estado Meridian |
|---|---|---|
| 3D Channel | Cryptomatte, depth matte, ID matte, extrator, neblina, DOF | — |
| Audio | EQ, chorus/flanger, delay, reverb, stereo, tone, filters | — (volume simples) |
| Blur & Sharpen | Gaussian, directional, box, camera lens, radial, vector blur, sharpen | ◐ (blur básico) |
| Channel | Alpha math, channel mixer, invert, set channels, remove matte | — |
| Cinema 4D | Importe/composição de assets externos C4D e equivalentes funcionais | — |
| Color Correction | Curves, levels, exposure, vibrance, HSL, lumetri-like, secondary correction | ◐ (brightness/contrast/saturation básicos) |
| Distort | Warp, displacement map, mesh, bezier, bulge, polar, turbulence, wave | — |
| Generate | Gradient, fractal, fill, lens flare, lightning, beam, checkerboard, grid, spectrum | — |
| Keying | Keylight-like key, luma, difference, extract, color range, spill | — |
| Matte | Matte choker, refine alpha, color matte, simple choker | — |
| Noise & Grain | Add/remove grain, fractal noise, temporal denoise, dust, median | — |
| Perspective | Drop shadow, bevel, CC sphere/cylinder, 3D glasses | — |
| Simulation | Particles, snow, rain, bubbles, caustics, shatter, waves | — |
| Stylize | Glow, posterize, roughen edges, emboss, pixelate, mosaic, find edges | — |
| Text | Numbers/timecode, além das ferramentas de tipografia | — |
| Time | Echo, posterize time, time displacement, pixel motion blur | — |
| Transition | Linear wipe, radial wipe, Venetian blinds, iris, gradient, block dissolve | — |
| Utility | HDR compander, grow bounds, LUT compatibility, color conversion | — |
| Immersive video | VR blur, 360/180 tools, projection transforms | — |
| Third-party and obsolete effects | Não prometer compatibilidade proprietária; mapear substitutos e plugins abertos | — |

**Critério obrigatório por efeito:** parâmetros detalhados, defaults, limites, suporte a alpha, order of operations, interpolação, color space, edge handling, 8/16/32 bpc, CPU/GPU, cachê, multithreading, teste de render, presets e documentação. Uma lista de nomes em uma aba de efeitos **não é** implementação.

## 6 — Montagem (Premiere + Resolve Edit)

- Timeline com track targeting, sync lock, multiseleção, sequência aninhada, insert/overwrite, ripple/roll/slip/slide, stretch e dynamic trim.
- Cut, razor, snapping sem drift, playhead subframe, timecode/drop-frame, JKL playback, teclas personalizáveis e perfis múltiplos.
- Transições com handles, easing editável, perfis armazenados, paste attributes, adjustment layers, motion graphics templates, bins/pastas inteligentes, organização/etiquetas, markers e metadata.
- Multicam com TC e waveform sync; proxy generation e reconform; VFR/CFR; scene detection; conform EDL/OTIO/AAF/XML; relinking, collect project, source monitor e comparison viewer.
- Monitor color-managed, overlays de zona segura, scopes, alt frames, GPU cache, safe-area guides, render preview, work area, batching e render queue.

## 7 — Cor e áudio (Resolve Color / Fairlight)

- Gestão OCIO/ACES, HDR, gamut mapping, LUTs, curvas, wheels, log, keyers, tracking e qualifiers, scopes waveform/vectorscope/parade, split screen, still reference, matching, shot tracking.
- Motor de áudio com 48/96k, buses, pan, surround, EQ, compressor, gate, limiter true peak, transient control, de-esser, denoise, Fades, loudness LUFS/R128 e automações sample-accurate. Formatos VST3/LV2 só após suporte nativo confiável.

## 8 — Legendas e IA

- Whisper local CPU/GPU (escolha por testes, não marketing), alinhamento por palavra, diarização, edição de timing, fonte, contorno, sombra, highlight/karaokê, posição segura, SRT/VTT/ASS e burn-in / soft subtitles; tradução local opcional com modelo/licença compatível.
- Exigir benchmarks WER/CER com corpus de fala PT-BR, EN e JP; não prometer precisão absoluta. Instalador deve permitir evitar pesos grandes.

## 9 — Arquitetura exigida para a ambição

O FFmpeg e MLT são úteis, mas sozinhos **não fornecem** um equivalente completo ao renderizador do After Effects. Precisaremos de compositor 2D/3D próprio em C++/Qt com processamento 32-bit float, modelos de cena em camadas, render por tiles/frames, cache de memória e disco, execução CPU/GPU com fallback, plugin API com versionamento, preview/export compartilhados, e motor de áudio separado com sincronização precisa. Internamente pode existir agendamento de dependências; a UI jamais terá nós.

### Status v0.3 (teste de engenharia, não release profissional)

- [x] UI com escolha de workspace Edit ou Effects (presets; **ainda sem motor Effects separado**)
- [x] Personalizar 17 comandos com detecção de conflito e arquivo persistente por instalação
- [x] Criar nest a partir de clipes selecionados, navegar para dentro e retornar
- [x] Gravar composições aninhadas (inclusive dois níveis) com vídeo, áudio e alpha ProRes 4444 intermediário, testadas com FFmpeg
- [x] Validação recursiva que rejeita ciclos e IDs inexistentes
- [ ] Transformações de nested layers na prévia idênticas às da exportação
- [ ] Mídia com fps diferente, todas as ferramentas compostas, alpha premultiplicado preciso e caixas de duração editáveis
- [ ] Painéis realmente destacáveis Qt, janelas independentes e múltiplos monitores
- [ ] Efeitos nativos avançados da tabela, texto, 3D, rastreamento, plugins profissionais

Não há estimativa de conclusão global defensável sem equipe, benchmark, prototipação C++ e matriz de testes multiplataforma. O objetivo de máxima abrangência é mantido, com implementação incremental e evidência verificável por recurso.
