# Effects workspace v0.14.0 — research and truthful implementation status

## Upstream primary references (reviewed October 2026)

- Adobe: complete After Effects effect list, revised May 2026, including GPU, bit-depth and MFR metadata: https://helpx.adobe.com/br/after-effects/desktop/apply-effects-and-animation-presets/effects-and-animation-presets/effect-list.html
- Adobe: Stylize effects (Glow, Emboss, Mosaic, Threshold): https://helpx.adobe.com/after-effects/desktop/apply-effects-and-animation-presets/list-of-effects/stylize-effects.html
- Adobe: Blur & Sharpen reference: https://helpx.adobe.com/br/after-effects/desktop/apply-effects-and-animation-presets/list-of-effects/blur-sharpen-effects.html
- Adobe: Distort effects reference: https://helpx.adobe.com/br/after-effects/desktop/apply-effects-and-animation-presets/list-of-effects/distort-effects.html
- Adobe: Track mattes and traveling mattes: https://helpx.adobe.com/after-effects/using/track-mattes-and-traveling-mattes.html
- Adobe: mask tracking: https://helpx.adobe.com/after-effects/using/rigid-mask-tracking.html
- Adobe: AI Object Matte: https://helpx.adobe.com/br/after-effects/desktop/roto-brush-and-refine-matte/roto-brush/object-matte.html
- FFmpeg libavfilter documentation: https://ffmpeg.org/ffmpeg-filters.html

**This research is used only to establish requirements. No Adobe binaries,
plugins, proprietary UI graphics, template files or source code are copied.**
Meridian effects are original parameterizations and processing graphs using
FFmpeg, **not** 1:1 algorithmic recreations of Adobe's implementations.

## Implemented now

18 new video effects (67 total effects in Meridian, plus 13 timeline transitions):

- AE · Color Correction: Exposure (SDR LUT), Sepia Tone, Shadow / Highlight approximation, Monochrome Tint.
- AE · Channel: RGB Channel Gain, RGB Color Separation.
- AE · Blur & Sharpen: Directional Blur Horizontal/Vertical (spatial, **not motion-vector blur**), Box Blur, Smart Blur, Median Noise Filter.
- AE · Stylize: Threshold, Emboss, Edge Detection, Glow / Bloom.
- AE · Distort: Bulge / Pinch (radial lens approximation).
- AE · Noise & Grain: Fine Film Grain.
- AE · Perspective: Drop Shadow for transparent imagery and title layers.

Glow and Drop Shadow are *branching* operations using multiple FFmpeg filter streams.
The render graph now follows the effect stack order, including the existing
single-input effects, before the layer's transform and alpha matte stages.

**Geometric alpha masks:** up to 16 per video clip, rectangle or ellipse,
normalized position/size, invert, feather, opacity and ordered Add/Subtract/
Intersect. Masks are independent of effects and can be used to create layered
composites with overlapping footage. Existing alpha is multiplied by the mask
(so a chroma key's transparency isn't discarded).

User interaction: workspace Effects -> Effects library and Inspector -> Layer
Masks. The Inspector provides numeric controls and undo/redo via the existing
project transaction flow. Clips are still stored in `.meridian` schema v1;
older projects without `masks` remain valid. In nested comps masks are stored
on child clips and rendered by the FFmpeg intermediate processing route.

## Current limitations — NOT IMPLEMENTED

- Real-time monitor parity with export; **use FFmpeg Stable / Render frame**
  to inspect exact masks, Glow and Drop Shadow. The browser preview does not
  render the complete effect graph.
- Node editor: intentionally not part of Meridian.
- Freehand Bézier mask path editing, mask animation/tracking, roto brush / AI
  subject matte, clean plate, track mattes from another layer, parenting,
  optical flow and 3D camera tracking.
- Text engine with live editable typography and per-character expressions;
  3D layers, lights, camera, particle simulations, true temporal motion blur.
- Full HDR, 16/32-bpc float effects and exact Adobe color management / GPU parity.
- The experimental C++ compositor intentionally rejects layers with masks or
  multi-input Glow / Drop Shadow instead of rendering them incorrectly.
- Some single-input FFmpeg filters run via the experimental decoder, but the
  complete effects pipeline is not validated for parity with FFmpeg Stable.
- No independent Windows .exe or macOS .app has been compiled in this release.

## Architecture and testing

- `src/after_effects_fx.py`: metadata, parameter contracts and original FFmpeg
  filter implementations; two multi-input processors have a named stream graph.
- `src/masks.py`: validated geometric matte model + deterministic FFmpeg alpha
  expression; no arbitrary user-supplied FFmpeg expression or code evaluation.
- `src/render.py`: graph-building refactor: effect stack order is preserved,
  even when the graph branches for Glow/Shadow; geometric alpha applied before
  rotated layer placement. Render frame and MP4 export share this pipeline.
- `web/mask-ui.js`: numeric mask Inspector (Add/Subtract/Intersect, enable,
  invert, feather, opacity, geometry) with compatible persistence and undo.
- `tests/test_effects_v014.py`: registry and range validation, visual alpha
  coverage, reverse matte, actual title shadow on contrasting background,
  real FFmpeg effect rendering and unsupported native path rejection.

See `docs/TEST_REPORT_v0.14.0.md` for exact commands, what was and was not tested.
