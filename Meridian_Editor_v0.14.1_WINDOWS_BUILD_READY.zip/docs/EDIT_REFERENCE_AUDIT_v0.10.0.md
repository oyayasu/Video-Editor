# Meridian Edit — research, coverage, and unresolved professional requirements

**Release:** v0.10.0 • **Status:** technical preview, **not 99% feature-complete**.

## Primary research corpus

These are feature/behavior references, **not** sources from which proprietary UI assets or code were taken:

1. Blackmagic Design — [Edit page overview](https://www.blackmagicdesign.com/br/products/davinciresolve/edit/) and [free certified training including video exercises](https://www.blackmagicdesign.com/br/products/davinciresolve/training/): track-based editing, source/record workflow, dynamic trims, smart bins, multicam, speed ramps, subtitles, Fairlight audio and delivery.
2. Blackmagic Design — [The Editor's Guide to DaVinci Resolve 20](https://documents.blackmagicdesign.com/UserManuals/DaVinci-Resolve-20-Editors-Guide.pdf): detailed editing exercises for trim, multicamera sync, proxy workflow, media organization, subtitles, audio and export.
3. Adobe — [Premiere desktop reference](https://helpx.adobe.com/premiere/desktop.html): project panel, source/program monitors, source patching, trims, multicam, media linking, preview files, color, audio and exporting.
4. Adobe — [source patching and insert/overwrite editing](https://helpx.adobe.com/premiere/desktop/edit-projects/intro-to-editing/add-media-to-the-timeline-using-source-patching.html).
5. Adobe — [rolling edit](https://helpx.adobe.com/premiere/desktop/edit-projects/trim-clips/perform-rolling-edits.html), [slip](https://helpx.adobe.com/br/premiere/desktop/edit-projects/trim-clips/perform-slip-edits.html) and [slide](https://helpx.adobe.com/br/premiere/desktop/edit-projects/trim-clips/perform-slide-edits.html).
6. Adobe — [keyboard shortcut reference](https://helpx.adobe.com/br/premiere/desktop/get-started/keyboard-shortcuts/default-keyboard-shortcuts.html) and [saved custom workspaces](https://helpx.adobe.com/premiere/desktop/get-started/tour-the-workspace/change-create-reset-workspaces.html).
7. Adobe — [track management](https://helpx.adobe.com/premiere/desktop/edit-projects/change-clip-sequence/add-tracks.html) and [timeline clip movement](https://helpx.adobe.com/premiere/desktop/edit-projects/change-clip-sequence/different-ways-to-move-clips.html).

The primary references contain screenshots and training videos; this audit uses behavior descriptions rather than redistributing protected screenshots or source code. **This is not an exhaustive verification of every supported format, shortcut or operation of either product.**

## Newly implemented and checked in v0.10

| Area | Function | Implemented behavior | Remaining limitations |
| --- | --- | --- | --- |
| Media | Offline identification | Detect missing source files on initial load/open; show OFFLINE in media list | No automatic recursive search / checksum matching |
| Media | Relink | Reassign asset path without changing clip references, reject incompatible streams/insufficient duration; re-probe FFmpeg | No batch folder relink, metadata fingerprinting or transcode |
| Track controls | Add / rename / delete empty | Video tracks ordered before audio tracks; IDs stable | No drag-reorder, sync locks, solo, multi-channel routing |
| Source editing | Frame-accurate In / Out trims | Handles validated; source/timeline timecodes and keyframes rebased | Precise easing across a boundary is approximated; no trim preview monitor |
| Source editing | Slip | Changes source in/out without moving clip or animation timeline | Numerical UI, no live 4-up trim monitor |
| Source editing | Roll | Changes shared cut of two touching clips while preserving combined range | No handle dragging / 4-up preview; requires exactly adjacent pair |
| Source editing | Slide | Moves middle clip and compensates adjacent clips | Requires exactly three touching clips |
| Insert/overwrite | Three-point overwrite | Replaces covered time in selected track, splits previously covered clips, preserves untouched handles | Source in/out keyed numerically; does not automatically insert linked audio |
| Insert/overwrite | Three-point insert | Ripples unlocked tracks, splits crossing clips; shifts/splits subtitles and shifts compatible transitions | Refuses locked tracks with later clips; inserts inside nested compositions not yet supported |
| Interaction | Keyboard shortcuts | New commands and partial backwards compatibility with stored mappings | Shortcut table far from full Premiere coverage |
| Safety | Transactional operations | Copy-edit-validate-commit: failed edit leaves project unchanged | Drag-and-drop move still uses older imperative UI code |
| Media rendering | Real output | FFmpeg exported a short actual test clip after insert+overwrite; paused-frame PNG produced | Single short synthetic asset, not professional footage validation |

## Professional Edit acceptance matrix — major blockers

| Capability | Status as of v0.10 | Required before professional release |
| --- | --- | --- |
| Native installable Qt editing application | **Missing** | Signed/installer build, full window docking, accessibility, multi-monitor |
| Source and program monitor with source-mark In/Out | **Missing** | Source preview in all common codecs and patch targeting |
| Exact trim ergonomics | **Partial** | Ripple/roll/slip/slide drag gestures, 2-/4-up monitors, JKL trimming |
| Linked AV and track patching | **Partial** | Link/unlink groups and sample-stable changes across locked/targeted tracks |
| Media bins, smart bins, tagging and metadata | **Missing** | Hierarchy, search, persistent labels, sorting, logging |
| Proxies/optimized media | **Missing** | Generation, relink, full-res parity, cache invalidation |
| Frame-accurate audio/video playback | **Missing** | Native clock, asynchronous decode, low-latency cache, JKL, audio sync tests |
| Multicam and auto sync | **Missing** | Timecode/audio sync, angle viewer, live cut, ISO tracks |
| Speed controls, optical flow, freeze/reverse | **Missing** | Deterministic time mapping and audio retiming |
| Advanced audio editing | **Partial** | Waveforms, clip/track gain staging, proper mixer, automation, meters, loudness |
| Titling / Essential Graphics | **Missing** | Text design, motion graphics, templates, vector overlays |
| Effects, transitions | **Partial** | Existing catalog; many high-end effects absent; parity and GPU still lacking |
| Captions and language | **Partial** | Review workflow, source-language handling, sync quality, auto transcription testing |
| Color management and HDR | **Missing** | ICC/OCIO/ACES, 10-bit, scopes, reference monitoring |
| Media interchange | **Missing** | XML/AAF/EDL/OTIO and verified roundtripping |
| Robust save/recover, history and collaboration | **Partial** | Versioned project migrations, journaling, safe recovery, shared projects |
| Export ecosystem | **Partial** | Format/codecs, alpha, presets, render queue, offline integrity testing |
| Performance and stability | **Unvalidated** | Hours-long multi-track 4K workflows, memory, GPU, crash recovery, profiling |
| Windows/macOS native installation | **Unvalidated** | Real builds and repeated clean-machine install/uninstall tests |

### Release policy

A professional editor cannot be certified by a button count or by passing unit tests alone. **No 99% claim is justified.** A release candidate must cover the acceptance matrix and survive independent real-world testing on Windows/macOS with professional media.

### Architectural decisions

- Continue **without any visual node editor**, including Effects later.
- Keep timeline properties as frame integers; keep source/time mapping in model.
- Centralize edit semantics in `src/editorial.py`; do not duplicate trim/slip/roll/slide business rules in JS.
- Keep the FFmpeg stable render engine as a fallback until native export/preview agree.
- Continue moving toward Qt/C++ and eventually GPU-accelerated compositing; this release does not pretend that migration has happened.
- Keep all feature work free/open source; avoid redistribution of Adobe/Blackmagic proprietary plugins/assets.
