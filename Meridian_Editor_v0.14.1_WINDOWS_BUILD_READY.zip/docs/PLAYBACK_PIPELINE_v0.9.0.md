# Meridian v0.9.0 — transport, cache e codificação por hardware

## O que foi implementado

### Preview por posição de quadro

`POST /api/native-preview-start` valida um projeto, cria uma sessão temporária com token imprevisível e registra `NativeFrameCache`. O monitor chama `GET /api/native-frame/<ticket>?frame=N` e recebe uma imagem JPEG acompanhada do cabeçalho `X-Meridian-Cache: HIT|MISS`.

O leitor usa `NativeTimeline.frame(N)`; essa é a mesma classe C++ CPU / FFmpeg empregada na exportação experimental. O modelo do projeto e o formato `.meridian` continuam inalterados.

- As imagens comprimidas são armazenadas em LRU limitado por **24 MiB por sessão** por padrão, sem gravação persistente em disco.
- Solicitações simultâneas ao compositor são serializadas, evitando leituras concorrentes de um decoder FFmpeg sequencial.
- Para saltos de mais de 12 quadros ou voltas, o compositor reinicializa seus leitores e abre o clipe diretamente no novo ponto de origem. A obtenção desse ponto ainda depende da precisão de seek do codec e de FFmpeg.
- Falha de renderização/encoder descarta o decoder defeituoso e mantém os JPEGs válidos no cache para futuras solicitações.
- O ticket tem 120 segundos de inatividade e a sessão é invalidada ao trocar projeto e composição ou concluir uma edição; `stop` libera arquivos temporários e processos associados.
- O monitor não armazena filas ilimitadas: apenas a solicitação em curso e o número do quadro mais recente requerido. Respostas tardias são descartadas. As imagens convertidas em object URLs são revogadas após a troca.
- Se Pillow estiver instalado, a compressão JPEG e o redimensionamento ocorrem sem iniciar um FFmpeg por quadro. Caso contrário, o FFmpeg continua como fallback, sem uma nova dependência obrigatória.

### Relógio de reprodução

`web/transport-clock.js` centraliza a contagem de quadros em uma origem de tempo do `AudioContext` quando disponível. O relógio permite `start`, `pause`, `reanchor` (seek) e roteamento de elementos de áudio. `web/frame-client.js` busca o quadro mais recente sem tentar compor todos os quadros intermediários atrasados.

**Limite essencial:** os elementos HTML de áudio têm buffering/latência próprios; a contagem usa `AudioContext.currentTime`, não amostras PTS efetivamente apresentadas pelo dispositivo. Isso diminui inconsistências de relógio mas **não é garantia de sincronia audiovisual sample-accurate**, tampouco reprodução de 24/30/60 fps em mídia exigente. Não há áudio nativo de baixa latência nesta versão.

### H.264 por hardware (somente codificação)

`src/hardware.py` testa uma conversão real de um quadro RGBA bruto para saída H.264 através do encoder do FFmpeg, antes de habilitar `native-hw`. `h264_amf`, `h264_nvenc`, `h264_qsv` e `h264_videotoolbox` são avaliados conforme o sistema operacional. A disponibilidade é reavaliada por máquina e cacheada durante a sessão.

A composição continua **C++ na CPU**. A GPU, quando disponível, acelera **somente a codificação H.264**, não os filtros, o processamento RGBA, o decoding, o render das camadas, a colorimetria nem a composição. Não há backend Vulkan/Metal/Direct3D nativo.

## Métricas indicativas da máquina de teste

No teste com o clipe fixture pequeno, projeto 1280×720 e JPEG de 320px de largura, o cache registrou HIT com custo de obtenção inferior ao arredondamento de 0,1 ms. Sem usar Pillow, as seis solicitações MISS apresentaram mediana de cerca de 150 ms; usando Pillow opcional, a mediana da amostra foi ~72 ms. Estes números medem toda a obtenção (decoder nativo + composição + JPEG), são observações de laboratório com primeira abertura fria e **não caracterizam FPS sustentado, desempenho de GPU, resultado em Windows ou um benchmark profissional**.

## Limitações e requisitos de conformidade

- Sem compositor Vulkan / Direct3D / Metal, Qt nativo, HDR ou render em float/linear light.
- Sem preload de mídia, indexação inteligente persistente, proxies automatizados e cache em disco para projetos grandes.
- O botão Render Frame ainda é o teste de correspondência mais confiável entre os caminhos de prévia e MP4 nativo. O stream JPEG é deliberadamente com perdas.
- AV-sync de dispositivo, latência P50/P95 em cenários reais, 4K/60, 10-bit e multicam precisam de medição com o hardware-alvo.
- Codec/decoder e encoders podem depender de drivers e builds específicos de FFmpeg. Uma máquina sem encoder validado mantém a exportação x264 CPU/FFmpeg estável.
- O antigo modo MJPEG "push" da v0.8 foi substituído pelo protocolo de solicitação de quadros; não permanece código obsoleto no pacote v0.9.

## Próxima arquitetura

1. Renderer nativo com API de surfaces/timeline e estratégia de backends específicos por plataforma; começar com Direct3D 11/12 ou Vulkan no Windows, Metal no macOS, sob controle do mesmo frame scheduler.
2. Pipeline de decodificação assíncrona com pool de buffer reutilizável, proxies, cache de disco e invalidação por fingerprint da fonte, com pré-busca priorizada próximo ao playhead.
3. Processamento de áudio nativo com time stamps e um master clock baseado nas amostras apresentadas, evitando múltiplos `HTMLMediaElement` sincronizados por compensações.
4. Harness de paridade por efeito entre preview e export, colorimetria padronizada, VFR, múltiplos codecs e benchmarking cruzado no Windows/macOS.
