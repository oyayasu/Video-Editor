# v0.4.0 — Test report

**41 unit/integration tests passed** on this build host, run by `python -m unittest discover -s tests -v`.

### What is tested

- Previously established document/model validation, undo-compatible nesting, caption round-trip, alpha intermediary, export formats, keyboard configuration.
- New typed effect schema, incompatibility/invalid range rejection, deterministic categorized effect registry.
- Actual FFmpeg export of each built-in video effect and audio effect chain (including fades); basic output-stream verification by FFprobe.
- Duplicate, split and ripple-delete operations, including nested compositions, locked tracks and overlaps.
- Local HTTP server endpoints with real requests to ephemeral loopback test server.
- JavaScript syntax via Node.js; Chromium UI with mocked API data for category filtering and effect-stack interactions. No uncaught JS errors in that scenario.

### Important limitations

- **Not** a pixel-by-pixel verified compositor, GPU/HDR test, multi-OS test, high-FPS/codec matrix, audio loudness QC or regression proof for every legacy interaction.
- Localhost navigation was blocked by the headless Chromium environment; browser tests simulate the API. Python HTTP server integration was tested separately.
- Current audio/video previews do not implement every backend effect, and rendered effects do not yet support animated individual parameters.
- No native executable/installer was produced or tested on Windows or macOS.

### Commands

```
python -m unittest discover -s tests -v
node --check web/editor.js
node --check web/effects-ui.js
```
