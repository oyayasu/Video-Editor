# Adobe Premiere Pro 26.0 — pesquisa de efeitos e plano de paridade Meridian

**Data de referência:** outubro de 2026. **Objetivo:** inventariar os efeitos do Premiere, comparar o alcance do Meridian e orientar a implementação original. Este documento não afirma equivalência visual nem reutilização de código da Adobe.

## Fontes

- [Catálogo e reorganização de efeitos e transições no Premiere 26.0](https://helpx.adobe.com/premiere/desktop/add-video-effects/effects-and-transitions-library/list-of-effects-and-transitions.html)
- [Efeitos modernos e aceleração por GPU no Premiere](https://helpx.adobe.com/premiere/desktop/add-video-effects/types-of-effects/effects.html)
- [Documentação Adobe de efeitos de vídeo e transições](https://helpx.adobe.com/premiere/desktop.html)
- [Biblioteca Adobe de efeitos de áudio, janeiro de 2026](https://helpx.adobe.com/pt/premiere/desktop/add-audio-effects/apply-audio-effects/audio-effects-library.html)

O arquivo `PREMIERE_26_CATALOG.json` apresenta as **327 entradas de pesquisa** com nome, categoria, natureza (efeito de vídeo, transição ou áudio), status na documentação Adobe e vínculo opcional com um efeito Meridian *parcialmente comparável*. **Não é a lista de plugins instaláveis do Meridian.**

| Origem no catálogo | Entradas registradas |
|---|---:|
| Efeitos de vídeo ativos v26 | 90 |
| Transições de vídeo ativas v26 | 81 |
| Efeitos de vídeo legados | 12 |
| Transições legadas | 21 |
| Efeitos de vídeo obsoletos | 6 |
| Transições obsoletas | 14 |
| Efeitos de vídeo removidos na v26 | 62 |
| Transições removidas | 3 |
| Efeitos de áudio **selecionados** do manual 2026 | 38 |
| **Total de entradas pesquisadas** | **327** |

**Nota:** a seção de áudio registra os efeitos identificados na página de referência e não garante um inventário exaustivo de todas as versões ou plataformas. Alguns nomes que reaparecem tanto entre os removidos quanto entre os ativos indicam implementações substituídas com o mesmo nome (por exemplo, `Noise`); isso não é inconsistência do catálogo.

## Estado Meridian v0.5.0

- **49 efeitos, animações e fades utilizáveis**, incluindo os 17 da v0.4.0 e **32 novos** nesta entrega. São oferecidos somente porque possuem parâmetros validados e adaptadores executáveis no exportador FFmpeg.
- Distribuição: **cor, desfoque/nitidez, distorção, máscaras por chave, grão, estilo, transformações, áudio (dinâmica/EQ/restauração/reverberação/modulação/estéreo), animação e fades**.
- A tabela de referência marca equivalentes como `partial_analog_not_exact`, nunca como `full`. Um plugin com o mesmo nome pode gerar resultado visivelmente diferente em outros valores, perfis de cor ou codecs.
- **Transições entre dois clipes não estão implementadas**. Fades de entrada e saída atuam nas bordas de um mesmo clipe; não se deve chamá-los de Cross Dissolve.

## Falhas que impedem paridade profissional

1. **Motor e prévia:** o HTML video do navegador não executa a mesma cadeia de efeitos que o FFmpeg de exportação. Não existe um renderer/framegraph unificado nem aceleração GPU própria, e isso precisa ser corrigido **antes** de proclamar paridade visual.
2. **Profundidade de cor:** todo fluxo deve ter espaço de cor e transfer functions explícitos; HDR, ACES, 10/12/16/32-bit float, LUTs e gerenciamento linear não estão implementados.
3. **Efeitos baseados em análise temporal:** Warp Stabilizer, Auto Reframe, Morph Cut, tracking, denoise temporal sério e object masks exigem análise, cache e novos motores.
4. **Transições de verdade:** Cross Dissolve, Dip to Color, whip/push, luma wipe, motion transitions e VR transitions requerem clipes relacionados, handles, sobreposição/mix e espaço de tempo de composição compartilhado.
5. **Efeitos compostos:** luminosidade via Lumetri completa, Ultra Key multipasso e despill, color match, composições por máscara, iluminação volumétrica, partículas, modelos 3D e projeções VR exigem motores próprios.
6. **Animação:** os parâmetros dos efeitos são estáticos nesta versão; necessitamos keyframes por parâmetro com curvas tangentes, expressões, masks animadas e igualdade prévia/export.
7. **Áudio:** o catálogo oferece DSP inicial via FFmpeg; ainda faltam reverb de convolução com IR, diálogo de alta qualidade, edição espectral, 5.1/Atmos, medição profissional, mixer com buses/sends, automação por faixa e processamento sample-accurate.
8. **Qualidade/precisão:** testes visuais ground truth, espectro/PSNR/SSIM, cenários 4K HDR, correção de falhas por codec/driver e testes de longa duração.

## Ordem de implementação recomendada

- **Marco A:** unificar prévia/export, provar alfa e espaço de cor, consolidar timeline/aninhamentos em uma única representação.
- **Marco B:** transições de duas fontes, efeitos de máscara, recortes, gradientes, keyframes por parâmetro, presets e controles melhores.
- **Marco C:** Lumetri-like controls (primárias, curvas, HSL qualifiers), Ultra-Key-like workflow com despill, blur/glow/perpective com qualidade GPU.
- **Marco D:** estabilização, rastreamento, motion graphics, generativos, IA local, áudio de produção, conform e codecs profissionais.

### Requisitos de aceite para cada novo efeito

Para constar no catálogo **utilizável**, deve existir: entrada única no registry; validação dos parâmetros; comportamento efetivo na exportação; teste de integração; e compatibilidade de projetos anteriores. Para constar como **paridade profissional**, ainda será exigida prévia igual à exportação, avaliação perceptual comparada, comportamento sob keyframes, transparência correta, 8/16/32-bit quando aplicável, teste de hardware e documentação de casos-limite. A v0.5.0 não satisfaz esse segundo nível.

Não distribuímos SDKs proprietários, código do Premiere, marcas, ícones ou recursos gráficos da Adobe. Este inventário é uma especificação de funcionalidades derivada da documentação pública; os efeitos do Meridian são implementações próprias usando interfaces abertas do FFmpeg.
