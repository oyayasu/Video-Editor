# Code audit — Meridian v0.10.0

- New headless edit operations are isolated in `src/editorial.py`. Project mutations use copy–validate–return, so failed operations do not mutate the caller's project.
- UI requests the same backend operations for both numeric trims and completed mouse edge trims. Eliminated legacy JavaScript-side keyframe-rebasing during mouse drag to avoid two sources of truth.
- Source-in/out bounding, locked tracks, nested-container resolution, transition invalidation, keyframe cropping and new media length validation are checked in the model.
- Server changes are limited to `/api/editorial-edit`, `/api/relink-media` and missing-media session/status responses; existing endpoints and `.meridian` schema remain unchanged.
- Stored shortcuts from older versions may be read as partial mappings; missing new commands use client defaults. New saves validate the complete mapping for collisions.
- New source files contain no intentional placeholders that claim unsupported effects or rendering capabilities. Existing v0.9 technical debt is not erased: imperative drag/move logic, HTML preview differences, legacy FFmpeg adapters, coarse AudioContext sync and platform packaging require further work.
- Release artifact excludes caches, build directories and native Linux test binaries. Test fixture is retained so tests can run after extracting the ZIP.
- Static checks: Python compileall and JavaScript `node --check`; no full external static/type analysis or formal security audit was performed.
