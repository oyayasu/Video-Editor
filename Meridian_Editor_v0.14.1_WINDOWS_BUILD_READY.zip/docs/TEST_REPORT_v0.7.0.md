# Meridian v0.7.0 — Validation summary

Date: 2026-10-17. Tested on Linux container with GNU C++ 14, CMake,
Python 3.13 and FFmpeg/FFprobe installed.

**84 automated tests PASS** (`python3 -m unittest discover -s tests -v`,
completed in approximately 37.6 seconds). Includes all 69 preexisting tests;
13 new pure-native/video tests; 2 new real HTTP integration tests.

Native coverage includes:

- Versioned C ABI, clear to opaque black/transparent output, invalid args.
- Correct source-over of straight-alpha layers and transparency retention.
- Pixel bounds clipping, cross dissolve, left wipe and 1:1 fast path parity.
- Affine transform, bilinear filter, clip-local X/Y/scale/opacity animation.
- FFmpeg source decode → native PNG and native MP4/H.264 export.
- Native frame versus native MP4 output color difference check (tolerance
  for lossy codec encoding).
- Real audio track export to AAC and A/V mux.
- HTTP `engine=native` option returning PNG and completing background MP4.
- Legacy pipeline unchanged and regression tests passing.

UI smoke test: Chromium with inline HTML, loaded JavaScript and **mocked
session/API** exercised Effects workspace and render-engine option; zero JS
runtime exceptions observed. Actual Chromium navigation to the local HTTP
server was rejected by this environment (`ERR_BLOCKED_BY_ADMINISTRATOR`).
The API was tested independently using real HTTP requests from Python.

**Not tested:** GPU/Qt/MLT, Windows or macOS native build, very long videos,
variable frame rate corner cases, all 49 video/audio effects through native
engine, alpha and color management at higher bit depth, crash recovery,
24/7 playback, caption burn-in through native engine, security audit.
Do not treat the current experimental renderer as production-ready.
