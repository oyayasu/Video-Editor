# Code audit — v0.4.0

## Refactoring performed

- Removed v0.3's inert **Effects** menu entries. Each item in the new library is a real, typed effect or animation with an FFmpeg export adapter.
- Added one backend catalog (`src/effects.py`) containing metadata, categories, parameter schema, strict validation and rendering adapters. UI consumes that catalog, avoiding duplicated hard-coded lists.
- Split effect-panel behavior into `web/effects-ui.js`, keeping category/search/stack interactions out of the large legacy `web/editor.js` controller.
- Centralized clip splitting in the validated Python model, with a new operation route also used by duplicating and ripple-deleting clips. Removed the parallel JS split algorithm.
- Removed repeated JS construction of blank project documents. The server supplies a freshly validated project.
- Removed unused Python imports (`math`, `value_at`, `traceback`) and the unused `lastPlayback` variable; removed old orphaned `.effect-entry` CSS.
- Avoided repeated effect-graph computation within video/audio filter-chain construction.
- Fixed `media_item()`'s hard-coded 30 fps media duration; imported media now receives the project's FPS.
- Clamped audio effect tails to clip length so effects do not inadvertently extend the mix.
- Maintained version-1 `.meridian` compatibility: `clip.effects` remains an optional list, so previous projects load unchanged.

## What is *not* cleaned / migrated yet

This is a **targeted audit**, not proof of zero dead or unreachable code. Some legacy files are densely formatted, and the original application still combines a browser-based preview with FFmpeg rendering. Critical remaining refactors:

1. Migrate monolithic timeline/controller code into independently testable modules.
2. Replace parallel preview/render implementations with a shared native compositor; effects do not all preview accurately in the browser.
3. Replace workspaces limited to swapping panels with a real docking layout in Qt.
4. Implement GPU renderer, high-depth color pipeline and frame-accurate audio monitoring.
5. Add actual transition overlap semantics (Cross Dissolve, Dip to Color) and keyframe support for effect parameters.
6. Test additional media/codec configurations and use sanitizers/linting in a native C++ build.

## Verification

- `python -m unittest discover -s tests -v`: 41 tests, including real FFmpeg outputs and local HTTP API tests.
- `node --check web/editor.js && node --check web/effects-ui.js`: JavaScript syntax checks.
- Mocked Chromium interface: category browse/search, effects stack add/edit/copy/paste/reorder/delete, no runtime exceptions.
- Browser in this environment blocks navigation to localhost, so the Chromium UI test used a simulated API response. The HTTP tests exercise the actual Python server separately. This is **not** equivalent to full end-to-end native UI testing.

## Scope clarification

A built-in Meridian effect is **implemented in the Meridian application** and translated to the currently bundled FFmpeg processing backend. That does not imply the DSP, blur, color or encoding algorithms were written from scratch, that proprietary Adobe/Blackmagic plugins run in Meridian, or that current effects meet production-grade GPU/HDR requirements.
