# Relatório de validação — v0.11.0

## Verificações aprovadas

- **21 testes específicos** no arquivo `tests/test_source_monitor_v011.py`: persistência e validação de marcas, compatibilidade legada, Insert/Overwrite de uma e duas faixas, não duplicação de ripple, divisa de trechos antigos, legendas, source out exclusivo, três pontos reversos/diretos, quatro pontos inconsistentes, atomicidade em erro, travas/streams incompatíveis e chamadas HTTP reais autenticadas.
- **63 testes de regressão focada**: `test_source_monitor_v011`, `test_editorial_v010`, `test_editorial_http_v010`, `test_nesting_shortcuts`, `test_model` — todos aprovados.
- **39 testes adicionais**: `test_captions`, `test_effects`, `test_premiere_catalog`, `test_timeline_operations`, `test_playback_cache_v09` — todos aprovados.
- `node --check web/editor.js` e `node --check web/source-monitor.js` — sem erros sintáticos.
- Chromium executado com **API simulada**, testando abertura de mídia, alteração de scrub, In/Out, patch simultâneo V1/A1, clique Insert e criação de dois clipes. **Nenhum erro JS** capturado. Captura em `tests/meridian-v0.11-dual-monitor.png`.
- Exportação real com FFmpeg de uma fonte de teste usando In=5, Out=25, Insert em V1+A1: `ffprobe` confirmou **MP4 de 0,666667 s com vídeo e áudio**.

## Limitações de validação

- A suíte monolítica `python -m unittest discover -s tests -q` **excedeu o tempo disponível**; não pode ser marcada como concluída. Os módulos acima foram verificados em lotes separados.
- O Chromium desta infraestrutura bloqueia navegação HTTP para o servidor loopback (`ERR_BLOCKED_BY_ADMINISTRATOR`). Os testes de UI são com API simulada, os testes HTTP são contra o servidor real em Python e a exportação é testada em outro fluxo; não há validação browser→servidor→MP4 automatizada num único teste.
- O próprio computador Windows/macOS do usuário, build `.exe/.app`, performance GPU, decodificação de fontes long-GOP/VFR e áudio profissional não foram validados.
