# Auditoria incremental de código — v0.11.0

- Nova lógica de edição limitada a `src/source_monitor.py`, reaproveitando `apply_edit`, `create_clip`, `editing_container`, `validate`.
- Remove a duplicidade conceitual: três pontos em duas faixas são resolvidos por **um** Insert com ripple + uma colocação validada da segunda stream (ou dois Overwrites isolados). Não faz dois ripples consecutivos.
- A interface não é responsável por recalcular `source_in`, duração, cortes ou cópia de keyframes; esses cálculos continuam em Python.
- Os campos de origem são opcionais no esquema de projeto, preservando retrocompatibilidade. Não há execução dinâmica arbitrária de modelos, scripts ou plugins.
- O endpoint exige token CSRF da sessão e as mesmas regras de loopback; o recurso não acrescenta upload de arquivos nem servidores remotos.
- Não adicionamos bibliotecas de execução nem instaladores nesta versão. O único JavaScript novo é `web/source-monitor.js`.
- Nenhum código proprietário do Premiere/Resolve foi copiado.

**Dívida técnica não resolvida:** o modelo editorial legado permite mover a faixa de vídeo e áudio de uma fonte separadamente após a operação; ainda não existem grupos linked persistentes. A UI continua HTML/Python e a preview da fonte depende do decoder do browser. Parte da lógica de edição em `web/editor.js` fora do novo Source Monitor permanece não centralizada; essa revisão não a alterou para evitar regressões fora do escopo.
