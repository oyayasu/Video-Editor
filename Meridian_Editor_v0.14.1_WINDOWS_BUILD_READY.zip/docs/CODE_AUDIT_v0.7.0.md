# Code quality and dependency audit — 0.7.0

- Continued from 0.6.0, preserving `.meridian` schema 1 and all existing
  effects, tests and stable FFmpeg exporter.
- No native .so/.dll/.dylib, CMake cache, `__pycache__`, `.pyc`, temporary
  media or build artifacts are shipped in the code-only archive.
- C++17 compositor separated into a versioned C ABI, independent of Python,
  FFmpeg and browser UI. No ownership of externally allocated buffers.
- Validation in C++ for pointer, pixel dimensions, opacity, transition and
  affine parameters. Uses bounded integer coordinates to prevent overflow.
- Python `ctypes` binding checks the ABI version before use and copies source
  buffers across the C boundary; no use-after-free from shared pointers.
- Decoder subprocesses are started only for active video clips and disposed
  after they cease being active; temporary files are scoped to export/frame
  functions. Encoder writes frames progressively, not into one full-video RAM
  buffer. Cross-process errors are propagated instead of silently ignored.
- Added an integer-aligned 1:1 compositor fast path to avoid unnecessary
  bilinear filtering in common editing operations.
- The new feature is opt-in (stable FFmpeg remains default). Unbuilt native
  library is detected and the UI option disabled. Burned subtitle requests
  in native mode are refused rather than dropping captions silently.
- Unchanged older Python/UI modules retain technical debt: compact formatting,
  coupled API/render orchestration, missing transaction/rollback semantics,
  insufficient structured logs and limited media codec coverage. This is **not**
  a certification that the whole codebase is free of dead code or defects.
- There is no Qt/C++ editor shell yet; using `ctypes` is a deliberate
  incremental bridge and must eventually be replaced by a native API layer.
