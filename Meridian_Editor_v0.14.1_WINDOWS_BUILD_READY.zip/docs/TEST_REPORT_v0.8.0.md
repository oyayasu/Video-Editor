# Meridian v0.8.0 — resultados verificáveis

Ambiente: Linux x86_64, GCC 14, CMake 3.31, FFmpeg 7.1, Python 3.13, Chromium headless. **Nenhum dispositivo GPU `/dev/dri` disponível e WebGL2 bloqueado** no Chromium do ambiente. Nenhum build de Windows/macOS executado.

## Testes automáticos (89 aprovados, executados por módulo)

| Módulo | Testes | Estado |
|---|---:|---|
| captions | 7 | passou |
| effects | 7 | passou |
| http_api | 9 | passou |
| model | 5 | passou |
| native_compositor | 13 | passou |
| nesting_shortcuts | 10 | passou |
| premiere_catalog | 6 | passou |
| render | 4 | passou |
| timeline_operations | 5 | passou |
| transitions_preview_keyframes | 18 | passou |
| playback_gpu_v08 | 5 | passou |
| **Total** | **89** | **sem falhas nos módulos** |

Todos os arquivos passaram por sintaxe (`python -m py_compile`, `node --check`). A biblioteca C++ compilou e os testes nativos anteriores passaram. O novo fluxo MJPEG produziu JPEGs reais a partir de quadros do compositor C++, e os testes HTTP cobriram autenticação CSRF, retorno multipart, expiração por uso único e cancelamento de sessão.

O browser smoke test usou Chromium com DOM/CSS/JavaScript completos e API simulada, verificando inicialização do projeto, ativação de `C++ · Stream`, fallback de WebGL2 indisponível e **nenhum `pageerror`**. Foi gerada uma captura **com mídia simulada**. O navegador desta infraestrutura bloqueia navegação para o HTTP de loopback; os endpoints HTTP reais foram testados fora do Chromium.

## Não verificado

- O shader WebGL2 **não foi executado em GPU** neste ambiente; apenas sintaxe JavaScript e fallback foram verificados.
- Não foi demonstrada latência sustentada em hardware de usuário nem playback nativo a 30/60 fps.
- Reprodução MJPEG real visual num Chrome/Windows e sincronização labial/AV não foram validadas.
- Desempenho em 4K, 8 camadas, HDR, composição linear e equivalência de cor GPU/CPU não foram validados.
- Não foi executado teste e2e do navegador conectando ao stream HTTP real; browser usa API simulada por restrição da infraestrutura.

## Como reproduzir

```sh
./build-native.sh
python -m unittest discover -s tests -v
node --check web/gpu-preview.js
node --check web/editor.js
```

No Windows, compile via `build-native-windows.bat` e inicie pelo `start-windows.bat`. Não há instalador ou binário do Windows validado neste pacote. Não usar como renderizador de trabalhos críticos sem conferir o MP4 final.
