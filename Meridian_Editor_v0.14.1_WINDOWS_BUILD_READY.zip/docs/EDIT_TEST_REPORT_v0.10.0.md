# Meridian Edit v0.10 — validation results

- **22 model-oriented tests** in `test_editorial_v010.py`: trims, clips with keyframes, slip, slide, roll, insert/overwrite across several clips, locked tracks, nested operations, relink and track management.
- **5 HTTP tests** in `test_editorial_http_v010.py`: actual local server routes for edits, insertion, auth rejection, offline status and legacy shortcut parsing.
- **43-test focused suite** (`test_editorial_v010`, `test_editorial_http_v010`, `test_model`, `test_timeline_operations`, `test_premiere_catalog`) completed with zero errors.
- **15-test nesting/shortcut + HTTP subset** completed with zero errors (overlaps with the focused suite; do not add totals indiscriminately).
- **Real FFmpeg media check**: generated a 2s audiovisual fixture, performed insert+overwrite and exported PNG/MP4. Output MP4 duration ~1.067s, PNG valid, FFprobe confirmed video. This does **not** test audio on all transitions, colorimetric precision, VFR, long-form production or AV sync.
- **Chromium UI smoke test**: document loaded using injected local source and simulated API (network navigation restricted here). Selected clip, trimmed from the UI, slipped, opened 3-point dialog, selected offline media; no JavaScript page errors. This is not a live server+browser end-to-end test.
- **C++17 module**: compiled with CMake/GCC in Linux, source files unchanged from v0.9.
- **Full old test suite**: attempted with native build; exceeded the test runner timeout before a final summary. NOT reported as passed. Shorter target suites passed.
- **Windows EXE/macOS app:** not compiled or validated in this Linux environment. Source package, not an installer.

Project regression policy: backup valuable `.meridian` projects and original source media; complete codec/system testing before using this build for paid/professional work.
