# Arquitetura: Meridian Studio — destino profissional

Status: **arquitetura proposta**, distinta do protótipo v0.2.0. Não descreve componentes inexistentes como prontos.

## Princípios inegociáveis

1. Mídia original nunca é modificada; `.meridian` armazena decisões de edição e referências.
2. Operações temporais e keyframes são indexados por quadros ou timecode racional; nunca por valores `float` de segundos como fonte da verdade.
3. A prévia e a exportação devem chamar a mesma árvore de processamento de imagem e áudio. Divergências são bugs, não diferenças de qualidade toleráveis.
4. Um único modelo de camadas e pilhas de efeitos serve para montagem, composição, cor e animação. **Nunca expor um editor visual de nós**; todas as operações devem ser possíveis com camadas, máscaras, Inspector e curvas.
5. Plugins de terceiros nunca podem corromper o processo editor: considerar execução isolada, APIs versionadas, formatos serializáveis e timeouts.
6. O formato de projeto precisa ter versionamento de schema, migrações, backup atômico, recoverability e mecanismos de relink portátil.
7. Nenhuma promessa de desempenho sem testes em hardware, codecs, durações e cenários determinados.
8. Licenças e distribuição (incluindo codecs e plugins) devem ser auditadas antes de publicação de binários.

## Módulos definitivos (planejados)

```
apps/desktop/           C++20 + Qt6 (Qt Widgets / Qt Quick sob avaliação)
  docks/                layout reconfigurável, painel, workspace e hotkeys
  timeline/             manipulação de clipes, snapping, ripple, trim, slip, slide
  curves/               curvas e tangentes Bézier 2D, unidades e easing
  monitor/              visualizador acelerado, scopes, overlay handles
  inspector/            metadata-driven property editor
core/document/          serialização, IDs estáveis, histórico de operações
core/time/              RationalTime, FrameTime, Sync, timecode DF/NDF
core/media/             probe, source manager, relink, offline/proxy/cache
core/timeline/          sequências, nested sequences, tracks, layers, effects
core/animation/         avaliação determinística e serialização de curvas
engine/mlt/             MLT producers, tractors, playlists, services, consumers
engine/gpu/             shaders, linear float buffers, color management
engine/audio/           tracks, buses, plugin host, waveform, peak cache
interop/otio/           import/export OTIO; testes de roundtrip
interop/edl-aaf-xml/   formatos adicionais conforme viabilidade/licenças
plugins/openfx/         host OFX + sandbox quando possível
plugins/audio/          host de plugins VST3 com licença compatível
plugins/native/         SDK próprio de efeitos/presets com parâmetros tipados e pilhas ordenadas
color/ocio/             gestão OCIO/ACES/Rec.709/Rec.2020 com UI de grade
render/queue/           tarefas, perfis, checkpoint/retry, QC automatizado
tests/                  snapshots, renders de referência, testes de stress
```

## Modelo de edição

- `SourceAsset`: hash opcional, URI, streams, FPS original racional, cores, duração, canais áudio, LUTs/metadados.
- `Sequence`: FPS racional, tamanho, pixel aspect ratio, audio sample rate, color space, drop/non-drop timecode, proxies.
- `Layer/Track`: visibilidade, mute, solo, lock, compositing stack order, parent groups.
- `ClipInstance`: source asset, source in/out, timeline in/out, speed map, track, nested sequence, keyframe parameters.
- `EffectInstance`: plugin ID/version, typed properties, defaults, keyframes, color pipeline stage, undo actions.
- `AnimationCurve`: ordered keyframes com valores e interpolação linear/hold/Bézier, tangentes temporais e espaciais.
- `AudioBus`: routing, gain staging, latency compensation, meters, mute, solo, plugins.
- `History`: comandos reversíveis, event log com checkpoints e autosave transacional.

## Motor MLT: integração-alvo

- `MLT Producer` para arquivos, fontes geradas, stills e grafismos.
- `Playlist` por faixa, com blanks/sources explicitamente modelados.
- `Tractor/Multitrack` para a composição das faixas e transições.
- `Filters` mapeados por metadados do editor; valores avaliados em cada quadro.
- `Consumer` para prévia e export com mesmas propriedades/codec pipeline e tempo.
- `CacheManager` isolado para thumbnails, proxies, waveforms, render preview.
- Renderizações sincronizadas ao frame number, não diretamente ao relógio da UI.

A integração com MLT deve ser prototipada e testada com clipes concorrentes, início negativo, duração fracionária, frames ausentes, timebases misturadas e render comparativo. O protótipo atual **não contém** a implementação desse adaptador.

## Pipeline de efeitos, plugins e segurança

1. Efeitos base: transform, blend, opacity, crop, mask, LUT, 3-way color, text, blur, chroma key.
2. Expor parâmetros como metadados tipados de maneira uniforme: `id/name/type/range/unit/default/animatable`.
3. `FFmpeg` e Frei0r podem servir como implementações iniciais de diversos efeitos; melhor software de referência não significa replicar o SDK proprietário Premiere.
4. Host OFX com descoberta, versionamento e gerenciamento explícito de licenças; VST3 para áudio.
5. Plugins defeituosos devem ter logs individuais e, quando possível, isolamento do processo com supervisão e rollback.
6. Efeitos licenciados de terceiros não serão embutidos sem autorização.

## Aspectos críticos de engenharia

- **Color science:** dados de entrada, linearização, conversão de gamut e gamma, OCIO, saída monitor vs render, alpha premultiplicado.
- **A/V sync:** amostragem, PTS/DTS, 44.1/48 kHz, priming, VFR/CFR, LTC/timecode.
- **GPU:** texture uploads, buffers, Vulkan/D3D12/Metal bridge, zero-copy quando seguro, fallback CPU.
- **Confiabilidade:** interrupção em export, out-of-memory, media offline, undo histórico após abertura, snapshot/backup, monitor de tarefa.
- **Desempenho:** 4K/6K/8K, H.264/H.265 com 10bit, ProRes/DNx, multicam, proxies, compositor cache multi-layer, benchmarks reproduzíveis.
- **Interoperabilidade:** importar e exportar OTIO/AAF/XML somente com tabela explícita de atributos que sobrevivem ao round-trip.
- **Acessibilidade:** navegação teclado, alto contraste, hit areas consistentes, escalonamento de fontes e HiDPI.

## Por que o protótipo atual usa JS e FFmpeg?

O protótipo atual é uma **etapa de especificação executável**: valida as interações de edição, o schema mínimo e a composição real via FFmpeg, antes de investimentos em um aplicativo Qt/MLT compilado. Para o produto final, a camada de apresentação será migrada e o mecanismo FFmpeg CLI será substituído/centralizado no engine MLT. Esse trabalho não está iniciado aqui e é um item de implementação aberto. Não confundir o motor inicial FFmpeg com uma integração já pronta de MLT.

## Revisão de licenças antes de uma versão pública

O código do protótipo está sob GPL-3.0. MLT tem licença LGPL-2.1-or-later (verificar módulos vinculados e bibliotecas), FFmpeg possui configurações LGPL/GPL e requisitos legais em binários, Qt possui múltiplas licenças e obrigações de distribuição, OpenFX e bibliotecas de plugin possuem termos independentes. Evitar inferir que *qualquer* compilação desses projetos seja livre de obrigações. Uma revisão específica deve acompanhar cada release.

## Mudança de requisitos v0.2.0

- Sem interface visual de nós, sob nenhuma modalidade (ver `PRODUCT_VISION.md`).
- Qt6 `QMainWindow/QDockWidget` são a base de pesquisa para layout nativo com painéis móveis/flutuantes e `saveState()/restoreState()`. A prévia HTML implementa apenas arranjos de três painéis + resize, não tabbing e múltiplas janelas.
- Legendas: `src/captions.py` é um adaptador opcional local de faster-whisper, sincronizado à fonte do clipe e persistido no projeto em quadros inteiros. API assíncrona. SRT/VTT e burn-in com libass funcionam no protótipo em Linux; Windows não validado.
- Plugins próprios passam a ter prioridade sobre hosts de plugins de terceiros; os hosts são um mecanismo complementar, não pré-requisito para recursos fundamentais.
- O modelo JSON `schema:1` permanece compatível com projetos anteriores: o campo `captions` é opcional para carregamento e adicionado aos novos projetos.
