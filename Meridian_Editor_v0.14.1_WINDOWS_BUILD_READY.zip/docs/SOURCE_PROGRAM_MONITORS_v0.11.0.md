# Meridian Edit v0.11.0 — Source / Program Monitor

## Escopo entregue

A v0.11 acrescenta um **subsistema de edição de origem**, não a conclusão da área Edit. Os monitores compartilham a janela, mas têm cursores e transportes separados:

- **Source Monitor** abre um arquivo de mídia por vez, permite navegar por frames da sequência, reproduzir, marcar In e Out, limpar pontos, consultar a duração selecionada e escolher destinos de vídeo/áudio.
- **Program Monitor** conserva a prévia da sequência existente e permite definir In/Out de destino para edição de três pontos. O playhead da timeline continua independente do Source Monitor.
- **Insert** abre espaço temporal usando a implementação de ripple do modelo editorial; o deslocamento entre faixas, legendas e transições é aplicado **uma única vez**, mesmo ao inserir áudio e vídeo.
- **Overwrite** substitui os intervalos cobertos exclusivamente nas faixas selecionadas. O modelo preserva trechos não substituídos e recorta seus keyframes.
- **Reverse three-point**: source Out + Program In/Out calcula Source In; **forward three-point**: Source In + Program In/Out calcula Source Out.
- **Conflito de quatro pontos**: duração da origem diferente da duração de destino resulta em erro explícito, nunca ajuste de velocidade silencioso.
- **Sem edição parcial**: o backend trabalha sobre uma cópia profunda e devolve projeto validado. Se a segunda faixa falhar, nenhuma alteração é aplicada ao documento original.
- **Pontos de origem persistentes**: `source_ranges` por ID de mídia no arquivo `.meridian`; versões antigas continuam sendo aceitas. O Out é **exclusivo** internamente para impedir duplicação de frames. O display mostra o último quadro incluído.

## Uso

1. Importe uma mídia, clique duas vezes no item para abri-lo no Source Monitor; arquivos áudio-only também podem ser abertos. O duplo clique num clipe não-nested da timeline abre sua fonte e posiciona a origem no início do trecho.
2. Navegue usando a régua do Source Monitor, seus botões de quadro ou `Shift+←/→`. Marque In (`I`) e Out (`O`) ou use os botões dedicados.
3. Escolha as faixas nos seletores **V** e **A**. Ambas podem ser desligadas, mas a edição exige pelo menos uma ativa. Para a fonte que não possua uma das streams, o controle correspondente fica desativado.
4. Posicione a timeline no quadro de destino, ou marque pontos de sequência usando `Ctrl+I`/`Ctrl+O` (ou os botões no Program Monitor).
5. Clique **Insert** ou **Overwrite** no Source Monitor. Um registro descritivo informa quantos frames e faixas foram editados.
6. Confira na timeline. É possível desfazer pela pilha de Undo existente. Salve o projeto para persistir as marcações de origem.

Atalhos adicionais são configuráveis no editor de atalhos existente. `Shift+Space` reproduz a fonte; `Space` reproduz a sequência. O backend é capaz de preparar um source edit em V1 e A1, por exemplo, de forma atômica, mas **não implementa edição posterior com vínculos A/V como uma única unidade**.

## Arquitetura e invariantes

| Módulo | Responsabilidade |
| --- | --- |
| `src/source_monitor.py` | Validação estrita, solução dos três pontos e source patching transacional. Sem dependência de interface nem de FFmpeg. |
| `src/model.py` | Validação e serialização de marcações da fonte. Esquemas legados continuam aceitos. |
| `src/server.py` | `/api/source-edit` autenticado e de resposta síncrona. |
| `web/source-monitor.js` | Estado de seleção/reprodução da origem, In/Out, patches, transporte, integração com Undo. |
| `web/index.html`, `web/styles.css` | Dois painéis distintos na área Edit, adaptáveis ao dimensionamento dos docks existentes. |

`source_in` é inclusivo; `source_out` e `program_out` são exclusivos. Todos os frames do modelo de edição são inteiros. O backend verifica a disponibilidade real dos handles da fonte usando a política de quantização já adotada pelo Meridian. Os intervalos de clipping seguem a lógica `src/editorial.py` existente; o monitor não tem seu próprio algoritmo de edição concorrente.

## Limitações assumidas

- Prévia da origem ainda usa seeking dos elementos HTMLMediaElement do navegador: **não é um decodificador de precisão sample-accurate/frame-accurate para codecs long-GOP/VFR**. O recorte definitivo utiliza frames do modelo; diferenças de posição percebida podem ocorrer em certos codecs.
- Não há monitor de forma de onda, JKL avançado, shuttle reverso, overlays de safe area, comparação de cortes, playback sincronizado por áudio de precisão profissional, multicam, proxy ou full-color-management.
- Trimming de conteúdo nested: Overwrite suporta container aninhado; **ripple Insert nested não**. Algumas faixas de um projeto legado podem estar bloqueadas, o que bloqueia o Insert se contiverem material posterior.
- Áudio e vídeo podem ser patchados juntos no ato da edição, mas não possuem metadados de *linked selection* para acompanhar cortes futuros.
- Só renderizamos um arquivo por vez no Source Monitor; o estado do cursor da fonte não é persistido (apenas In/Out são salvos).
- UI testada em Chromium com servidor simulado. O Chromium do ambiente bloqueia conexões HTTP loopback reais, portanto teste browser→servidor foi substituído por verificação HTTP real separada e integração de modelo + render com arquivos reais.
- **Não é um `.exe` instalável**, nem um editor finalizado. Precisa de Python/FFmpeg no uso a partir do código. Windows/macOS desktop ainda dependem de validação no hardware de destino.

## Fontes de referência

- Adobe, [Source Monitor e marcações In/Out](https://helpx.adobe.com/pt/premiere/desktop/get-started/source-and-program-monitor-adjustments/set-in-and-out-points-in-the-source-monitor.html).
- Adobe, [Source patching](https://helpx.adobe.com/premiere/desktop/edit-projects/intro-to-editing/add-media-to-the-timeline-using-source-patching.html).
- Adobe, [Three-point edits](https://helpx.adobe.com/ph_fil/premiere-pro/how-to/three-point-edits.html).
- Blackmagic Design, [DaVinci Resolve Editing Reference Manual](https://documents.blackmagicdesign.com/UserManuals/DaVinci_Resolve_10_Reference_Manual.pdf). O manual citado é histórico; comportamentos atuais devem ser conferidos nas versões vigentes.

A implementação é original e usa os conceitos editoriais descritos pelas fontes, **não** componentes ou código proprietário da Adobe/Blackmagic.
