# Meridian v0.9.0 — relatório de validação

**Resultado final nesta infraestrutura Linux: 98 testes automatizados aprovados, 0 falhas.**

- Execução: `python -m unittest discover -s tests -v`; 98 casos, duração aproximada 81 segundos.
- Módulos antigos continuam aprovados (modelo `.meridian`, nests, efeitos, transições, keyframes, exportação real via FFmpeg, HTTP/segurança de sessão e compositor C++).
- Novos testes: LRU e limites de memória, seek aleatório para frente e para trás, recuperabilidade após falha do codificador JPEG, expiração e substituição de sessão, header HIT/MISS, ambos os caminhos de JPEG, comandos HTTP autenticados, relógio Web Audio, cliente sem atualização de quadros obsoletos e probe condicional de encoder H.264.
- CMake compilou `native/compositor.cpp` de uma árvore limpa em Linux (`g++ -std=c++17`, build Release). Compilação Windows/macOS não foi executada.
- `python -m py_compile src/*.py` e `node --check web/*.js` terminaram sem erros.
- Smoke test Chromium com HTML/CSS/JS e respostas simuladas: página inicializou, catálogo carregou, opções de monitor e exportação renderizaram, seleção de codificação por hardware desabilitada sem confirmação e `pageerror=[]`. A captura não é renderização de mídia real; no browser deste ambiente, acessos HTTP de loopback são bloqueados pelo sistema, por isso APIs HTTP foram testadas separadamente em Python.
- `GET /api/native-frame/<ticket>` foi testado com JPEG real, cache HIT e MISS, rejeição de índice inválido e revogação do token após stop.

## Medições ilustrativas

Amostra curta, composição C++ 1280×720, preview JPEG 320 px, dez pedidos (repetições inclusas): MISS mediano ~150 ms usando FFmpeg por JPEG e ~72 ms usando o acelerador Pillow opcional. Cache HIT retornou em menos de 0,1 ms na precisão apresentada. Este é um **microbenchmark**, não uma garantia de reprodução em tempo real nem comparação de qualidade de codificadores.

## Não testado, logo NÃO concluído

- GPU para compor camadas por Vulkan, Direct3D, Metal; CUDA/OpenCL render profissional.
- Hardware H.264 validado em GPU real; a infraestrutura não possui uma GPU adequada.
- Sincronização AV de amostras na saída do sistema, duração de longos projetos, 4K/10-bit/HDR, caches de disco persistentes.
- Windows/macOS nativo, distribuição EXE/.app e instalação assinada.
- Aderência pixel a pixel do preview JPEG (com perdas) e exportação H.264 de todos os efeitos possíveis.

O código disponível não deve ser apresentado como equivalente em recursos, estabilidade ou performance ao Premiere, Resolve ou After Effects.
