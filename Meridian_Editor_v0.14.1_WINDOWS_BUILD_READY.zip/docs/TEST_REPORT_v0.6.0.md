# Validação — Meridian v0.6.0

- Ambiente de testes: Linux, Python 3.13, FFmpeg/FFprobe instalados.
- Suíte completa: `python -m unittest discover -s tests -q` — **69 testes OK**.
- Sintaxe JavaScript: `node --check web/editor.js` e `node --check web/effects-ui.js` — **OK**.
- Testes de transições com mídia de cores sintéticas: dissolve produz mistura intermediária; wipe revela o frame esquerdo antes do direito; as duas saídas exportam para MP4.
- Comparação exata vs saída MP4 em um mesmo frame: tolerância de 15 níveis RGB por canal no cenário de teste; **OK**. Isso não é uma prova global de fidelidade entre codecs, bit depths e efeitos.
- Efeitos animados: diferença fotométrica entre valores de brilho em dois instantes; amplificação de áudio variável ao longo do tempo exportada; **OK**.
- Semântica de documento: projetos sem campo `transitions`, transições inválidas, limites de keyframe, split, nest, exportação e round-trip; **OK**.
- Endpoints HTTP: criação de transição, geração de PNG, validação de token e rejeição de índice de frame fora dos limites; **OK**.
- Interface no Chromium: montagem HTML e execução JS em `about:blank`, com API simulada; seleção múltipla, criação de transição, botão de keyframe e exibição do PNG verificados; **nenhum erro JavaScript**.
- Limitação do teste visual: navegador da sandbox bloqueou navegação HTTP e `file://`, impedindo teste e2e com servidor real; backend e navegador foram exercitados separadamente. Screenshot `Meridian_v0.6.0_Interface.png` foi produzido com backend simulado.
- Não testado: Windows/macOS nativos, C++/Qt, hardware GPU, timeline de longas durações, renderização multi-hora, efeitos HDR, comparações perceptuais de áudio e performance sob clipes de múltiplos codecs.

Captura visual reproduzível no pacote: `tests/meridian-v0.6-ui-mocked.png` (API simulada).
