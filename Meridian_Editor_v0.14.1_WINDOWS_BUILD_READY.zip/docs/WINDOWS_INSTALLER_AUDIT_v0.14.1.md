# Windows distribution audit — v0.14.1

## Implemented in the source tree

- Native PySide6/QtWebEngine window, local-only HTML UI, shutdown of HTTP server.
- Windows-native file picker routed from HTTP worker to GUI main thread.
- Navigation restricted to local editor; HTTPS external links open in system browser.
- Embedded interpreter via PyInstaller **onedir** and wheel-based Qt runtime.
- Embedded FFmpeg/FFprobe from Gyan Essentials with upstream SHA256 check on download.
- Optional Windows C++ compositor DLL included in a successful native build.
- Compiled application smoke test for assets, runtime, local HTTP API, model and effects.
- Windows Inno Setup per-user installer and portable ZIP + SHA256SUMS.
- GitHub Actions workflow to build without dependencies on an end-user PC.

## Not validated here

- Running PyInstaller / Inno Setup on Windows; this session is Linux only.
- QtWebEngineProcess.exe and Qt plugins on a clean Windows computer.
- Qt WebEngine audio/video codecs and GPU drivers on Windows machines.
- Windows installer end-to-end installation/uninstallation.
- Signature/reputation in Windows SmartScreen.
- License compliance audit of precise distributed dependencies.
- All editor features and export formats on packaged runtime.

**No Windows EXE was generated here.** This audit describes source code and
future build steps, not a completed binary distribution.
