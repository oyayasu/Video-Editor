# Meridian — Contrato de produto (17/10/2026)

**Versão:** visão do produto; não equivale a funcionalidades concluídas.

## Definições aceitas

- **NENHUM editor visual de nós**, nem sequer oculto como modo de composição. A interface será baseada em timeline, camadas, pilhas de efeitos, máscaras, pastas/grupos, ajustes, keyframes, curvas e Inspector. Internamente o motor pode calcular dependências sem exibir grafos editáveis; esse detalhe não altera o modelo visual e de interação.
- **Workspace profissional realmente personalizável**: painéis com drag-and-drop, agrupamento em abas, dock/undock, janelas flutuantes, segunda tela, resize, maximização, presets, salvamento, reset e atalhos customizáveis. A prévia HTML permite apenas resize e troca de posição de três painéis, salva layouts e alterna presets. Docking/tabbing/flutuação completos serão parte da interface Qt.
- **Visual moderno e próprio**: referências funcionais de Adobe Premiere Pro, After Effects e DaVinci Resolve, sem reproduzir logotipos, arte proprietária ou marcas de terceiros. Layout escuro, contraste consistente, feedback imediato, alta densidade informacional, HiDPI e acessibilidade.
- **Legendas automáticas gratuitas por IA**: inferência local, nunca cobrança por segundo/minuto, sem exigir assinatura ou conta externa. Primeiro uso pode baixar pesos livres. Foco em precisão e revisão manual; marcas temporais por palavra, idiomas variados, presets visuais, export SRT/VTT, legendas em vídeo, detecção de falantes e conformidade com fps racional serão fases posteriores quando não implementados.
- **Coleção de efeitos e ferramentas próprias, profunda e integrada**: a UX, controles, presets e documentação dos efeitos pertencem ao Meridian. Utilizar algoritmos/bibliotecas de código aberto e interfaces próprias é permitido, respeitando licenças. A qualidade deve ser medida por testes e comparação objetiva, não anunciada como pronta antes disso.
- **Gratuito e open source**: uso local, sem bloqueio por assinatura, versão gratuita artificialmente reduzida ou dependência operacional obrigatória de serviço de terceiros. Respeito à GPL e licenças dos componentes distribuídos.

## Biblioteca nativa pretendida (não implementada)

| Área | Ferramentas a desenvolver | Critérios de qualidade |
|---|---|---|
| Áudio | EQ paramétrico, compressor, limiter true peak, gate/expander, de-esser, fades, reverb, denoise, normalização LUFS, mixer e buses | Conformidade loudness, THD/SNR, zero clipping não-intencional, testes ABX e latência medida |
| Transições | Dissolve, dip to color, luma wipe, directional wipe, push, slide, zoom, blur, motion blur, presets com duração esticável | Sem saltos de frame, brilho e gamma coerentes, easing editável, render determinístico |
| Animação | Anchor/position/scale/rotation/opacity, motion blur, parenting, máscaras, shape/text layers, curvas Bézier com handles e editor inline | Continuidade, interpolação previsível, undo completo, mesmo resultado na prévia e na exportação |
| Cor | Lift/gamma/gain, log wheels, exposição, contraste, temperatura/tint, curvas RGB/HSL, scopes, LUTs, controle de gamut, HDR | Gerenciamento OCIO, conformidade Rec.709/Rec.2020, ranges e alpha corretos, sem clipping indevido |
| Legendas | Whisper local, legenda por palavra, estilos, caixas seguras, timeline CC, correção, export SRT/VTT e burn-in | WER/CER por idioma, precisão de timing, validadores SRT/VTT, testes de estilos e codificação Unicode |

## Base de IA

- **V0.2.0**: faster-whisper opcional em CPU/int8, modelos `small`, `medium`, `large-v3-turbo`, `large-v3`; sem transcrição real validada neste ambiente (dependência e pesos não instalados). A integração é assíncrona e guarda legendas em quadros inteiros.
- **Posterior**: whisper.cpp e Vulkan/Metal/CoreML como alternativas de aceleração sem CUDA (especialmente para GPUs AMD/Apple); benchmarks antes da escolha automática. Alinhamento por palavra e separação de falantes com solução local/licença compatível; WhisperX é uma referência técnica, não componente integrado em v0.2.0.
- Documentação: https://github.com/SYSTRAN/faster-whisper ; https://github.com/ggml-org/whisper.cpp ; https://github.com/m-bain/whisperX

## Critérios de aceitação profissional

1. O usuário realiza o mesmo trabalho fundamental de montagem/cor/áudio/animação sem precisar lidar com uma interface de nós em hipótese alguma.
2. Editar/deslocar cada painel não faz a prévia perder estado, nem quebra teclas/seleção; layouts persistem ao fechar/abrir e funcionam em múltiplos monitores.
3. Ao aplicar um efeito, o resultado visual é o mesmo na prévia e no arquivo renderizado; cada efeito tem presets testados e undo granular.
4. O produto sobrevive a mídia offline, erros de arquivos, falhas do render e falta de GPU com mensagens claras e dados preservados.
5. Transcrição e alinhamento reportam idioma, duração, taxa de erro avaliada por amostras reais; nunca alegar precisão absoluta.
6. Cross-platform real (Windows primeiro, macOS/Linux depois) com instalação reproduzível e testes em hardware-alvo, incluindo AMD.
