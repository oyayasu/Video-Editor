# Revisão de código v0.8.0

- Partiu da v0.7.0 integral, mantendo projeto `.meridian`, 49 efeitos e 3 transições, animações, nests, legendas, atalhos e exportação FFmpeg estável.
- Separou as funcionalidades de preview em `src/native_playback.py` (sem bibliotecas Python adicionais) e `web/gpu-preview.js` (WebGL2 opcional), em vez de duplicar o processador de efeitos no backend.
- MJPEG é produzido por um único processo FFmpeg por stream e por um compositor C++ existente, não por um novo processo para cada frame. A saída é consumida incrementalmente, com limite explícito de tamanho por JPEG. Saída é interrompível por desconexão e cancelamento.
- HTTP requer token CSRF para iniciar a sessão, ID de stream imprevisível e uso único; sessão antiga é invalidada quando outra começa. O servidor continua limitado ao loopback.
- Animação e ordem de camadas na prévia C++ usam o mesmo `NativeTimeline.frame()` do exportador; imagem JPEG perde fidelidade por compressão e escala.
- Shader WebGL2 centralizado em arquivo próprio, com tratamento explícito para contexto inexistente, e recursos GPU descartados na mudança de modo. Os efeitos avançados que o GPU ainda não reproduz são documentados, não anunciados como equivalentes.
- Não foi incorporado Vulkan/Metal/Direct3D por ausência de ambiente de validação; a exportação não é GPU. Não é correto chamar este protótipo de player profissional de áudio e vídeo sincronizados.
- Testes de regressão antigos mantidos e acrescentados testes para registro de sessão, autenticação HTTP, MJPEG real, cancelamento e parsing. Browser smoke test sem conectividade HTTP local foi feito com API simulada.
- Código preexistente ainda requer refatoração: `web/editor.js` e `src/server.py` são grandes e acoplados, exportação não é transacional, e a estrutura de decoders precisa de seek/cache avançado. A v0.8 não afirma inexistência de código morto em toda a base.
