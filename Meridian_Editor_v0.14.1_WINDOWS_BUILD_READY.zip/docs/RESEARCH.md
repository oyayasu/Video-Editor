# Pesquisa de referência — 17 de outubro de 2026

Este arquivo é um **levantamento inicial fundamentado em fontes oficiais**, não uma alegação de que toda a interface ou todos os recursos já foram analisados quadro a quadro. A Blackmagic fornece vídeos oficiais de treinamento; a Adobe fornece documentação e demonstrações em vídeo. Examinar cada gravação, versão e variação de painel exige um programa contínuo de pesquisa e testes. Não incluímos frames de terceiros no repositório.

## Premiere Pro: referências primárias

1. [Controles de efeitos — visão geral, imagens dos painéis](https://helpx.adobe.com/premiere/desktop/add-video-effects/apply-video-effects/about-effect-controls-panel.html). Referência de grupos de propriedades, indicadores de keyframes, timeline de efeitos e filtros.
2. [Adicionar keyframes, imagens de demonstração](https://helpx.adobe.com/premiere/desktop/add-video-effects/control-effects-and-transitions-using-keyframes/add-keyframes.html). Referência de botão de animação, keyframe na timeline e gráficos de valor/velocidade.
3. [Interpolação Bézier — tangentes editáveis](https://helpx.adobe.com/premiere/desktop/add-video-effects/control-effects-and-transitions-using-keyframes/control-effect-changes-using-bezier-keyframe-interpolation.html). Referência para futuras curvas espaciais/temporais.
4. [Animação de camadas — tutorial em vídeo Adobe](https://helpx.adobe.com/premiere/desktop/add-text-images/insert-images-and-graphics/animate-layers-using-the-effect-controls-panel.html). Referência da interação de animação, Ease In/Out e controle de propriedades.
5. [Como agrupar, encaixar e soltar painéis](https://helpx.adobe.com/premiere/desktop/get-started/tour-the-workspace/dock-group-undock-panels.html). Referência de layout para múltiplos monitores.
6. [Keyframes na timeline](https://helpx.adobe.com/premiere/desktop/add-video-effects/control-effects-and-transitions-using-keyframes/view-keyframes-and-properties-in-the-timeline-panel.html). Referência de animação inline nas faixas.
7. [Biblioteca de efeitos e predefinições](https://helpx.adobe.com/premiere/desktop/add-video-effects/types-of-effects/about-effects-and-effects-panel.html). Referência para efeitos e presets pesquisáveis.
8. [Camadas de ajuste](https://helpx.adobe.com/premiere/desktop/add-video-effects/apply-video-effects/create-adjustment-layers.html). Referência para corrigir múltiplas camadas simultaneamente.
9. [Máscaras e tracking](https://helpx.adobe.com/premiere/desktop/add-video-effects/work-with-masks/track-masks.html). Referência para composição não destrutiva.
10. [Atalhos de teclado oficiais](https://helpx.adobe.com/br/premiere/desktop/get-started/keyboard-shortcuts/default-keyboard-shortcuts.html). Planejamento de mapa de atalhos editável.
11. [Opções de exportação](https://helpx.adobe.com/premiere/desktop/render-and-export/export-files/export-options-in-premiere.html). Referência de fila, formatos, conformação e interoperabilidade.
12. [Painel de áudio](https://helpx.adobe.com/premiere/desktop/add-audio-effects/basic-audio-editing/edit-audio-using-the-properties-panel.html). Referência para propriedades rápidas e mixagem.

## DaVinci Resolve: referências primárias

1. [Manual oficial do DaVinci Resolve 21, Blackmagic Support](https://www.blackmagicdesign.com/support). Manual de 10 julho de 2026, abrangendo edição, cor, VFX, áudio e entrega.
2. [Edit — imagens oficiais e exemplos funcionais](https://www.blackmagicdesign.com/br/products/davinciresolve/edit/). Timeline com camadas, Inspector, keyframe/curvas, velocidade, multicâmera, transições, áudio e composição.
3. [Color — imagens oficiais e grade profissional](https://www.blackmagicdesign.com/products/davinciresolve/color). Curvas personalizadas, scopes, nodes, grades reutilizáveis.
4. [Treinamento oficial gratuito da Blackmagic com vídeos](https://www.blackmagicdesign.com/br/products/davinciresolve/training/). Inclui introdução à edição parte 1 (~79 minutos), parte 2 (~56 minutos), edição multicâmera (~32 minutos), efeitos visuais na edição (~30 minutos), introdução ao Fusion (~52 minutos), composição básica (~59 minutos), gráficos em movimento (~68 minutos) e muito mais. Contém arquivos de projeto para comparar funções.
5. [Fusion 21 User Manual](https://www.blackmagicdesign.com/support). Componentes de animação, spline, node graph, chaveamento, composição 2D/3D.

## Padrões e mecanismos livres

- [MLT Framework — código-fonte oficial](https://github.com/mltframework/mlt), [documentação do framework](https://mltframework.org/docs/framework/) e [DTD XML](https://github.com/mltframework/mlt/blob/master/src/modules/xml/mlt-xml.dtd). Objetivo: mecanismo profissional de edição não linear e composição.
- [Kdenlive — arquitetura de build](https://github.com/KDE/kdenlive/blob/master/dev-docs/build.md). Referência de uso real Qt6/MLT, não um componente copiado na íntegra.
- [OpenFX](https://openeffects.org/) — padrão para plugins de efeitos visuais.
- [OpenTimelineIO](https://opentimelineio.readthedocs.io/) — intercâmbio de timelines.
- [OpenColorIO](https://opencolorio.org/) — gerenciamento de cor.
- [FFmpeg](https://ffmpeg.org/) — codecs, filtergraphs e exportação transitória.

## Lições de interface (hipóteses para validação)

- Reunir edição e composição leve na mesma timeline reduz mudança de contexto. **Hipótese de UX**, não uma métrica provada.
- Controles numéricos de propriedades ao lado de keyframes e gráfico de velocidade podem melhorar precisão, conforme funções documentadas no Premiere.
- O editor de curva inline e Inspector do Resolve ilustram que composição camadas + animação podem funcionar sem exposição obrigatória de nós.
- Um gráfico de interpolação profissional exige tangentes Bézier customizadas, seleção múltipla, conversão de unidades, visualização espacial, correção de keyframes fora do tempo útil, undo granular e tratamento determinístico no renderizador.
- A compatibilidade nativa com plugins `.prm` não foi provada nem implementada. Priorizar OpenFX e um SDK próprio documentado.

## Registro de referências visuais (não incorporadas ao ZIP)

- Adobe: telas de Effect Controls, propriedades, motion, opacidade e animação nas páginas (1), (2), (3) e (4) acima.
- Blackmagic: imagens oficiais das páginas Edit e Color, recursos de keyframes e curvas na página Edit.
- Treinamentos oficiais Blackmagic: vídeos com demonstração de operações reais (não houve revisão quadro a quadro de todos eles).

## Investigação ainda pendente para reprodução milimétrica

- Capturar a UI atual em Windows/macOS e medir espaçamento, estados, ícones, escalas HiDPI, atalhos contextuais, dicas de ferramentas e acessibilidade — sem copiar logos ou ícones de marca.
- Reproduzir uma bateria de projetos com operações equivalentes no Premiere/Resolve para comparar resultados, timecode, keyframes, mixed frame rates, áudio e formatos exportados.
- Levantamento comparativo dos plugins nativos e terceiros mais usados, distribuídos por tipo, licença e suporte a GPU.
- Revisão de todas as gravações tutoriais e manuais relevantes antes de afirmar equivalência de funções.
- Definição de uma lista de aceitação baseada em editoras e editores profissionais, com sessões observadas e testes de usabilidade reais.

## Pesquisa adicional — interface personalizável e legendas locais

- [Adobe: dock, group e undock de painéis](https://helpx.adobe.com/premiere/desktop/get-started/tour-the-workspace/dock-group-undock-panels.html), atualizado em janeiro de 2026. Definiu metas de drag-and-drop, áreas de encaixe, aba compartilhada e painéis flutuantes.
- [Adobe: workspaces personalizados](https://helpx.adobe.com/premiere/desktop/get-started/tour-the-workspace/change-create-reset-workspaces.html): salvar, carregar, restaurar layouts.
- [Qt QDockWidget](https://doc.qt.io/qt-6/qdockwidget.html): janelas encaixáveis e flutuantes; [QMainWindow saveState/restoreState](https://doc.qt.io/qt-6/qmainwindow.html): persistência nativa.
- [faster-whisper](https://github.com/SYSTRAN/faster-whisper): motor Whisper com CTranslate2 e licença MIT; `device='cpu', compute_type='int8'` para compatibilidade inicial sem GPU CUDA.
- [whisper.cpp](https://github.com/ggml-org/whisper.cpp): referência de inferência local multiplataforma com backends Vulkan e Metal, útil para AMD/Apple.
- [WhisperX](https://github.com/m-bain/whisperX): alinhamento por palavra e separação de falantes; certas funções requerem acesso a modelos e aceitação de termos no Hugging Face, não assumir que todas funcionem sem configuração.
- [FFmpeg filters](https://ffmpeg.org/ffmpeg-filters.html): filtros de legendas e áudio; gravação experimental de SRT ao MP4 necessita de build com libass.

A pesquisa documenta **referências e alternativas**, não conformidade de uma versão final. A exigência atual é nunca expor nós ao usuário, independentemente do subsistema.

## Follow-up sources (October 2026; v0.4 architecture)

- Adobe Premiere, Effect Controls: https://helpx.adobe.com/premiere/desktop/add-video-effects/apply-video-effects/about-effect-controls-panel.html — effect stack and editable property model.
- Adobe Premiere 26.0 category organization: https://helpx.adobe.com/uk/premiere/desktop/add-video-effects/effects-and-transitions-library/effects-and-transitions-reorganization.html — categories like Blur & Sharpen, Color Correction, Stylize, Transform.
- Adobe After Effects, effect listing: https://helpx.adobe.com/after-effects/desktop/apply-effects-and-animation-presets/effects-and-animation-presets/effect-list.html — breadth of built-in effects, 8/16/32-bit and GPU metadata.
- FFmpeg official filters: https://ffmpeg.org/ffmpeg-filters.html — actual available filters and their validated numeric options.

These sources informed functional design only; no proprietary code, icons or artwork was copied.
