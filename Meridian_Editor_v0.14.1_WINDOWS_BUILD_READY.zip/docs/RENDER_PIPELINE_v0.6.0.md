# Meridian v0.6.0 — contrato de preview e renderização

## Nível de garantia atual

A base técnica continua Python + JavaScript + FFmpeg. **Não** existe um novo compositor em C++/Qt nesta versão. O método `make_command()` em `src/render.py` gera o **mesmo grafo de vídeo** para duas saídas: MP4 completo e PNG de um frame solicitado. As diferenças residuais incluem formato de pixel na saída (`rgb24` para PNG; `yuv420p` e H.264 para MP4), codificação e processamento de áudio (omitido na prévia estática). Há um teste de comparação de pixel dentro de tolerância na suíte.

`render_frame()` não é um motor de playback. A operação percorre o pipeline desde o início da sequência, gera um PNG e o devolve ao navegador pelo POST `/api/preview-frame`, autenticado com o token local. Não deve ser acionada a 30/60 fps; um processamento por GPU de alto desempenho e cache incremental serão necessários no compositor definitivo. O botão Render frame fica desabilitado durante a operação, e a imagem é invalidada quando o usuário move o playhead ou edita o projeto.

A biblioteca de mídia e a timeline continuam reproduzidas pelo navegador em modo **Fast preview**; isso não assegura fidelidade em transições ou em todos os efeitos. A visualização precisa deve ser consultada manualmente via **Render frame**.

## Transições de duas fontes

As transições são referências entre dois clipes com `outgoing`, `incoming`, `start`, `duration`, `type` e ID. Elas são elementos da sequência, não filtros de um único clipe. A v0.6 oferece:

- `cross_dissolve`: a transparência da camada incoming cresce ao longo da sobreposição dos dois clipes. Requer uma fonte outgoing embaixo na mesma faixa; nenhum clipe é implicitamente expandido ou retimado.
- `wipe_left`: a transparência da fonte incoming usa um limite espacial crescente da esquerda para a direita, conservando a fonte outgoing até que ela seja coberta.
- `audio_crossfade`: áudio outgoing diminui progressivamente e incoming aumenta progressivamente; a mistura é linear em amplitude, não equal-power. Os fades atuam nos segmentos sobrepostos.

Limitações atuais: o cross dissolve depende do encaixe sequencial de duas fontes na mesma faixa; várias sobreposições simultâneas na mesma faixa não são representadas, e a validação rejeita transições cujas janelas se cruzam. Uma operação de trim/move pode ajustar a duração ou remover uma transição que deixe de ser válida. Não há edição independente dos handles, easing da transição ou suporte a múltiplos clipes num mesmo ponto de junção. A prévia rápida HTML não representa todas as transições.

## Keyframes de efeitos

`src/effects.py` registra explicitamente os parâmetros animáveis via `ANIMATABLE`. Cada instância de efeito pode guardar `keyframes: {parameter: [{frame, value, interpolation}]}` em frames locais ao clipe. A validação impede parâmetros desconhecidos, quadros repetidos, valores fora de alcance e interpoladores não suportados. As expressões do FFmpeg usam `t` local e avaliação por frame/bloco, após trim e `setpts` de cada fonte. Split mantém amostras nos limites e atualiza os offsets; nest preserva as curvas.

A implementação exportável inicial cobre `brightness_contrast.brightness`, `brightness_contrast.contrast`, `saturation.amount` e `audio_gain.gain`. Não é correto tratar todos os outros 45+ efeitos como animáveis. A UI oferece somente criação/remoção de pontos nesses parâmetros. Edição completa de curvas e tangentes de efeitos será projeto posterior.

## Riscos pendentes antes de um lançamento profissional

- Prévia realtime e exportação ainda usam caminhos de mídia diferentes.
- Falta teste Windows nativo, aceleração GPU, cache de quadro, gerenciamento de cores HDR/ACES, VFR, áudio subframe e render de efeitos pesados sob carga.
- Falta comportamento profissional completo de transições, incl. handles e manipulação conjunta de múltiplas faixas.
- Nest pré-renderiza sequências em ProRes 4444; pode custar espaço temporário e tempo considerável.
- `amix=normalize=0` preserva a soma de níveis, mas múltiplas faixas fortes podem produzir clipping. Não há limitador/master meter obrigatório.
- O campo `schema` segue em `1` por compatibilidade retroativa; uma migração versionada deve ser estabelecida antes de uma mudança incompatível.
