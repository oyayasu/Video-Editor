# Meridian v0.5.0 — testes realizados

Local de execução: contêiner Linux, Python 3.13, FFmpeg 7.1.5, FFprobe disponível.

## Evidência automatizada

- **47 testes de unittest aprovados**: `python -m unittest discover -s tests -q`.
- Todos os 49 recursos do registro têm especificação e adaptador de processamento ou animação de overlay testável.
- Todos os efeitos de vídeo da lista passaram por exportação MP4 individual na suíte de regressão.
- Todos os 13 efeitos novos de áudio passaram por exportação MP4 individual.
- Chroma Key seguido de Posterize manteve o canal alfa no ensaio rawvideo RGBA.
- O registro de pesquisa contém 327 itens etiquetados com seu status Adobe, separados da biblioteca executável.
- Foram verificados IDs únicos, compatibilidade de faixa, validação de faixa de valores, ordem de filtros e API de sessão do servidor.
- `node --check web/editor.js` e `node --check web/effects-ui.js`: sem erros de sintaxe.

## Limitações dos testes

- O Chromium headless deste ambiente bloqueou as navegações via HTTP de localhost e URL sintética. **Não foi possível realizar nova validação visual automatizada da interface v0.5.0**. O modelo da API é coberto por testes HTTP e os arquivos JS por análise de sintaxe; isso não equivale a teste de UI ponta-a-ponta.
- Não houve comparação perceptual ou numérica do resultado dos efeitos com os equivalentes Adobe; as implementações *não são 1:1*.
- FFmpeg export passando não garante que todos os efeitos preservem cores HDR/float, parâmetros animáveis, imagens multicamadas complexas ou transparência após todas as combinações possíveis.
- Não houve build/execução de EXE nativo Windows, aplicativo macOS, nem testes Vulkan/Metal/MLT/Qt. O produto segue protótipo HTML/JS/Python/FFmpeg.
- Transições entre dois clipes, Warp Stabilizer, Lumetri completo, OpenFX/VST3, 3D e prévia idêntica ao export **não estão implementados**.
