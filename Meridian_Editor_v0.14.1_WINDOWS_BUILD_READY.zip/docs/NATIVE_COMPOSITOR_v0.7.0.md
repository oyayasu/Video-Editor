# Meridian v0.7.0 — Native CPU compositor (experimental)

## Purpose and non-goals

This is the **first actual compiled compositor** in the Meridian codebase. Its
C++ library owns the final layer transform, straight-alpha compositing, and
transition masks. It is not a Qt port, not a GPU compositor, not real-time
playback, and not an HDR/color-managed After Effects replacement.

The old FFmpeg filter-graph renderer is retained without replacement.
`Render engine` in the UI controls both `Render frame` and MP4 export.
The selected renderer is **not serialized** into the `.meridian` project.

## Architecture

```
.meridian (validated, frame-based document)
   │
   ├─ existing FFmpeg filter-graph exporter [stable, unchanged]
   │
   └─ native experimental path: src/native_render.py
         │
         ├─ FFmpeg source decode + per-clip effect stack → RGBA frames
         ├─ native/compositor.cpp (C++17 shared library)
         │    ├─ RGBA straight-alpha source-over
         │    ├─ bilinear affine transform (scale, rotation, position)
         │    ├─ opacity and linear/hold/ease keyframes
         │    └─ cross dissolve + wipe masks
         ├─ PNG encoder → accurate still preview
         └─ H.264 encoder + separate FFmpeg audio mix/mux → MP4 export
```

Both *native preview frame* and *native export* call `NativeTimeline.frame()`.
This means geometry, layer order, masks, compositing, and opacity are shared
instead of implemented separately by the browser and exporter. FFmpeg effects
are still evaluated separately on each media decode. The generated PNG and
H.264 MP4 are not byte-identical because H.264 is lossy; compare representative
pixels within a tolerance. Some stochastic FFmpeg effects may not be exactly
reproducible between renders.

Frame numbering is integer-based; transforms are evaluated at clip-local frames.
The C ABI is explicit and versioned (`meridian_api_version() == 2`). RGBA is
8-bit in straight-alpha form. Bilinear sampling uses premultiplied-color
interpolation to avoid black fringes at transparent edges. Compositing itself
is performed on gamma-encoded data; **linear-light compositing, ACES, HDR and
16/32-bit floating point are not implemented**.

Layer order is derived from the track order and clips' start frame. Video
transitions are evaluated on the incoming clip within validated overlaps.
The audio renderer currently reuses FFmpeg effects and mixes audio tracks to
AAC; audio lives outside the C++ pixel compositor.

## Compile

Requires a modern C++17 compiler, CMake and FFmpeg/FFprobe on PATH.

- Linux/macOS: `./build-native.sh`
- Windows x64: `build-native-windows.bat` (CMake + Visual Studio C++ Build Tools)

Library is copied into `native/bin/`; **no platform-specific binary is included
in the full source ZIP**. The new option is disabled until the library has been
built locally. `start-windows.bat` or `start-macos-linux.sh` still launches the
existing prototype, with Python 3.10+.

After compilation, run `python -m unittest discover -s tests -v` to test both
engines. Building or running the UI does not require paid Adobe software or a
license key. FFmpeg and third-party components keep their own licenses.

## Verified in Linux environment

- C++17 library built with CMake/GCC; no special shared-library dependencies.
- 13 tests: blending, true alpha preservation, clipping, cross dissolve,
  wipe, affine geometry, static and animated transforms, real PNG output,
  native MP4 video, visual still/MP4 comparison, and AAC audio mux.
- Real HTTP API tests verify selecting native engine, returning PNG, and
  finishing background MP4 export.
- 69 legacy tests remained functional.
- Browser JavaScript passes syntax checking; browser-to-local-server test
  cannot be performed in this environment (Chromium security interception).

## Known limitations, deliberately not hidden

- **CPU-only**, with sequential FFmpeg clip decoders and 8-bit RGBA frames.
  No GPU compute/accelerated rendering, no native Qt dockable UI.
- **Not real-time**: the preview is a PNG rendered on demand and the normal
  browser video playback is still an approximation. Random seeking may decode
  frames from the clip's source in-point before reaching the target.
- Per-frame FFmpeg source decoding and copy-heavy ctypes bridge can be slow
  with 4K/complex/long timelines. This implementation intentionally favors
  correctness and controlled memory over low latency.
- Native caption **burn-in is not supported**. Choose FFmpeg Stable for
  projects requiring burned subtitles. Export SRT/VTT separately as before.
- Nested sequences use the **legacy FFmpeg renderer** to create ProRes 4444
  temporary child media before the C++ parent pass: not end-to-end native.
- Native path does not promise exact color equivalence with legacy engine;
  it has different alpha and scale/rotation interpolation semantics.
- Effects continue to run in FFmpeg, not native C++; some effect pipelines,
  variable-frame-rate material, and effect time-domain behavior need further
  parity and stress testing. Cross-platform Windows/macOS native binaries
  have not yet been built or tested in this environment.
- Rendering long sequences still lacks export progress/cancel/recovery,
  robust cache, GPU profiling, proxy scheduling, multi-threaded render queue,
  and professional audio synchronization validation.

## Next milestones

1. Cache-aware clip decoding with precise random seeks, stream timestamps and
   bounded working set.
2. Display the **native** frame during continuous playback, not just on demand.
3. GPU backend abstraction (Vulkan/Metal/D3D) with a CPU reference renderer.
4. Scene-linear floating-point composition, reliable chroma key and color
   management (OpenColorIO/ACES), independently tested against reference images.
5. Full native dockable UI (Qt), stable interchange project model and 3rd party
   effect/plugin host. No visual node editor will be added.
