# v0.8.0 — Monitor GPU e reprodução contínua experimental

## Arquitetura implementada

A v0.8.0 mantém 3 caminhos explicitamente diferentes, selecionáveis no monitor:

| Modo | Fonte dos pixels | Composição | Codificação/transporte | Limites |
|---|---|---|---|---|
| Browser | HTMLVideoElement por clipe | CSS | navegador | ignora diversos efeitos |
| WebGL2 GPU | HTMLVideoElement por clipe | shaders WebGL2: transformações, opacidade, contraste, saturação, brilho, dois tipos de transição | vídeo decodificado pelo navegador/textura WebGL2 | não é o renderizador de exportação; blur, filtros avançados, HDR, masks/tracking ausentes |
| C++ Stream | FFmpeg decodifica clipes e aplica efeitos | `NativeTimeline.frame()` usa `native/compositor.cpp` | FFmpeg MJPEG 640px image2pipe e multipart HTTP | CPU, <=15 fps nominal, sem garantias de latência/sincronização audiovisual |

`Render engine` (seletor antigo) continua independente e escolhe o motor da exportação MP4 e o botão `Render frame`. `C++ Stream` é um **monitor** experimental, não deve ser confundido com um exportador GPU. Para verificar conformidade, use Render frame/MP4 do mesmo motor C++.

### MJPEG: detalhes

1. `POST /api/native-preview-start` recebe projeto validado e frame, com header `X-Meridian-Token` (CSRF). Pode abrir composição aninhada no contexto de edição. Registra URL imprevisível, de uso único, com expiração de 45 segundos se não consumida.
2. `GET /api/native-stream/<token>` no loopback consome a URL uma vez; envia `multipart/x-mixed-replace; boundary=meridianframe`, `Content-Type:image/jpeg`, `Content-Length` e `X-Meridian-Frame` por parte.
3. Uma thread de produção constrói quadros RGBA via `NativeTimeline.frame()` (até 15 fps nominais) e alimenta a entrada de um único FFmpeg MJPEG; o leitor consome os JPEGs em incrementos de 16 KB, limitados a 8 MiB por quadro.
4. `POST /api/native-preview-stop` cancela a sessão e encerra o processo. A desconexão encerra o transporte e define o evento de interrupção. Os processos filho também são eliminados na saída do contexto.

A CPU pode ficar abaixo de 15 fps, especialmente em grandes resoluções ou efeitos pesados; neste caso, a linha do tempo e os elementos de áudio do navegador não esperam o quadro de vídeo. O cabeçalho `X-Meridian-Frame` permite implementar no futuro timestamps explícitos num protocolo com sincronização; `<img>` MJPEG do navegador não expõe esse cabeçalho à UI. O formato e o protocolo poderão evoluir sem alterar `.meridian`.

### Compositor WebGL2

- Um canvas `WebGL2` compila shaders GLSL ES 3.00 na abertura do modo GPU.
- Texturas vêm de `HTMLVideoElement`; sem dependência de servidores externos. O raster de saída usa a área do monitor; vídeo fonte é encaixado mantendo o aspecto.
- Vertex shader posiciona retângulos de vídeo com transformação afim (posição/escala/rotação). Fragment shader aplica opacidade, contraste, brilho, saturação e máscara de transição. Mistura via `gl.SRC_ALPHA/ONE_MINUS_SRC_ALPHA`.
- Em erro de criação do contexto ou upload, o monitor volta a `Browser · Basic` e notifica.
- **Não há teste de aceleração GPU real nesta infraestrutura (sem `/dev/dri`, WebGL2 bloqueado no Chromium headless).** O código passou por verificação sintática e teste de fallback no navegador. Validar em Windows com a RX 7600 ou outra GPU antes de publicar métricas.

## Compatibilidade e limitações

O projeto usa Python/JS e ainda não tem host nativo Qt ou compositor Vulkan. FFmpeg pode usar codec acelerado em outras rotas, mas a v0.8.0 **não implementa** decodificação/encodificação GPU automática. A combinação dos dois modos experimentais não fornece fidelidade, desempenho e áudio sincronizado simultaneamente.

Testes de conformidade exigidos para fase seguinte: benchmarks de frame time P50/P95, scrub/seek backward eficiente, cache de frames, sincronismo AV com clock de áudio, checagem de fragment shader em GPU real, paridade de cores e performance em cenas com >= 8 camadas, 4K/HDR.
