# Meridian Quick Edit v0.12.0 — pesquisa, licenças e limites

## Objetivo

Presets *genuinamente integrados* e reproduzíveis dentro do Meridian, preservando a interface profissional, a edição manual e o projeto aberto. O catálogo rápido não depende de servidores externos. As receitas são autoria do projeto (metadados e parâmetros), não cópias de código, gráficos, fotos, sons, fontes ou templates proprietários.

## Material público estudado

- CapCut Transitions: https://www.capcut.com/tools/video-transition — inspiração apenas em categorias e acessibilidade por clique; não incorpora ativos ou marcas do produto.
- CapCut Keyframes: https://www.capcut.com/resource/how-to-add-keyframes-in-capcut — facilidade de edição e acesso rápido à animação.
- Kdenlive Effects & Filters: https://docs.kdenlive.org/en/effects_and_filters.html — organização por categorias, favoritos, pilhas de efeitos e aplicação a clipes.
- FFmpeg xfade (implementação LGPL, referência de linguagem visual e efeitos de transição): https://github.com/FFmpeg/FFmpeg/blob/master/libavfilter/vf_xfade.c — o Meridian não importa seu código-fonte nesta etapa; o renderizador já usa o FFmpeg externo.
- Google Fonts: https://github.com/google/fonts — licenciamento por família e arquivos OFL originais. https://openfontlicense.org — licença SIL OFL 1.1.
- Mixkit free templates: https://mixkit.co/free-video-templates/ e https://mixkit.co/license/ — **não foram incorporados**. Licença para uso em projetos produzidos com esses materiais não é automaticamente autorização para embutir os arquivos de template em um novo aplicativo e redistribuí-los como uma biblioteca open-source. Cada pack exigiria análise individual.

## Recursos implementados nesta etapa

- **82 presets originais:** 46 animações/fades (40 variações direcionais + 6 fades), 24 looks/stacks de vídeo, 12 cadeias de áudio; `src/quick_packs.py` constitui a fonte única de especificações e aplicações.
- **13 transições:** 12 de vídeo (dissolve, 4 wipes duros, 4 wipes suaves, 2 diagonais, círculo) e um crossfade de áudio. Essas transições funcionam sobre clipes realmente sobrepostos. O FFmpeg Stable é obrigatório para as 10 novas máscaras; o compositor C++ experimental rejeita explicitamente variantes que ainda não desenha.
- **37 famílias tipográficas indicadas no navegador de fontes**, todas apontando à categoria `/ofl/` do repositório oficial de Google Fonts, em vez de empacotar arquivos. É preciso conferir a licença e os nomes reservados de cada arquivo antes de modificar/distribuir fontes.
- **Title/Text Layer (experimental):** com Pillow opcional, gera PNG RGBA transparente e o coloca numa faixa de vídeo. Pode receber presets de animação de posição e efeitos como outros clipes. O texto rasterizado **ainda não é reeditável como texto**; o usuário deverá gerar nova arte para trocar palavras. Pode usar fonte instalada .ttf/.otf indicada pelo usuário ou fonte de fallback do Pillow. **Meridian não certifica a licença de fontes externas escolhidas pelo usuário.**
- Favoritos, pesquisa e categorias na aba `Quick Edit`, sem redesenhar os painéis principais.

## Licenciamento de fontes — notas explícitas

SIL OFL 1.1 permite **uso comercial, incorporação em documentos/vídeos e redistribuição acompanhada da licença**, com restrições (em especial a venda isolada do arquivo e os nomes reservados nas alterações). A licença **não equivale a domínio público**. O catálogo atual é de **descoberta de fontes**, não uma instalação/download automática dentro do programa; nenhum arquivo .ttf/.otf foi incorporado ao ZIP. A interface permite escolher um arquivo de fonte já instalado para gerar um título, mediante responsabilidade do usuário sobre a licença desse arquivo.

## Limitações técnicas

- Presets de movimento animam posição x/y e opacidade via fade nativo; curvas de escala, rotação e opacidade contínua no exportador FFmpeg ainda dependem da migração do compositor e não são anunciadas como incluídas nesses presets.
- A prévia básica HTML e a prévia WebGL2 ainda não reproduzem perfeitamente todas as novas transições, efeitos e fades. O `Render frame` com FFmpeg e a exportação FFmpeg usam o mesmo grafo.
- Títulos são rasterizados, não shapes vetoriais editáveis, e ficam vinculados à localização absoluta do arquivo PNG. O usuário deve copiar os PNGs ao migrar de computador ou realizar relink manual.
- Pillow é uma dependência opcional **apenas para gerar novos títulos**. Edição, importação, presets e exportação das mídias existentes não precisam de Pillow.
- Não há instalador Windows `.exe`, aplicativo Qt, aceleração GPU na exportação, coleção importada do Mixkit nem pacotes de música/som.

## Verificação

- Exercitado cada preset contra o modelo e validação de parâmetros (82/82); testes unitários para erros, trilhas bloqueadas e imutabilidade do documento de entrada.
- 12 transições de vídeo renderizadas em quadros reais FFmpeg 1280×720 em verificação isolada; arquivos PNG não vazios. A suíte de CI usa um subconjunto para não impor custos excessivos a todas as execuções.
- Gerado título transparente localmente e renderizado sobre um clipe de vídeo de teste, confirmado por imagem.
- API HTTP `/api/apply-preset`, `/api/create-title`, metadados de `/api/session` exercitados localmente.
- UI aberta em Chromium com DOM/script carregados de arquivos locais e API simulada, porque a navegação HTTP loopback é bloqueada no ambiente de teste; Quick Edit com 82 cards, Fonts 37, pesquisa/favoritos e modal de Title sem erros JavaScript.
- A suíte de regressão completa de todos os subsistemas não foi executada nesta rodada; testes focalizados estão no relatório.
