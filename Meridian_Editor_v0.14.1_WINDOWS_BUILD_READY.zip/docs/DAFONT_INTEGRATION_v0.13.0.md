# DaFont integration v0.13.0 — licensing, implementation and limits

## Decisions

The Quick Edit font library now displays **54 families**: the preexisting 37 Google Fonts / SIL OFL links, plus **17 commercial-use families** whose authors/license pages on DaFont were reviewed. No third-party `.ttf` or `.otf` binaries are embedded in the ZIP. The Meridian program is GPL-3.0; downloaded font files keep their own creator-assigned licenses (SIL OFL 1.1 or CC0 1.0).

The [DaFont FAQ](https://www.dafont.com/faq.php#copyright) cautions that site badges are *indicative*, not a complete license. “100% Free” is not automatically a license to repackage/re-host binaries. The DaFont side therefore uses only fonts with a direct statement by the author of a named license that explicitly permits commercial work. For use or redistribution beyond normal commercial video titles, always preserve the original archive's license notices.

## 17 approved DaFont families

| Family | Genre | Declared license | DaFont |
|---|---|---|---|
| Creato Display | Headlines & Modern | SIL OFL 1.1 | https://www.dafont.com/creato-display.font |
| Juliett | Clean & Modern | SIL OFL 1.1 | https://www.dafont.com/juliett.font |
| Elevatia | Clean & Modern | SIL OFL 1.1 | https://www.dafont.com/elevatia.font |
| Thernaly | Clean & Modern | SIL OFL 1.1 | https://www.dafont.com/thernaly.font |
| Wiltype | Clean & Modern | SIL OFL 1.1 | https://www.dafont.com/wiltype.font |
| Friendly Sans | Handwriting | SIL OFL 1.1 | https://www.dafont.com/friendly-sans.font |
| Signwood | Vintage & Retro | SIL OFL 1.1 | https://www.dafont.com/signwood.font |
| Pinzelan | Handwriting | SIL OFL 1.1 | https://www.dafont.com/pinzelan.font |
| Eightgon | Tech & Futuristic | SIL OFL 1.1 | https://www.dafont.com/eightgon.font |
| Datdot | Tech & Futuristic | SIL OFL 1.1 | https://www.dafont.com/datdot.font |
| Pixelbasel | Pixel & Gaming | SIL OFL 1.1 | https://www.dafont.com/pixelbasel.font |
| Help Me | Horror & Display | SIL OFL 1.1 | https://www.dafont.com/help-me.font |
| Public Pixel | Pixel & Gaming | CC0 1.0 | https://www.dafont.com/public-pixel.font |
| Home Video | Pixel & Gaming | CC0 1.0 | https://www.dafont.com/home-video.font |
| Unitblock | Headlines & Modern | CC0 1.0 | https://www.dafont.com/unitblock.font |
| Hexcore | Tech & Futuristic | CC0 1.0 | https://www.dafont.com/hexcore.font |
| Saved by Zero | Tech & Futuristic | CC0 1.0 | https://www.dafont.com/saved-by-zero.font |

## End-user workflow

1. In the desktop prototype, select **Quick Edit → DaFont & Free Fonts**.
2. Use the font card to open its **original DaFont page**, where the author and license can be reviewed, and download the ZIP.
3. In Meridian click **Import ZIP** for that family. Choose the downloaded archive; accepted fonts are stored under `~/.meridian-editor/fonts/<family-id>/` (not installed globally).
4. After import, the card displays **imported** and shows its preview where browser font loading is available.
5. Click **Use in Title**, enter title and duration, or open **Create Title** and select a previously imported DaFont family + variant.
6. Rendered titles are local RGBA PNG overlays. Editing the original text still requires generating another title; native editable typography is future work.

Google Fonts remain discovery-only links as before; they are not silently auto-downloaded or installed.

## Technical safety and integration

`src/font_library.py` is the single source of truth for the curated DaFont catalog, accepted archive members, provenance, and local-font resolution. `POST /api/import-dafont` accepts only a curated family and Base64 ZIP with an authenticated loopback session; the archive is capped at 7 MiB, inflated contents at 22 MiB, individual fonts at 5 MiB, and 200 entries. It rejects duplicate expected filenames, compressed archives without matching font files, non-loadable font files, and ZIP symlinks. Extraction is never invoked: approved data are written to canonical predefined filenames. License / readme files are preserved when included, and a `source.json` records the author's page and downloaded ZIP SHA-256. It cannot cryptographically prove that a user selected an authentic DaFont download.

The `GET /api/installed-font/<family>/<variant>` route serves only validated installed variants so the browser can display the real typeface in its catalog. `POST /api/create-title` resolves `font_id` and `font_variant` on the server, preventing clients from sending arbitrary managed font filenames. Imported fonts are persisted independently of the `.meridian` project; rendered PNG title assets still need to be moved with the project for cross-computer portability.

**Limitations:** this environment cannot retrieve the DaFont binary ZIP downloads. No actual DaFont typeface files are bundled, no all-site scraper exists, and no automatic license verification of user-selected ZIP content is possible. `Pillow` is needed to import (font-load test) and generate titles. Only curated families are approved for commercial-use import. FFmpeg Stable is required for title overlay exports as before.

## Tests

`python -m unittest discover -s tests -p 'test_dafont_library_v013.py' -v`

Tests use *synthetic ZIPs with renamed local font files*, not redistributed DaFont assets. Checks include successful import, local persistence, alpha-title generation, HTTP API end-to-end, rejection of wrong names / corrupted fonts / unknown families / oversized ZIPs, and path traversal denial. Chromium tests cover catalog display, filters, disabled/enabled title controls and UI error handling. Browser tests have a simulated API; separate HTTP tests cover the actual backend.
