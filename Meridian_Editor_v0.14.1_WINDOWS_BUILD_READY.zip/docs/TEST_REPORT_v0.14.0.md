# Meridian v0.14.0 — test report

This release is a **working source-code preview**, not an installable or fully
professional Effects workspace. Validation performed on Linux with FFmpeg,
Python and Chromium. Windows, Metal/Vulkan GPU and macOS builds are untested.

## Completed checks

1. Every one of the 18 newly implemented effects generated a real PNG frame
   with FFmpeg; the combined effect stack and alpha masks were also rendered.
2. Geometric rectangle and ellipse matte, inverse matte, alpha preservation,
   feature guard and mask validation are covered by the new tests.
3. Drop Shadow was verified against two synthetic transparent/opaque image
   layers; source pixels remain intact and the shadow darkens the background.
4. Actual FFmpeg MP4 export completed after Sepia + Glow + Drop Shadow +
   geometric mask, **with video and audio streams** (`ffprobe` verified).
5. Browser UI tested headlessly with Chromium and simulated session/API:
   open Effects, select clip, add ellipse, change mask center, search/apply Glow.
   No JavaScript page errors in the final run.
6. Previous editorial, shortcuts, source/program monitors, quick presets and
   effect model regression suites were exercised separately. See console test
   invocation below; fast suites (93 cases) passed after the legacy effect
   catalog count assertion was upgraded to 67.
7. HTTP preview, editor and session API regression: 36 cases ran, with
   34 passes and 2 skips. These were separate from the simulated-browser test.
8. Python compiled and JS syntax checked; no dependencies were copied from
   Adobe or included as font binaries.

## Limits

The full monolithic test suite (all high-resolution render variants) was not
run to completion in this release; avoid claiming a full suite pass. Testing
was primarily conducted under Linux. Playback frame-accurate performance,
real GPU export, timing on actual Windows hardware and GUI accessibility need
further validation. Some effects are deliberately approximations.
